"""
Smart Micro-Batcher for LLM API calls.

Problem: Sending 50 tiny chapters as 50 separate API calls wastes
network overhead and rate-limit slots.

Solution: Group adjacent small chapters/chunks into batches that fit
within a single API call's token budget. Use delimiters so the LLM
translates each segment separately, then split the response back out.

Flow:
  chunks -> group into batches -> one API call per batch -> split output
"""
import re
from dataclasses import dataclass, field


SEGMENT_DELIMITER = "=== SEGMENT {n} ==="
SEGMENT_PATTERN = re.compile(r"===\s*SEGMENT\s*(\d+)\s*===")

# Conservative: 4 chars ~ 1 token
CHARS_PER_TOKEN = 4


@dataclass
class Segment:
    index: int
    text: str
    token_estimate: int = 0

    def __post_init__(self):
        self.token_estimate = max(1, len(self.text) // CHARS_PER_TOKEN)


@dataclass
class Batch:
    segments: list[Segment] = field(default_factory=list)
    total_input_tokens: int = 0

    def can_add(self, seg: Segment, budget: int) -> bool:
        # Reserve output tokens (Hindi output is ~1.3x English input)
        output_reserve = int(self.total_input_tokens * 1.4) + int(seg.token_estimate * 1.4)
        total = self.total_input_tokens + seg.token_estimate + output_reserve
        return total <= budget

    def add(self, seg: Segment):
        self.segments.append(seg)
        self.total_input_tokens += seg.token_estimate

    @property
    def is_single(self) -> bool:
        return len(self.segments) == 1


class MicroBatcher:
    def __init__(self, max_tokens_per_call: int = 3500):
        self.max_tokens = max_tokens_per_call

    def build_batches(self, texts: list[str]) -> list[Batch]:
        segments = [Segment(index=i, text=t) for i, t in enumerate(texts)]
        batches: list[Batch] = []
        current = Batch()

        for seg in segments:
            # If single segment exceeds budget, it gets its own batch
            if seg.token_estimate * 2.4 > self.max_tokens:
                if current.segments:
                    batches.append(current)
                    current = Batch()
                solo = Batch()
                solo.add(seg)
                batches.append(solo)
                continue

            if current.can_add(seg, self.max_tokens):
                current.add(seg)
            else:
                if current.segments:
                    batches.append(current)
                current = Batch()
                current.add(seg)

        if current.segments:
            batches.append(current)

        return batches

    def format_batch_input(self, batch: Batch) -> str:
        if batch.is_single:
            return batch.segments[0].text
        parts = []
        for seg in batch.segments:
            parts.append(SEGMENT_DELIMITER.format(n=seg.index + 1))
            parts.append(seg.text)
        return "\n\n".join(parts)

    def split_batch_output(self, batch: Batch, output: str) -> dict[int, str]:
        if batch.is_single:
            return {batch.segments[0].index: output}

        result = {}
        splits = SEGMENT_PATTERN.split(output)

        # splits looks like: [preamble, "1", text1, "2", text2, ...]
        idx = 1
        while idx < len(splits) - 1:
            seg_num = int(splits[idx]) - 1  # 0-indexed
            text = splits[idx + 1].strip()
            result[seg_num] = text
            idx += 2

        # Fallback: if delimiter splitting failed, assign whole output to first segment
        if not result:
            result[batch.segments[0].index] = output

        return result
