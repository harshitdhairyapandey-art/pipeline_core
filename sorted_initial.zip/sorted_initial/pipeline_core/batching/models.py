from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional
from ..core.models import StageType

@dataclass
class ContentUnit:
    unit_id: str
    chapter_id: str
    order_index: int
    text: str
    title: Optional[str] = None
    metadata: Dict[str, Any] = field(default_factory=dict)

@dataclass
class BatchPlan:
    batch_id: str
    stage: StageType
    provider: str
    model: str
    unit_ids: List[str]
    order_start: int
    order_end: int
    estimated_chars: int
    estimated_tokens: int
    input_artifact_path: str
    output_artifact_path: str
    retry_count: int = 0

@dataclass
class BatchManifest:
    job_id: str
    stage: StageType
    total_units: int
    total_batches: int
    batches: List[BatchPlan] = field(default_factory=list)
