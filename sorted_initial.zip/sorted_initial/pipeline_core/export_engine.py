"""
Production export engine.
- DOCX: Nirmala UI font, justified paragraphs, cover page
- PDF: reportlab with Devanagari, page numbers
- EPUB3: ebooklib with NCX navigation
- TXT: plain text fallback (always works)
"""
import time
from pathlib import Path

DATA_DIR = Path("data")


class ExportEngine:
    def run(self, title: str = "LexiFlow Novel",
            formats: list = None) -> dict:
        if formats is None:
            formats = ["docx", "txt"]

        polished_dir = DATA_DIR / "polished"
        export_dir = DATA_DIR / "exports"
        export_dir.mkdir(parents=True, exist_ok=True)

        files = sorted(polished_dir.glob("chapter_*.txt"))
        if not files:
            raise FileNotFoundError("No polished chapters found")

        ts = time.strftime("%Y%m%d_%H%M")
        safe_title = "".join(c if c.isalnum() or c in "-_ " else "" for c in title)
        base = f"{safe_title}_{ts}"
        results = {}

        chapters = []
        for f in files:
            chapters.append(f.read_text(encoding="utf-8"))

        if "txt" in formats:
            p = export_dir / f"{base}.txt"
            p.write_text("\n\n".join(chapters), encoding="utf-8")
            results["txt"] = str(p)

        if "docx" in formats:
            path = self._export_docx(chapters, export_dir, base, title)
            if path:
                results["docx"] = str(path)

        if "pdf" in formats:
            path = self._export_pdf(chapters, export_dir, base, title)
            if path:
                results["pdf"] = str(path)

        if "epub" in formats:
            path = self._export_epub(chapters, export_dir, base, title)
            if path:
                results["epub"] = str(path)

        return results

    def _export_docx(self, chapters, export_dir, base, title):
        try:
            from docx import Document
            from docx.shared import Pt, Inches
            from docx.enum.text import WD_ALIGN_PARAGRAPH

            doc = Document()

            # Default font
            style = doc.styles["Normal"]
            style.font.name = "Nirmala UI"
            style.font.size = Pt(12)

            # Cover page
            cover = doc.add_paragraph()
            cover.alignment = WD_ALIGN_PARAGRAPH.CENTER
            run = cover.add_run(title)
            run.font.size = Pt(28)
            run.font.name = "Nirmala UI"
            run.bold = True
            doc.add_page_break()

            for i, chapter_text in enumerate(chapters):
                if i > 0:
                    doc.add_page_break()
                for para_text in chapter_text.split("\n\n"):
                    para_text = para_text.strip()
                    if not para_text:
                        continue
                    p = doc.add_paragraph(para_text)
                    p.alignment = WD_ALIGN_PARAGRAPH.JUSTIFY
                    for run in p.runs:
                        run.font.name = "Nirmala UI"
                        run.font.size = Pt(12)

            path = export_dir / f"{base}.docx"
            doc.save(str(path))
            return path
        except ImportError:
            return None

    def _export_pdf(self, chapters, export_dir, base, title):
        try:
            from reportlab.lib.pagesizes import A4
            from reportlab.lib.units import mm
            from reportlab.pdfgen import canvas
            from reportlab.pdfbase import pdfmetrics
            from reportlab.pdfbase.ttfonts import TTFont
            from reportlab.lib.styles import ParagraphStyle
            from reportlab.platypus import SimpleDocTemplate, Paragraph, PageBreak

            # Try to register Nirmala UI for Devanagari
            try:
                pdfmetrics.registerFont(TTFont("NirmalaUI",
                    "C:/Windows/Fonts/Nirmala.ttf"))
                font_name = "NirmalaUI"
            except Exception:
                font_name = "Helvetica"

            path = export_dir / f"{base}.pdf"
            doc = SimpleDocTemplate(str(path), pagesize=A4)
            style = ParagraphStyle(
                "Hindi", fontName=font_name, fontSize=11,
                leading=16, spaceAfter=6,
            )

            story = []
            for i, chapter_text in enumerate(chapters):
                if i > 0:
                    story.append(PageBreak())
                for para in chapter_text.split("\n\n"):
                    para = para.strip()
                    if para:
                        story.append(Paragraph(para, style))

            doc.build(story)
            return path
        except ImportError:
            return None

    def _export_epub(self, chapters, export_dir, base, title):
        try:
            from ebooklib import epub

            book = epub.EpubBook()
            book.set_identifier("ayzer-" + base)
            book.set_title(title)
            book.set_language("hi")

            spine = ["nav"]
            toc = []

            for i, chapter_text in enumerate(chapters):
                ch_num = i + 1
                ch = epub.EpubHtml(
                    title=f"Chapter {ch_num}",
                    file_name=f"chapter_{ch_num:04d}.xhtml",
                    lang="hi",
                )
                html_paras = "".join(
                    f"<p>{p.strip()}</p>"
                    for p in chapter_text.split("\n\n")
                    if p.strip()
                )
                ch.content = (
                    f'<html><head><title>Chapter {ch_num}</title></head>'
                    f'<body><h2>Chapter {ch_num}</h2>{html_paras}</body></html>'
                )
                book.add_item(ch)
                spine.append(ch)
                toc.append(epub.Link(
                    f"chapter_{ch_num:04d}.xhtml",
                    f"Chapter {ch_num}", f"ch{ch_num}",
                ))

            book.toc = toc
            book.spine = spine
            book.add_item(epub.EpubNcx())
            book.add_item(epub.EpubNav())

            path = export_dir / f"{base}.epub"
            epub.write_epub(str(path), book)
            return path
        except ImportError:
            return None
