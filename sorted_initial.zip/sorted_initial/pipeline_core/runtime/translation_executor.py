"""
pipeline_core/runtime/translation_executor.py
===============================================
Translation executor.

Responsibilities:
  - Flatten batches into individual work items
  - Build prompts per unit
  - Dispatch through throughput-controlled provider calls
  - Validate output (non-empty, reasonable length)
  - Preserve result ordering
  - Halt cleanly on first failure

Separation of concerns is strict:
  - This module ONLY handles execution plumbing.
  - Prompt construction is in translation/prompt_builder.py.
  - Resilience (rate limiting, retries) wraps calls via throughput_controller.
  - The translation stage is a thin orchestration shell.
"""
import logging
from typing import List, Dict, Any, Callable, Tuple

from ..resilience.throughput_controller import execute_with_throughput_control
from ..resilience.fallback_policy import ResilienceFailure
from .concurrent_executor import execute_concurrently
from ..translation.translation_strategy import evaluate_translation_strategy

logger = logging.getLogger(__name__)

# Minimum and maximum length ratio (translated vs source) before flagging
_MIN_LENGTH_RATIO = 0.15
_MAX_LENGTH_RATIO = 5.0


def _validate_translation_output(
    text: str,
    source_text: str,
    unit_id: str,
) -> Tuple[bool, str]:
    """
    Validates that translated output is non-empty and not suspiciously sized.
    Returns (is_valid, error_message).
    """
    if not text or not text.strip():
        return False, f"Empty output for unit {unit_id}"

    src_len = max(len(source_text), 1)
    out_len = len(text)
    ratio   = out_len / src_len

    if ratio < _MIN_LENGTH_RATIO:
        logger.warning(
            f"Unit {unit_id}: output suspiciously short "
            f"(ratio {ratio:.2f}, src={src_len}, out={out_len})."
        )
    elif ratio > _MAX_LENGTH_RATIO:
        logger.warning(
            f"Unit {unit_id}: output suspiciously long "
            f"(ratio {ratio:.2f}, src={src_len}, out={out_len}). "
            "Possible repetition or hallucination."
        )

    # Length warnings are non-fatal — only empty output fails
    return True, ""


def _resolve_unit(unit_id: str, unit_lookup: Dict[str, Any]) -> Dict[str, Any] | None:
    """
    Resolve a unit from the lookup by exact ID or by base ID for split parts.
    Split parts have IDs like 'abc123_part1', 'abc123_part2'.
    Preprocessing only knows the base ID 'abc123'.
    """
    # Exact match first
    unit = unit_lookup.get(unit_id)
    if unit:
        return unit

    # Split part fallback — strip _partN suffix
    if "_part" in unit_id:
        base_id = unit_id.rsplit("_part", 1)[0]
        base_unit = unit_lookup.get(base_id)
        if base_unit:
            # Return a copy so we don't mutate the shared lookup
            return dict(base_unit)

    return None


def execute_translation_batches(
    batches:           List[Dict[str, Any]],
    unit_lookup:       Dict[str, Any],
    global_context:    Dict[str, Any],
    provider_callable: Callable,
    prompt_builder:    Callable,
    max_workers:       int = 2,
) -> Tuple[bool, Any]:
    """
    Execute translation for all batches.

    Args:
        batches:            List of batch dicts from the manifest.
        unit_lookup:        {unit_id: preprocessed_unit} mapping.
        global_context:     Global context dict (glossary, tone, etc.).
        provider_callable:  The provider's translate_text / call_ai method.
        prompt_builder:     Callable(clean_text, bundle, unit, global_context) -> str.
        max_workers:        Max concurrent threads.

    Returns:
        (True, [result_dicts]) on full success.
        (False, error_dict)    on first failure.
    """
    # Flatten batches → individual work items, preserving order
    work_items: List[Dict[str, Any]] = []

    for batch in batches:
        batch_unit_ids = batch.get("unit_ids", [])
        bundle         = batch.get("context_bundle", {})

        for unit_id in batch_unit_ids:
            original_unit = _resolve_unit(unit_id, unit_lookup)
            if not original_unit:
                return False, {
                    "message": f"Unit ID {unit_id} not found in preprocessing context.",
                    "code":    "MISSING_UNIT_CONTEXT",
                }

            # For split parts, the clean_text must come from the semantic chunker
            # output (stored in the chunk manifest), not the full original unit.
            # chunk_builder stores split text via split_unit_semantically which
            # sets clean_text on the sub-unit — but the manifest only stores unit_ids.
            # So we reconstruct: if this is a split part, the batch's context_bundle
            # was built from the split sub-unit which had the correct partial text.
            # The original_unit here is only used for metadata/context — we use
            # whatever clean_text it has unless it's a split part.
            if "_part" in unit_id and unit_id not in unit_lookup:
                # This is a split part — clean_text from original would be the full
                # chapter. We need the partial text. It's embedded in the batch
                # manifest's split_texts if present, otherwise fall back to original.
                split_texts = batch.get("split_texts", {})
                clean_text = split_texts.get(unit_id) or original_unit.get("clean_text", "")
            else:
                clean_text = original_unit.get("clean_text", "")

            if not clean_text or not clean_text.strip():
                return False, {
                    "message": f"Unit {unit_id} has empty clean_text.",
                    "code":    "EMPTY_CLEAN_TEXT",
                }

            work_items.append({
                "unit_id":       unit_id,
                "clean_text":    clean_text,
                "bundle":        bundle,
                "original_unit": original_unit,
                "metadata":      original_unit.get("metadata", {}),
            })

    if not work_items:
        return False, {"message": "No work items after flattening batches.", "code": "NO_WORK_ITEMS"}

    # Worker function executed per unit
    def _translate_unit(item: Dict[str, Any]) -> Tuple[bool, Any]:
        unit_id    = item["unit_id"]
        clean_text = item["clean_text"]
        bundle     = item["bundle"]
        orig_unit  = item["original_unit"]

        # Phase 1: Strategy + prompt
        strategy = evaluate_translation_strategy(orig_unit, global_context)
        try:
            prompt = prompt_builder(clean_text, bundle, orig_unit, global_context)
        except Exception as e:
            logger.error(f"Prompt build failed for unit {unit_id}: {e}")
            return False, {
                "message": f"Prompt construction failed for {unit_id}: {e}",
                "code":    "PROMPT_BUILD_FAILURE",
            }

        # Phase 2: Provider dispatch with throughput control + retry
        try:
            translated_text = execute_with_throughput_control(
                lambda: provider_callable(prompt)
            )
        except ResilienceFailure as rf:
            return False, {
                "message": f"Provider resilience exhausted for {unit_id}: {rf}",
                "code":    f"PROVIDER_{rf.category.upper()}",
            }
        except Exception as e:
            return False, {
                "message": f"Provider call failed for {unit_id}: {e}",
                "code":    "PROVIDER_CALL_FAILURE",
            }

        # Phase 3: Validate output
        is_valid, err_msg = _validate_translation_output(
            translated_text, clean_text, unit_id
        )
        if not is_valid:
            return False, {"message": err_msg, "code": "VALIDATION_FAILURE"}

        return True, {
            "unit_id":         unit_id,
            "translated_text": translated_text,
            "strategy":        strategy,
            "metadata":        item["metadata"],
        }

    return execute_concurrently(work_items, _translate_unit, max_workers)