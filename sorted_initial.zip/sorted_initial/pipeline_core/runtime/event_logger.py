import json
import os
from datetime import datetime
from typing import Dict, Any

class EventLogger:
    """Append-only structured event log ensuring secure pipeline observability and metrics tracing."""
    def __init__(self, run_dir: str):
        self.log_dir = os.path.join(run_dir, "logs")
        os.makedirs(self.log_dir, exist_ok=True)
        self.log_path = os.path.join(self.log_dir, "events.jsonl")

    def log_event(self, event_type: str, payload: Dict[str, Any] = None):
        event = {
            "timestamp": datetime.now().isoformat(),
            "event_type": event_type,
            "payload": payload or {}
        }
        with open(self.log_path, 'a', encoding='utf-8') as f:
            f.write(json.dumps(event) + '\n')
