import concurrent.futures
from typing import Callable, List, TypeVar, Tuple, Any

T = TypeVar('T')

def execute_concurrently(items: List[T], worker_fn: Callable[[T], Tuple[bool, Any]], max_workers: int = 2) -> Tuple[bool, Any]:
    """
    Executes a bounded worker pool over a sequence of items, halting cleanly on first failure natively.
    Preserves absolute ordering of successful results.
    `worker_fn` must return a Tuple[bool, result_or_error_dict].
    """
    if not items:
        return True, []
        
    results: List[Any] = [None] * len(items)
    
    with concurrent.futures.ThreadPoolExecutor(max_workers=max_workers) as executor:
        # Submit all futures mapping sequentially to their native index structure
        future_to_index = {
            executor.submit(worker_fn, item): idx 
            for idx, item in enumerate(items)
        }
        
        for future in concurrent.futures.as_completed(future_to_index):
            idx = future_to_index[future]
            try:
                success, payload = future.result()
                if not success:
                    # Cancel pending futures cleanly and structurally halt constraints
                    executor.shutdown(wait=False, cancel_futures=True)
                    return False, payload
                results[idx] = payload
            except Exception as e:
                executor.shutdown(wait=False, cancel_futures=True)
                return False, {"message": f"Unhandled worker thread crash: {str(e)}", "code": "WORKER_CRASH"}
                
    return True, results
