import json
import os
from datetime import datetime
from typing import Optional, Dict, Any

from ..core.models import PipelineJob, StageType


def _checkpoint_path(working_dir: str) -> str:
    return os.path.join(working_dir, "checkpoint.json")


def save_checkpoint(
    job: PipelineJob,
    last_completed_stage: StageType,
    artifact_path: Optional[str]
) -> None:
    """
    Persists the current pipeline checkpoint to disk after each successful stage.
    Overwrites the previous checkpoint atomically.
    """
    data: Dict[str, Any] = {
        "job_id": job.job_id,
        "last_completed_stage": last_completed_stage.name,
        "artifact_path": artifact_path,
        "job_status": job.status.name,
        "final_output_path": job.final_output_path,
        "timestamp": datetime.now().isoformat()
    }

    path = _checkpoint_path(job.working_dir)
    # Write to a temp file then rename for atomicity on supported filesystems
    tmp_path = path + ".tmp"
    with open(tmp_path, "w", encoding="utf-8") as f:
        json.dump(data, f, indent=2)
    os.replace(tmp_path, path)


def load_checkpoint(job_working_dir: str) -> Optional[Dict[str, Any]]:
    """
    Loads an existing checkpoint from disk. Returns None if no checkpoint exists
    or the file is corrupt/unreadable.
    """
    path = _checkpoint_path(job_working_dir)
    if not os.path.exists(path):
        return None

    try:
        with open(path, "r", encoding="utf-8") as f:
            return json.load(f)
    except (json.JSONDecodeError, OSError):
        return None
