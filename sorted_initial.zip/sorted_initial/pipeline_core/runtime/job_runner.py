from typing import TYPE_CHECKING
from ..core.models import PipelineJob, JobStatus
from .event_logger import EventLogger
from .checkpoint_store import load_checkpoint
from .resume_manager import get_resume_state

if TYPE_CHECKING:
    from ..core.orchestrator import Orchestrator

class JobRunner:
    """Outer shell wrapper managing pipeline execution with checkpoint-aware resume support."""

    def __init__(self, orchestrator: "Orchestrator"):
        self.orchestrator = orchestrator

    def run(self, job: PipelineJob):
        logger = EventLogger(job.working_dir)

        # Detect existing checkpoint and log accordingly
        checkpoint = load_checkpoint(job.working_dir)
        if checkpoint:
            logger.log_event("job_resuming", {
                "job_id": job.job_id,
                "last_completed_stage": checkpoint.get("last_completed_stage"),
                "artifact_path": checkpoint.get("artifact_path")
            })
        else:
            logger.log_event("job_started", {"job_id": job.job_id})

        try:
            self.orchestrator.run_pipeline(job)

            if job.status == JobStatus.COMPLETED:
                logger.log_event("job_completed", {
                    "job_id": job.job_id,
                    "final_output": job.final_output_path
                })
            elif job.status == JobStatus.CANCELLED:
                logger.log_event("job_cancelled", {"job_id": job.job_id})
            elif job.status == JobStatus.FAILED:
                logger.log_event("job_failed", {
                    "job_id": job.job_id,
                    "error": job.error_message
                })
        except Exception as e:
            job.status = JobStatus.FAILED
            job.error_message = str(e)
            logger.log_event("job_crashed", {"job_id": job.job_id, "error": str(e)})
