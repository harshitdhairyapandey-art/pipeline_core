from typing import Dict, Any, List, Optional

from ..core.models import PipelineJob, StageType
from .checkpoint_store import load_checkpoint


def get_resume_state(job: PipelineJob, stages: list) -> Dict[str, Any]:
    """
    Determines whether an existing checkpoint allows resuming from a mid-pipeline stage.

    Returns:
        {
            "resume": bool,
            "start_index": int,         # index into stages list to start execution from
            "artifact_path": str | None # artifact to feed into the first resumed stage
        }
    If no checkpoint → start from the beginning (start_index=0).
    If all stages already completed → marks as already done.
    """
    checkpoint = load_checkpoint(job.working_dir)

    # No checkpoint — fresh run
    if not checkpoint:
        return {"resume": False, "start_index": 0, "artifact_path": job.source_path}

    last_stage_name: Optional[str] = checkpoint.get("last_completed_stage")
    artifact_path: Optional[str] = checkpoint.get("artifact_path")

    # Resolve last completed stage to an index in the current stage list
    stage_names: List[str] = [s.stage_type.name for s in stages]

    if last_stage_name not in stage_names:
        # Checkpoint references a stage not in this stage list — treat as fresh
        return {"resume": False, "start_index": 0, "artifact_path": job.source_path}

    last_index = stage_names.index(last_stage_name)
    next_index = last_index + 1

    # All stages completed — job is already done
    if next_index >= len(stages):
        return {"resume": True, "start_index": len(stages), "artifact_path": artifact_path}

    return {
        "resume": True,
        "start_index": next_index,
        "artifact_path": artifact_path
    }
