from typing import Dict, Any

def get_polishing_sampling_config(unit: Dict[str, Any]) -> dict:
    """
    Returns adaptive full sampling config based on chapter emotional content.
    Migrated from LexiFlow pro.py get_polish_sampling() — includes min_p for
    compatible models, frequency/presence penalty for vocabulary diversity.
    """
    analysis = unit.get("analysis", {})
    tone = analysis.get("tone", "").lower()

    # Emotional Resonance Detection (migrated from LexiFlow)
    high_creative = ("grief", "horror", "melancholic", "tragic", "resolution", "sadness", "nostalgia", "resignation", "dread")
    high_control  = ("action", "climax", "tension", "neutral", "focus", "trepidation", "anxiety")

    if tone in high_creative:
        # Grief/horror: wide creative pool, strong repetition penalty
        # Forces model to reach for elegant synonyms rather than generic words
        return {
            "temperature":       0.75,
            "min_p":             0.05,    # adaptive wide pool — best for creative chapters
            "top_p":             0.90,    # fallback if min_p unsupported
            "frequency_penalty": 0.45,    # strongly punish repeated words
            "presence_penalty":  0.30,    # force vocabulary diversity across whole output
        }
    elif tone in high_control:
        # Action/technical: controlled precision, moderate repetition OK
        return {
            "temperature":       0.45,
            "min_p":             0.10,    # tighter pool for precise action writing
            "top_p":             0.85,
            "frequency_penalty": 0.15,    # light penalty — action needs some repetition
            "presence_penalty":  0.10,
        }
    else:
        # Standard chapters: balanced creativity and discipline
        return {
            "temperature":       0.65,
            "min_p":             0.07,
            "top_p":             0.88,
            "frequency_penalty": 0.30,
            "presence_penalty":  0.20,
        }
