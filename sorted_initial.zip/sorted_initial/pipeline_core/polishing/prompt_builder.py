from typing import Dict, Any

def build_polishing_prompt(raw_hindi_text: str, unit: Dict[str, Any], global_context: Dict[str, Any]) -> str:
    """
    Constructs the V2 "LexiFlow Pro" context-aware polish prompt.
    Migrated from LexiFlow pro.py build_pro_prompt() with full editorial freedom
    and PRO_MANDATE_ADDITIONS from prompts.py.
    """
    helpful = unit.get("helpful_context", {})
    critical = unit.get("critical_context", {})

    # Preprocessing Signals
    has_dialogue = helpful.get("voice_context", {}).get("dialogue_density", "low") in ("medium", "high")
    scene_type = unit.get("analysis", {}).get("scene_type", "narrative")
    tone_hint = critical.get("tone_hint") or global_context.get("global_tone", "neutral")

    prompt_lines = [
        "You are a senior Hindi literary editor. You have received a first-draft translation of a novel chapter.",
        "Your job is to make this read like it was originally written in Hindi — not translated from English.",
        "You have full editorial freedom. Rewrite freely. The only things locked are meaning and proper nouns.",
        "",
        "EDITORIAL MANDATE (V2 GOLD STANDARD):",
        "- DIALOGUE NATURALIZATION (High Priority): Every dialogue line must sound like a real person speaking Hindi. (e.g., 'पहचाना मुझे?' instead of 'क्या तुम्हें मैं याद हूँ?')",
        "- SOV WORD ORDER: Rephrase sentences to ensure native Hindi Subject-Object-Verb syntax. Remove awkward English syntax bleed.",
        "- STRUCTURAL RHYTHM:",
        "  * Action scenes: Use short, sharp sentences and active verbs. Avoid passive voice.",
        "  * Emotional scenes: Use medium-length sentences to give the emotion breathing room.",
        "  * Philosophical/Ritualistic: Longer, elegant sentences are allowed but must remain readable.",
        "- WORLD-BUILDING: Ensure technical or magic system terms flow naturally like literature, not a mechanical wiki.",
        "- TRUST THE READER: Do NOT add interpretative meaning, preambles, or embellishments beyond the source intent.",
        "- YOUR ONLY CONSTRAINTS: All plot facts and meaning must be fully preserved. Proper nouns in the glossary stay exactly as listed.",
    ]

    # Volume flow context
    volume_flow = global_context.get("volume_flow", {})
    if volume_flow:
        arc = volume_flow.get("dominant_arc", "")
        if arc:
            prompt_lines.append(f"- VOLUME ARC: {arc}")

    # Scene-specific polish policy (migrated from build_pro_prompt)
    if scene_type in ("action", "climax"):
        prompt_lines.append("- SCENE POLICY: ACTION-ORIENTED. Prioritize physical verbs and rapid pacing.")
    elif scene_type in ("grief", "melancholic", "horror"):
        prompt_lines.append("- SCENE POLICY: ATMOSPHERIC. Fully utilize the expressive depth of Hindi literary tradition for emotional resonance.")
    elif scene_type in ("ritual", "philosophical"):
        prompt_lines.append("- SCENE POLICY: CLASSICAL. Longer, elegant sentences allowed. Maintain ceremonial register.")

    # Tone and Style
    if tone_hint:
        prompt_lines.append(f"- TONE AND STYLE: {tone_hint}")

    # Locked Glossary (proper nouns)
    glossary_map = global_context.get("glossary_map", {})
    locked_terms = []
    for term, instruction in glossary_map.items():
        if isinstance(instruction, dict):
            deva = instruction.get("devanagari") or instruction.get("suggested_rendering", "")
            action = instruction.get("recommended_action", "")
        else:
            deva = instruction
            action = ""
        if deva and not deva.startswith("["):
            locked_terms.append((term, deva))

    if locked_terms:
        prompt_lines.append("- LOCKED PROPER NOUNS (Never change these Devanagari spellings):")
        for term, deva in locked_terms:
            prompt_lines.append(f"  * {term} -> {deva}")

    # Character Address registers (Aap/Tum/Tu)
    if helpful.get("address_hierarchy"):
        address_hints = helpful.get("address_hierarchy", [])
        if address_hints:
            prompt_lines.append("- CHARACTER ADDRESS FORMS (STRICT ENFORCEMENT):")
            for hint in address_hints:
                char = hint.get('character_or_role', 'Unknown')
                reg = hint.get('suggested_register', 'neutral')
                form_hindi = {"tu": "तू (intimate/contemptuous)", "tum": "तुम (familiar)", "aap": "आप (formal/respectful)"}.get(reg, reg)
                prompt_lines.append(f"  * {char}: Maintain the '{form_hindi}' register strictly in dialogue.")

    # Character Voices
    voice_ctx = helpful.get("voice_context", {})
    if voice_ctx.get("voice_profile"):
        profile = voice_ctx.get("voice_profile", [{}])[0]
        style = profile.get("voice_style", "")
        if style:
            prompt_lines.append(f"- CHARACTER VOICE PROFILE: {style}")

    # Flow Context
    flow_ctx = helpful.get("flow_context", {})
    if flow_ctx.get("narrative_position"):
        prompt_lines.append(f"- NARRATIVE POSITION: {flow_ctx['narrative_position']}")

    # Emotional context (migrated from build_pro_prompt)
    emotion_timeline = critical.get("emotion_timeline", [])
    if emotion_timeline:
        prompt_lines.append(f"- EMOTIONAL ARC: {' → '.join(emotion_timeline)}")
        prompt_lines.append("  Your vocabulary, rhythm and sentence structure should embody this arc completely.")

    prompt_lines.append(f"\nRAW TEXT TO POLISH:\n{raw_hindi_text}")
    prompt_lines.append("\nOutput ONLY the final polished Hindi text.")

    # Append PRO_MANDATE_ADDITIONS from prompts.py
    try:
        from ..prompts import PRO_MANDATE_ADDITIONS
        if PRO_MANDATE_ADDITIONS:
            prompt_lines.append(PRO_MANDATE_ADDITIONS)
    except ImportError:
        pass

    return "\n".join(prompt_lines)
