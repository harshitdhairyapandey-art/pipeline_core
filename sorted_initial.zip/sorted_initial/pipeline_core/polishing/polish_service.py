"""
pipeline_core/polishing/polish_service.py
==========================================
Polish service — executes the polishing pass per translated unit.

Polishing is a light literary rewrite for flow, dialogue naturalisation,
and style. It does NOT rewrite meaning. Heavy critic-loop work happens
in postprocessing.
"""
import logging
from typing import Dict, Any, Tuple, List

from ..providers.scitely_provider import ScitelyProvider
from ..resilience.throughput_controller import execute_with_throughput_control
from ..resilience.fallback_policy import ResilienceFailure
from .prompt_builder import build_polishing_prompt
from .sampling_policy import get_polishing_sampling_config
from ..runtime.concurrent_executor import execute_concurrently

logger = logging.getLogger(__name__)


def polish_units(
    translated_units: List[Dict[str, Any]],
    unit_lookup:      Dict[str, Any],
    global_context:   Dict[str, Any],
    provider:         ScitelyProvider,
    max_workers:      int = 2,
) -> Tuple[bool, Any]:
    """
    Polish all translated units concurrently.

    Returns:
        (True, [polished_unit_dicts]) on success.
        (False, error_dict)           on first failure.
    """

    def _polish_unit(trans_unit: Dict[str, Any]) -> Tuple[bool, Any]:
        unit_id        = trans_unit.get("unit_id")
        raw_hindi_text = trans_unit.get("translated_text", "")

        # --- Resolve preprocessing context ---
        original_unit = unit_lookup.get(unit_id)
        if not original_unit:
            logger.warning(f"Polishing: no preprocessing context for unit {unit_id} — using empty context.")
            original_unit = {}

        if not raw_hindi_text or not raw_hindi_text.strip():
            return False, {
                "message": f"Polishing unit {unit_id} has no translated_text.",
                "code":    "EMPTY_INPUT_TEXT",
            }

        # --- Build prompt ---
        try:
            prompt = build_polishing_prompt(raw_hindi_text, original_unit, global_context)
        except Exception as e:
            logger.error(f"Polish prompt build failed for {unit_id}: {e}")
            return False, {
                "message": f"Polish prompt build failed for {unit_id}: {e}",
                "code":    "PROMPT_BUILD_FAILURE",
            }

        # --- Resolve adaptive sampling ---
        sampling_params = get_polishing_sampling_config(original_unit)

        # --- Provider call with throughput control ---
        try:
            polished_text = execute_with_throughput_control(
                lambda: provider.call_ai(
                    # The prompt IS the system prompt; user content is the raw text
                    prompt,
                    raw_hindi_text,
                    temperature=sampling_params.pop("temperature", 0.65),
                    sampling_params=sampling_params,
                )
            )
        except ResilienceFailure as rf:
            return False, {
                "message": str(rf),
                "code":    f"PROVIDER_{rf.category.upper()}",
            }
        except Exception as e:
            return False, {
                "message": f"Provider call failed for unit {unit_id}: {e}",
                "code":    "PROVIDER_CALL_FAILURE",
            }

        if not polished_text or not polished_text.strip():
            return False, {
                "message": f"Provider returned empty polish for unit {unit_id}.",
                "code":    "EMPTY_PROVIDER_RESPONSE",
            }

        return True, {
            "unit_id":          unit_id,
            "polished_text":    polished_text,
            "sampling_applied": sampling_params,
            "metadata":         trans_unit.get("metadata", {}),
        }

    return execute_concurrently(translated_units, _polish_unit, max_workers)
