"""
pipeline_core/tests/test_chunk_quality.py
==========================================
Tests for chunk quality validation rules.
"""
import unittest

from pipeline_core.translation.chunk_quality_rules import validate_chunk, validate_all_chunks


def _make_bundle(
    prev_tail: str = "",
    terms: list = None,
    split_warning: bool = False,
) -> dict:
    return {
        "previous_unit_tail":     prev_tail,
        "critical_terms":         terms or [],
        "global_glossary_keys":   terms or [],
        "split_warning":          split_warning,
        "address_hierarchy_slice": [],
        "voice_hints":            "",
    }


class TestValidateChunk(unittest.TestCase):

    def test_clean_chunk_no_warnings(self):
        text    = "यह एक सामान्य हिंदी अनुच्छेद है। " * 10   # ~400 chars
        bundle  = _make_bundle(terms=["Arjun", "Karma"])
        warnings = validate_chunk(text, bundle)
        self.assertEqual(warnings, [])

    def test_too_short_chunk_warns(self):
        text    = "Short."
        bundle  = _make_bundle(terms=["Term"])
        warnings = validate_chunk(text, bundle)
        self.assertTrue(any("TOO_SHORT" in w for w in warnings))

    def test_exceeds_hard_limit_warns(self):
        text    = "X " * 1700   # 3400 chars > 3200 hard limit
        bundle  = _make_bundle(terms=["Term"])
        warnings = validate_chunk(text, bundle)
        self.assertTrue(any("HARD_LIMIT" in w for w in warnings))

    def test_approaching_soft_limit_warns(self):
        text    = "X " * 1430   # 2860 chars — above 2800 soft warn
        bundle  = _make_bundle(terms=["Term"])
        warnings = validate_chunk(text, bundle)
        self.assertTrue(any("NEAR_LIMIT" in w for w in warnings))

    def test_mid_dialogue_split_warns(self):
        # Text ending with unclosed quote
        text    = 'उसने कहा, "मैं वहाँ जाऊँगा'
        bundle  = _make_bundle(terms=["Term"])
        warnings = validate_chunk(text, bundle)
        self.assertTrue(any("MID_DIALOGUE" in w for w in warnings))

    def test_split_without_carryover_warns(self):
        text    = "Normal text here. " * 20
        bundle  = _make_bundle(prev_tail="short", split_warning=True, terms=["Term"])
        warnings = validate_chunk(text, bundle, is_split=True)
        self.assertTrue(any("CARRYOVER" in w for w in warnings))

    def test_split_with_adequate_carryover_no_warn(self):
        text    = "Normal text here. " * 20
        tail    = "Long tail context. " * 20   # > 200 chars
        bundle  = _make_bundle(prev_tail=tail, split_warning=True, terms=["Term"])
        warnings = validate_chunk(text, bundle, is_split=True)
        self.assertFalse(any("CARRYOVER" in w for w in warnings))

    def test_no_glossary_warns(self):
        text    = "Normal text here. " * 20
        bundle  = _make_bundle(terms=[])   # no glossary
        warnings = validate_chunk(text, bundle)
        self.assertTrue(any("GLOSSARY" in w for w in warnings))


class TestValidateAllChunks(unittest.TestCase):

    def test_returns_only_problematic_chunks(self):
        chunks = [
            {
                "batch_id":      "job1_batch_0001",
                "estimated_chars": 500,   # fine
                "context_bundle": _make_bundle(terms=["X"]),
            },
            {
                "batch_id":      "job1_batch_0002",
                "estimated_chars": 10,    # too short
                "context_bundle": _make_bundle(terms=["X"]),
            },
        ]
        issues = validate_all_chunks(chunks)
        self.assertNotIn("job1_batch_0001", issues)
        self.assertIn("job1_batch_0002", issues)

    def test_empty_chunks_returns_empty_dict(self):
        self.assertEqual(validate_all_chunks([]), {})


if __name__ == "__main__":
    unittest.main()
