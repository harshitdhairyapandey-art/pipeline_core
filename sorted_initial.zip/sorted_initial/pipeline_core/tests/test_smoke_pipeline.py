import os
import json
import tempfile
import unittest

from pipeline_core.core.models import PipelineJob, JobStatus, StageType
from pipeline_core.core.orchestrator import Orchestrator

from pipeline_core.stages import (
    IngestionStage,
    PreprocessingStage,
    BatchPlanningStage,
    TranslationStage,
    PostprocessingStage,
    ExportStage
)

class TestSmokePipeline(unittest.TestCase):
    def test_pipeline_smoke(self):
        with tempfile.TemporaryDirectory() as temp_dir:
            # 1. Setup sample input file
            sample_text = (
                "Chapter 1\n"
                "This is the first sentence. This is the second sentence.\n\n"
                "Chapter 2\n"
                "Another chapter starts here. Multiple lines of text.\n\n"
                "This is a separate section in chapter 2."
            )
            
            source_path = os.path.join(temp_dir, "sample.txt")
            with open(source_path, 'w', encoding='utf-8') as f:
                f.write(sample_text)
                
            # 2. Instantiate pipeline stages
            stages = [
                IngestionStage(),
                PreprocessingStage(),
                BatchPlanningStage(),
                TranslationStage(),
                PostprocessingStage(),
                ExportStage()
            ]
            
            orchestrator = Orchestrator(stages)
            
            # 3. Create PipelineJob
            job = PipelineJob(
                job_id="smoke_test_job_001",
                status=JobStatus.PENDING,
                source_path=source_path,
                working_dir=temp_dir
            )
            
            # 4. Run orchestrator
            orchestrator.run_pipeline(job)
            
            # 5. Assertions
            # Status check
            self.assertEqual(job.status, JobStatus.COMPLETED, f"Job failed with error: {job.error_message}")
            
            # Output check
            self.assertIsNotNone(job.final_output_path)
            self.assertTrue(os.path.exists(job.final_output_path))
            self.assertTrue(job.final_output_path.endswith("exported_output.txt"), f"Expected exported_output.txt, got {job.final_output_path}")
            
            # Verify specific execution traces
            self.assertIn(StageType.INGESTION, job.stage_results)
            self.assertIn(StageType.PREPROCESSING, job.stage_results)
            self.assertIn(StageType.BATCH_PLANNING, job.stage_results)
            self.assertIn(StageType.TRANSLATION, job.stage_results)
            self.assertIn(StageType.POSTPROCESSING, job.stage_results)
            self.assertIn(StageType.EXPORT, job.stage_results)
            
            # Verify the resulting text file contents
            with open(job.final_output_path, 'r', encoding='utf-8') as f:
                final_text = f.read()
                
            self.assertTrue(len(final_text) > 0, "No text generated in final output.")
            
            # Verify translation payload mutation cleanly mapped through
            self.assertIn("[TRANSLATED]", final_text)

if __name__ == '__main__':
    unittest.main()
