"""
pipeline_core/tests/test_resume_checkpoint.py
===============================================
Tests for checkpoint writing and resume logic.
"""
import json
import os
import tempfile
import unittest

from pipeline_core.core.models import (
    PipelineJob, JobStatus, StageType, JobConfig,
)
from pipeline_core.runtime.checkpoint_store import save_checkpoint, load_checkpoint
from pipeline_core.runtime.resume_manager import get_resume_state


def _make_job(working_dir: str) -> PipelineJob:
    return PipelineJob(
        job_id      = "test_resume_001",
        status      = JobStatus.PENDING,
        source_path = os.path.join(working_dir, "input.txt"),
        working_dir = working_dir,
    )


# Minimal stage stub
class _FakeStage:
    def __init__(self, stage_type: StageType):
        self._stage_type = stage_type

    @property
    def stage_type(self) -> StageType:
        return self._stage_type


class TestCheckpointStore(unittest.TestCase):

    def test_save_and_load(self):
        with tempfile.TemporaryDirectory() as tmp:
            job = _make_job(tmp)
            save_checkpoint(job, StageType.INGESTION, "/some/artifact.json")

            data = load_checkpoint(tmp)
            self.assertIsNotNone(data)
            self.assertEqual(data["job_id"], "test_resume_001")
            self.assertEqual(data["last_completed_stage"], "INGESTION")
            self.assertEqual(data["artifact_path"], "/some/artifact.json")

    def test_load_nonexistent_returns_none(self):
        with tempfile.TemporaryDirectory() as tmp:
            self.assertIsNone(load_checkpoint(tmp))

    def test_overwrite_is_atomic(self):
        """Second save overwrites first; no corrupt intermediate state."""
        with tempfile.TemporaryDirectory() as tmp:
            job = _make_job(tmp)
            save_checkpoint(job, StageType.INGESTION, "/first.json")
            save_checkpoint(job, StageType.PREPROCESSING, "/second.json")

            data = load_checkpoint(tmp)
            self.assertEqual(data["last_completed_stage"], "PREPROCESSING")
            self.assertEqual(data["artifact_path"], "/second.json")

    def test_corrupt_checkpoint_returns_none(self):
        with tempfile.TemporaryDirectory() as tmp:
            cp_path = os.path.join(tmp, "checkpoint.json")
            with open(cp_path, "w") as f:
                f.write("{this is not valid json}")
            self.assertIsNone(load_checkpoint(tmp))


class TestResumeManager(unittest.TestCase):

    def setUp(self):
        self.stages = [
            _FakeStage(StageType.INGESTION),
            _FakeStage(StageType.PREPROCESSING),
            _FakeStage(StageType.BATCH_PLANNING),
            _FakeStage(StageType.TRANSLATION),
            _FakeStage(StageType.POLISHING),
            _FakeStage(StageType.POSTPROCESSING),
            _FakeStage(StageType.PUBLISHING),
            _FakeStage(StageType.EXPORT),
        ]

    def test_no_checkpoint_starts_from_zero(self):
        with tempfile.TemporaryDirectory() as tmp:
            job   = _make_job(tmp)
            state = get_resume_state(job, self.stages)
            self.assertFalse(state["resume"])
            self.assertEqual(state["start_index"], 0)

    def test_resume_starts_after_last_completed(self):
        with tempfile.TemporaryDirectory() as tmp:
            job = _make_job(tmp)
            save_checkpoint(job, StageType.PREPROCESSING, "/preproc.json")

            state = get_resume_state(job, self.stages)
            self.assertTrue(state["resume"])
            # Should start at BATCH_PLANNING (index 2)
            self.assertEqual(state["start_index"], 2)
            self.assertEqual(state["artifact_path"], "/preproc.json")

    def test_resume_after_last_stage_marks_complete(self):
        with tempfile.TemporaryDirectory() as tmp:
            job = _make_job(tmp)
            save_checkpoint(job, StageType.EXPORT, "/final.txt")

            state = get_resume_state(job, self.stages)
            self.assertTrue(state["resume"])
            self.assertEqual(state["start_index"], len(self.stages))

    def test_unknown_checkpoint_stage_starts_fresh(self):
        with tempfile.TemporaryDirectory() as tmp:
            job     = _make_job(tmp)
            cp_path = os.path.join(tmp, "checkpoint.json")
            with open(cp_path, "w") as f:
                json.dump({
                    "job_id": job.job_id,
                    "last_completed_stage": "DOES_NOT_EXIST",
                    "artifact_path": "/some/path.json",
                }, f)

            state = get_resume_state(job, self.stages)
            self.assertFalse(state["resume"])
            self.assertEqual(state["start_index"], 0)

    def test_no_duplicate_stage_rerun(self):
        """
        After checkpoint at TRANSLATION, orchestrator must NOT rerun
        INGESTION, PREPROCESSING, or BATCH_PLANNING.
        """
        with tempfile.TemporaryDirectory() as tmp:
            job   = _make_job(tmp)
            save_checkpoint(job, StageType.TRANSLATION, "/trans.json")
            state = get_resume_state(job, self.stages)

            resume_start = state["start_index"]
            already_done = [s.stage_type.name for s in self.stages[:resume_start]]
            self.assertIn("INGESTION",     already_done)
            self.assertIn("PREPROCESSING", already_done)
            self.assertIn("TRANSLATION",   already_done)

            next_stage = self.stages[resume_start].stage_type.name
            self.assertEqual(next_stage, "POLISHING")


if __name__ == "__main__":
    unittest.main()
