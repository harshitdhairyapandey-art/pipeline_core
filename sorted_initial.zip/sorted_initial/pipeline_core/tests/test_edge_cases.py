import os
import json
import tempfile
import unittest

from pipeline_core.core.models import PipelineJob, JobStatus, StageType
from pipeline_core.core.orchestrator import Orchestrator

from pipeline_core.stages import (
    IngestionStage,
    PreprocessingStage
)

class TestEdgeCases(unittest.TestCase):
    def test_empty_input_file(self):
        """Empty input file should fail at ingestion stage cleanly."""
        with tempfile.TemporaryDirectory() as temp_dir:
            source_path = os.path.join(temp_dir, "empty.txt")
            with open(source_path, 'w', encoding='utf-8') as f:
                f.write("")
                
            orchestrator = Orchestrator([IngestionStage()])
            job = PipelineJob(
                job_id="edge_empty_001",
                status=JobStatus.PENDING,
                source_path=source_path,
                working_dir=temp_dir
            )
            
            orchestrator.run_pipeline(job)
            
            self.assertEqual(job.status, JobStatus.FAILED)
            self.assertEqual(job.stage_results[StageType.INGESTION].error_code, "EMPTY_CONTENT")

    def test_corrupted_json(self):
        """A corrupted intermediate JSON artifact should fail gracefully."""
        with tempfile.TemporaryDirectory() as temp_dir:
            corrupt_path = os.path.join(temp_dir, "corrupt.json")
            with open(corrupt_path, 'w', encoding='utf-8') as f:
                f.write('{"units": [{unclosed_brace')
                
            orchestrator = Orchestrator([PreprocessingStage()])
            job = PipelineJob(
                job_id="edge_corrupt_001",
                status=JobStatus.PENDING,
                source_path=corrupt_path,
                working_dir=temp_dir
            )
            
            orchestrator.run_pipeline(job)
            
            self.assertEqual(job.status, JobStatus.FAILED)
            self.assertEqual(job.stage_results[StageType.PREPROCESSING].error_code, "INVALID_JSON")

    def test_missing_artifact(self):
        """A missing artifact dependency should instantly halt the pipeline."""
        with tempfile.TemporaryDirectory() as temp_dir:
            missing_path = os.path.join(temp_dir, "does_not_exist.json")
                
            orchestrator = Orchestrator([PreprocessingStage()])
            job = PipelineJob(
                job_id="edge_missing_001",
                status=JobStatus.PENDING,
                source_path=missing_path,
                working_dir=temp_dir
            )
            
            orchestrator.run_pipeline(job)
            
            self.assertEqual(job.status, JobStatus.FAILED)
            self.assertEqual(job.stage_results[StageType.PREPROCESSING].error_code, "ARTIFACT_NOT_FOUND")

    def test_unit_with_empty_text(self):
        """Units missing text logic should be structurally skipped and tracked without crashing."""
        with tempfile.TemporaryDirectory() as temp_dir:
            source_path = os.path.join(temp_dir, "input.json")
            payload = {
                "source_file": "input.txt",
                "units": [
                    {
                        "unit_id": "valid_1",
                        "display_order": 1,
                        "text": "Valid text block."
                    },
                    {
                        "unit_id": "invalid_1",
                        "display_order": 2,
                        "text": None # Missing raw_text payload
                    }
                ]
            }
            with open(source_path, 'w', encoding='utf-8') as f:
                json.dump(payload, f)
                
            orchestrator = Orchestrator([PreprocessingStage()])
            job = PipelineJob(
                job_id="edge_empty_unit_001",
                status=JobStatus.PENDING,
                source_path=source_path,
                working_dir=temp_dir
            )
            
            orchestrator.run_pipeline(job)
            
            self.assertEqual(job.status, JobStatus.COMPLETED)
            
            # Verify the invalid unit was skipped and tracked
            metrics = job.stage_results[StageType.PREPROCESSING].metrics
            self.assertEqual(metrics.get("invalid_unit_count"), 1)
            self.assertEqual(metrics.get("unit_count"), 1) # Only one valid unit remains

if __name__ == '__main__':
    unittest.main()
