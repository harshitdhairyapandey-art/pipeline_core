"""
pipeline_core/tests/test_batching_logic.py
============================================
Tests for semantic chunking and batch planning logic.
"""
import unittest

from pipeline_core.translation.provider_profiles import SCITELY_PROFILE, ProviderProfile
from pipeline_core.translation.chunk_builder import build_chunks
from pipeline_core.translation.semantic_chunker import (
    split_text_semantically,
    split_unit_semantically,
)


def _make_unit(uid: str, text: str, order: int = 1) -> dict:
    return {
        "unit_id": uid,
        "display_order": order,
        "kind": "chapter",
        "title": f"Ch {order}",
        "clean_text": text,
        "metadata": {},
        "critical_context": {"critical_terms": [], "tone_hint": "", "chapter_title": ""},
        "helpful_context": {
            "style_notes": [],
            "devanagari_hints": [],
            "address_hierarchy": [],
            "flow_context": {},
            "voice_context": {"dialogue_density": "low", "voice_profile": []},
            "tts_profile": {},
        },
        "analysis": {"scene_type": "narrative", "translation_difficulty": "medium"},
    }


class TestSemanticSplitter(unittest.TestCase):

    def test_no_split_needed(self):
        text   = "Short text."
        result = split_text_semantically(text, max_chars=500)
        self.assertEqual(result, [text])

    def test_splits_within_limit(self):
        para  = "This is a paragraph. " * 20    # ~440 chars
        text  = ("\n\n" + para) * 7             # ~3100 chars
        parts = split_text_semantically(text, max_chars=1000)
        self.assertGreater(len(parts), 1)
        for part in parts:
            self.assertLessEqual(len(part), 1500,
                msg=f"Part too long: {len(part)} chars")

    def test_order_preserved(self):
        paras = [f"Paragraph {i}. " * 10 for i in range(10)]
        text  = "\n\n".join(paras)
        parts = split_text_semantically(text, max_chars=300)
        reconstructed = " ".join(parts)
        for i in range(10):
            self.assertIn(f"Paragraph {i}", reconstructed)

    def test_single_unit_split_preserves_metadata(self):
        text = "X " * 2000    # 4000 chars, exceeds 3200 max
        unit = _make_unit("u1", text, order=1)
        subs = split_unit_semantically(unit, max_chars=3200)
        self.assertGreater(len(subs), 1)
        for sub in subs:
            self.assertEqual(sub["display_order"], 1)
            self.assertIn("_part", sub["unit_id"])
            self.assertTrue(sub.get("_is_split"))


class TestBuildChunksGrouping(unittest.TestCase):

    def test_small_units_grouped_together(self):
        # Each unit ~300 chars; target 2400 → should all fit in one batch
        units  = [_make_unit(f"u{i}", "Hello " * 50, order=i) for i in range(5)]
        chunks = build_chunks("job1", units, SCITELY_PROFILE)
        self.assertEqual(len(chunks), 1)
        self.assertEqual(len(chunks[0]["unit_ids"]), 5)

    def test_large_unit_triggers_split(self):
        big_text = "Word " * 1500    # ~7500 chars >> 3200 max
        units    = [_make_unit("big", big_text, order=1)]
        chunks   = build_chunks("job1", units, SCITELY_PROFILE)
        self.assertGreater(len(chunks), 1)
        for chunk in chunks:
            self.assertLessEqual(chunk["estimated_chars"],
                                 SCITELY_PROFILE.max_chars_per_chunk + 50)

    def test_order_preserved_after_grouping(self):
        units   = [_make_unit(f"u{i}", "Text " * 100, order=i) for i in range(10)]
        profile = ProviderProfile(
            name="test", provider="test", model="m", role="translation",
            max_chars_per_chunk=3200, target_chars_per_chunk=600,
            safe_parallel_requests=1, supports_strict_json=False,
            retry_backoff_seconds=1,
        )
        chunks      = build_chunks("job1", units, profile)
        seen_orders = []
        for chunk in chunks:
            for uid in chunk["unit_ids"]:
                # Find the unit's display_order
                for u in units:
                    if u["unit_id"] == uid or uid.startswith(u["unit_id"]):
                        seen_orders.append(u["display_order"])
                        break
        self.assertEqual(seen_orders, sorted(seen_orders),
            msg="Chunk order is not monotonically increasing")

    def test_end_of_units_split_reason(self):
        units  = [_make_unit("u1", "Hello " * 10, order=1)]
        chunks = build_chunks("job1", units, SCITELY_PROFILE)
        self.assertEqual(chunks[-1]["split_reason"], "end_of_units")


class TestBuildChunksFields(unittest.TestCase):

    def test_chunks_have_required_fields(self):
        units  = [_make_unit(f"u{i}", "Hello world. " * 20, order=i) for i in range(3)]
        chunks = build_chunks("job1", units, SCITELY_PROFILE)
        for chunk in chunks:
            self.assertIn("chunk_id", chunk)
            self.assertIn("unit_ids", chunk)
            self.assertIn("estimated_chars", chunk)
            self.assertIn("context_bundle", chunk)
            self.assertIn("split_reason", chunk)

    def test_all_unit_ids_present(self):
        units     = [_make_unit(f"u{i}", "Hello. " * 30, order=i) for i in range(5)]
        chunks    = build_chunks("job1", units, SCITELY_PROFILE)
        all_ids   = set()
        for chunk in chunks:
            all_ids.update(chunk["unit_ids"])
        for u in units:
            found = any(cid == u["unit_id"] or cid.startswith(u["unit_id"]) for cid in all_ids)
            self.assertTrue(found, f"unit {u['unit_id']} missing from chunks")

    def test_carryover_tail_populated_for_second_chunk(self):
        long_text = "Sentence. " * 300    # ~3000 chars
        units     = [_make_unit("u1", long_text, 1), _make_unit("u2", long_text, 2)]
        profile   = ProviderProfile(
            name="test", provider="test", model="m", role="translation",
            max_chars_per_chunk=3200, target_chars_per_chunk=500,
            safe_parallel_requests=1, supports_strict_json=False,
            retry_backoff_seconds=1,
        )
        chunks = build_chunks("job1", units, profile)
        if len(chunks) > 1:
            tail = chunks[1]["context_bundle"].get("previous_unit_tail", "")
            self.assertGreater(len(tail), 0, "Expected carryover tail in second chunk")


if __name__ == "__main__":
    unittest.main()
