"""
pipeline_core/tests/test_ai_analyst_fallbacks.py
=================================================
Tests that AIAnalyst failures never crash preprocessing and
that safe defaults are returned on any error.
"""
import os
import json
import tempfile
import unittest
from unittest.mock import MagicMock, patch


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _make_mock_provider(side_effect=None, return_value="{}"):
    """Return a mock ScitelyProvider whose call_ai raises or returns as specified."""
    p = MagicMock()
    if side_effect is not None:
        p.call_ai.side_effect = side_effect
    else:
        p.call_ai.return_value = return_value
    return p


# ---------------------------------------------------------------------------
# AIAnalyst unit tests
# ---------------------------------------------------------------------------

class TestAIAnalystFallbacks(unittest.TestCase):

    def setUp(self):
        os.environ.setdefault("SCITELY_API_KEY", "test-key")
        from pipeline_core.preprocessing.ai_analyst import AIAnalyst
        self.AIAnalyst = AIAnalyst

    def test_analyze_chapter_bulk_on_provider_exception(self):
        provider = _make_mock_provider(side_effect=RuntimeError("network down"))
        analyst  = self.AIAnalyst(provider)
        result   = analyst.analyze_chapter_bulk("Some long chapter text here. " * 20)
        self.assertEqual(result, {})

    def test_analyze_chapter_bulk_on_bad_json(self):
        provider = _make_mock_provider(return_value="this is not json { bad")
        analyst  = self.AIAnalyst(provider)
        result   = analyst.analyze_chapter_bulk("Text " * 30)
        self.assertEqual(result, {})

    def test_analyze_chapter_bulk_missing_meta_key(self):
        # Valid JSON but missing 'meta' key — should return {}
        provider = _make_mock_provider(return_value='{"glossary": []}')
        analyst  = self.AIAnalyst(provider)
        result   = analyst.analyze_chapter_bulk("Text " * 30)
        self.assertEqual(result, {})

    def test_generate_devanagari_empty_terms(self):
        provider = _make_mock_provider()
        analyst  = self.AIAnalyst(provider)
        result   = analyst.generate_devanagari([])
        self.assertEqual(result, [])
        provider.call_ai.assert_not_called()

    def test_generate_devanagari_on_exception(self):
        provider = _make_mock_provider(side_effect=ConnectionError("timeout"))
        analyst  = self.AIAnalyst(provider)
        result   = analyst.generate_devanagari(["Arjun", "Krishna"])
        self.assertEqual(result, [])

    def test_generate_devanagari_filters_incomplete_entries(self):
        # One valid, one missing devanagari field
        payload = json.dumps({"translations": [
            {"term": "Arjun", "devanagari": "अर्जुन", "type": "character"},
            {"term": "orphan"},   # missing devanagari
        ]})
        provider = _make_mock_provider(return_value=payload)
        analyst  = self.AIAnalyst(provider)
        result   = analyst.generate_devanagari(["Arjun", "orphan"])
        self.assertEqual(len(result), 1)
        self.assertEqual(result[0]["term"], "Arjun")

    def test_detect_address_hierarchy_on_exception(self):
        provider = _make_mock_provider(side_effect=ValueError("parse fail"))
        analyst  = self.AIAnalyst(provider)
        result   = analyst.detect_address_hierarchy("He said, 'Come here.' " * 20)
        self.assertEqual(result, [])

    def test_build_voice_profiles_on_exception(self):
        provider = _make_mock_provider(side_effect=Exception("boom"))
        analyst  = self.AIAnalyst(provider)
        result   = analyst.build_voice_profiles("Character dialogue " * 30)
        self.assertEqual(result, {})

    def test_build_volume_flow_on_exception(self):
        provider = _make_mock_provider(side_effect=TimeoutError("timed out"))
        analyst  = self.AIAnalyst(provider)
        result   = analyst.build_volume_flow("Story text " * 50)
        self.assertEqual(result, {})

    def test_build_tts_profiles_on_exception(self):
        provider = _make_mock_provider(side_effect=IOError("io error"))
        analyst  = self.AIAnalyst(provider)
        result   = analyst.build_tts_profiles("voice ctx", "Sample text " * 20)
        self.assertEqual(result, {})

    def test_short_text_skips_analyze(self):
        """Text under minimum length should not trigger a provider call."""
        provider = _make_mock_provider()
        analyst  = self.AIAnalyst(provider)
        result   = analyst.analyze_chapter_bulk("Hi")  # too short
        self.assertEqual(result, {})
        provider.call_ai.assert_not_called()


# ---------------------------------------------------------------------------
# Integration: preprocessing assembler does not crash on AI failure
# ---------------------------------------------------------------------------

class TestPreprocessingAssemblerAIFailure(unittest.TestCase):

    def test_assembler_returns_valid_schema_when_ai_fails(self):
        """Assembler must return a valid context bundle even when analyst raises."""
        from pipeline_core.preprocessing.preprocessing_assembler import assemble_context
        from pipeline_core.preprocessing.ai_analyst import AIAnalyst

        # Analyst whose every method raises
        bad_provider = _make_mock_provider(side_effect=RuntimeError("All AI down"))
        analyst = AIAnalyst(bad_provider)

        unit = {
            "unit_id":      "u1",
            "display_order": 1,
            "kind":         "chapter",
            "title":        "Chapter 1",
            "clean_text":   "The hero walked into the forest. " * 30,
            "metadata":     {},
        }

        result = assemble_context(unit, analyst=analyst)

        # Must have the fixed schema keys
        self.assertIn("critical_context", result)
        self.assertIn("helpful_context", result)
        self.assertIn("analysis", result)

        # Heuristic fields must be populated
        self.assertIsInstance(result["critical_context"]["critical_terms"], list)
        self.assertIsInstance(result["helpful_context"]["style_notes"], list)
        self.assertIsInstance(result["analysis"]["scene_type"], str)

    def test_assembler_returns_valid_schema_with_no_analyst(self):
        """Assembler must work fine with analyst=None."""
        from pipeline_core.preprocessing.preprocessing_assembler import assemble_context

        unit = {
            "unit_id":      "u2",
            "display_order": 1,
            "kind":         "section",
            "title":        "Prologue",
            "clean_text":   "Once upon a time there was a great kingdom. " * 10,
            "metadata":     {},
        }

        result = assemble_context(unit, analyst=None)
        self.assertIn("critical_context", result)
        self.assertIn("helpful_context", result)
        self.assertIn("analysis", result)


if __name__ == "__main__":
    unittest.main()
