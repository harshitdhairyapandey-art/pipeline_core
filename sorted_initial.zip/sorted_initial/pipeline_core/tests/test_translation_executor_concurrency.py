"""
pipeline_core/tests/test_translation_executor_concurrency.py
=============================================================
Tests for the translation executor: ordering, failure halting,
and throughput-controller wrapping.
"""
import threading
import time
import unittest

from pipeline_core.runtime.translation_executor import execute_translation_batches


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _make_unit(uid: str, text: str = "Hello world.") -> dict:
    return {
        "unit_id": uid,
        "clean_text": text,
        "metadata": {},
        "critical_context": {"critical_terms": [], "tone_hint": "", "chapter_title": ""},
        "helpful_context": {
            "style_notes": [], "devanagari_hints": [], "address_hierarchy": [],
            "flow_context": {}, "voice_context": {"dialogue_density": "low"}, "tts_profile": {},
        },
        "analysis": {"scene_type": "narrative", "translation_difficulty": "low"},
    }


def _make_batch(unit_ids: list, bundle: dict = None) -> dict:
    return {
        "batch_id":        "batch_test",
        "unit_ids":        unit_ids,
        "context_bundle":  bundle or {},
        "retry_count":     0,
    }


def _simple_prompt_builder(clean_text, bundle, unit, global_context) -> str:
    return f"TRANSLATE: {clean_text}"


class TestOutputOrdering(unittest.TestCase):
    """Results must be in input order even when workers complete out of order."""

    def test_results_are_ordered(self):
        n_units   = 6
        unit_ids  = [f"u{i}" for i in range(n_units)]
        unit_lookup = {uid: _make_unit(uid, f"Text {i}") for i, uid in enumerate(unit_ids)}

        # Stagger completions: even units sleep longer
        call_count = [0]
        call_lock  = threading.Lock()

        def provider(prompt: str) -> str:
            with call_lock:
                idx = call_count[0]
                call_count[0] += 1
            # Even-indexed units sleep slightly longer
            if idx % 2 == 0:
                time.sleep(0.05)
            return f"[TRANSLATED_{idx}]"

        batches = [_make_batch(unit_ids)]
        success, results = execute_translation_batches(
            batches           = batches,
            unit_lookup       = unit_lookup,
            global_context    = {},
            provider_callable = provider,
            prompt_builder    = _simple_prompt_builder,
            max_workers       = 3,
        )

        self.assertTrue(success, f"Expected success, got: {results}")
        result_ids = [r["unit_id"] for r in results]
        self.assertEqual(result_ids, unit_ids,
            msg=f"Result order mismatch: {result_ids} != {unit_ids}")

    def test_all_units_present(self):
        unit_ids    = [f"u{i}" for i in range(8)]
        unit_lookup = {uid: _make_unit(uid) for uid in unit_ids}

        success, results = execute_translation_batches(
            batches           = [_make_batch(unit_ids)],
            unit_lookup       = unit_lookup,
            global_context    = {},
            provider_callable = lambda p: "[TRANSLATED]",
            prompt_builder    = _simple_prompt_builder,
            max_workers       = 4,
        )
        self.assertTrue(success)
        self.assertEqual(len(results), len(unit_ids))


class TestFailureHalting(unittest.TestCase):
    """A single worker failure must stop the job cleanly."""

    def test_one_failure_returns_false(self):
        unit_ids    = ["u0", "u1", "u_fail", "u3"]
        unit_lookup = {uid: _make_unit(uid) for uid in unit_ids}

        def provider(prompt: str) -> str:
            if "u_fail" in prompt:
                raise RuntimeError("Simulated provider crash")
            return "[OK]"

        success, payload = execute_translation_batches(
            batches           = [_make_batch(unit_ids)],
            unit_lookup       = unit_lookup,
            global_context    = {},
            provider_callable = provider,
            prompt_builder    = _simple_prompt_builder,
            max_workers       = 2,
        )
        self.assertFalse(success, "Expected failure due to crashing worker")
        self.assertIsInstance(payload, dict, "Error payload should be a dict")

    def test_missing_unit_returns_false(self):
        unit_ids    = ["u0", "missing_unit"]
        unit_lookup = {"u0": _make_unit("u0")}   # "missing_unit" not in lookup

        success, payload = execute_translation_batches(
            batches           = [_make_batch(unit_ids)],
            unit_lookup       = unit_lookup,
            global_context    = {},
            provider_callable = lambda p: "[OK]",
            prompt_builder    = _simple_prompt_builder,
        )
        self.assertFalse(success)
        self.assertIn("code", payload)


class TestThroughputControlWrapping(unittest.TestCase):
    """Provider calls must go through throughput_controller (rate limiter)."""

    def test_calls_are_rate_limited(self):
        """
        With 2 RPS global limit and 4 concurrent workers, 8 calls should
        take at least ~3 seconds (can't all fire simultaneously).
        """
        n = 8
        unit_ids    = [f"u{i}" for i in range(n)]
        unit_lookup = {uid: _make_unit(uid) for uid in unit_ids}
        timestamps  = []
        lock        = threading.Lock()

        def provider(prompt: str) -> str:
            with lock:
                timestamps.append(time.time())
            return "[TRANSLATED]"

        start = time.time()
        success, _ = execute_translation_batches(
            batches           = [_make_batch(unit_ids)],
            unit_lookup       = unit_lookup,
            global_context    = {},
            provider_callable = provider,
            prompt_builder    = _simple_prompt_builder,
            max_workers       = 4,
        )
        elapsed = time.time() - start

        self.assertTrue(success)
        # With 2 RPS and 8 calls, minimum time ≈ 3.5s (some tolerance)
        self.assertGreaterEqual(elapsed, 2.5,
            msg=f"Rate limiter not working — all calls fired in {elapsed:.2f}s")


if __name__ == "__main__":
    unittest.main()
