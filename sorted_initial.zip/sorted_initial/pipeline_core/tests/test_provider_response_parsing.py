"""
pipeline_core/tests/test_provider_response_parsing.py
======================================================
Tests for provider response parsing: success, error, malformed, 429.
"""
import unittest
from unittest.mock import patch, MagicMock

from pipeline_core.providers.client import (
    extract_text_from_response,
    extract_error_from_response,
    ProviderResponseError,
    ProviderRateLimitError,
    ProviderAuthError,
)


# ---------------------------------------------------------------------------
# Unit tests for helper functions
# ---------------------------------------------------------------------------

class TestExtractTextFromResponse(unittest.TestCase):

    def test_standard_openai_success(self):
        resp = {
            "choices": [
                {"message": {"content": "Hello in Hindi"}, "finish_reason": "stop"}
            ]
        }
        self.assertEqual(extract_text_from_response(resp), "Hello in Hindi")

    def test_missing_choices_returns_none(self):
        self.assertIsNone(extract_text_from_response({}))
        self.assertIsNone(extract_text_from_response({"data": "something"}))

    def test_empty_choices_list_returns_none(self):
        self.assertIsNone(extract_text_from_response({"choices": []}))

    def test_none_content_returns_none(self):
        resp = {"choices": [{"message": {"content": None}}]}
        self.assertIsNone(extract_text_from_response(resp))

    def test_non_dict_response_returns_none(self):
        self.assertIsNone(extract_text_from_response("not a dict"))
        self.assertIsNone(extract_text_from_response(None))
        self.assertIsNone(extract_text_from_response(42))

    def test_text_field_fallback(self):
        # Some providers use 'text' instead of 'message.content'
        resp = {"choices": [{"text": "Alternative text"}]}
        self.assertEqual(extract_text_from_response(resp), "Alternative text")


class TestExtractErrorFromResponse(unittest.TestCase):

    def test_nested_error_dict(self):
        resp = {"error": {"message": "Rate limit exceeded", "code": "rate_limit"}}
        self.assertEqual(extract_error_from_response(resp), "Rate limit exceeded")

    def test_error_string(self):
        resp = {"error": "Invalid API key"}
        self.assertEqual(extract_error_from_response(resp), "Invalid API key")

    def test_top_level_message(self):
        resp = {"message": "Something went wrong"}
        self.assertEqual(extract_error_from_response(resp), "Something went wrong")

    def test_no_error_returns_none(self):
        resp = {"choices": [{"message": {"content": "OK"}}]}
        self.assertIsNone(extract_error_from_response(resp))

    def test_non_dict_returns_none(self):
        self.assertIsNone(extract_error_from_response("string"))
        self.assertIsNone(extract_error_from_response(None))


# ---------------------------------------------------------------------------
# Integration tests for ScitelyProvider._execute_request HTTP handling
# ---------------------------------------------------------------------------

class TestScitelyHTTPHandling(unittest.TestCase):
    """
    Patch requests.post to simulate various HTTP responses.
    Tests that the provider surfaces them as the correct exception types.
    """

    def _get_provider(self):
        import os
        os.environ.setdefault("SCITELY_API_KEY", "test-key-for-tests")
        from pipeline_core.providers.scitely_provider import ScitelyProvider
        return ScitelyProvider()

    @patch("pipeline_core.providers.scitely_provider.requests.post")
    def test_success_200_parsed(self, mock_post):
        mock_resp = MagicMock()
        mock_resp.status_code = 200
        mock_resp.ok          = True
        mock_resp.json.return_value = {
            "choices": [{"message": {"content": "नमस्ते"}}]
        }
        mock_post.return_value = mock_resp

        provider = self._get_provider()
        result   = provider._execute_request({"model": "x", "messages": []})
        self.assertIn("choices", result)

    @patch("pipeline_core.providers.scitely_provider.requests.post")
    def test_429_raises_rate_limit_error(self, mock_post):
        mock_resp = MagicMock()
        mock_resp.status_code = 429
        mock_resp.headers     = {"Retry-After": "30"}
        mock_resp.text        = "Rate limit exceeded"
        mock_post.return_value = mock_resp

        provider = self._get_provider()
        with self.assertRaises(ProviderRateLimitError) as ctx:
            provider._execute_request({})
        self.assertEqual(ctx.exception.retry_after, 30.0)

    @patch("pipeline_core.providers.scitely_provider.requests.post")
    def test_401_raises_auth_error(self, mock_post):
        mock_resp = MagicMock()
        mock_resp.status_code = 401
        mock_resp.text        = "Unauthorized"
        mock_post.return_value = mock_resp

        provider = self._get_provider()
        with self.assertRaises(ProviderAuthError):
            provider._execute_request({})

    @patch("pipeline_core.providers.scitely_provider.requests.post")
    def test_500_raises_temporary_error(self, mock_post):
        from pipeline_core.providers.client import ProviderTemporaryError
        mock_resp = MagicMock()
        mock_resp.status_code = 500
        mock_resp.text        = "Internal server error"
        mock_post.return_value = mock_resp

        provider = self._get_provider()
        with self.assertRaises(ProviderTemporaryError):
            provider._execute_request({})

    @patch("pipeline_core.providers.scitely_provider.requests.post")
    def test_malformed_json_raises_response_error(self, mock_post):
        mock_resp = MagicMock()
        mock_resp.status_code = 200
        mock_resp.ok          = True
        mock_resp.json.side_effect = ValueError("not JSON")
        mock_resp.text        = "not json"
        mock_post.return_value = mock_resp

        provider = self._get_provider()
        with self.assertRaises(ProviderResponseError):
            provider._execute_request({})

    @patch("pipeline_core.providers.scitely_provider.requests.post")
    def test_error_payload_raises_response_error(self, mock_post):
        mock_resp = MagicMock()
        mock_resp.status_code = 200
        mock_resp.ok          = True
        mock_resp.json.return_value = {
            "error": {"message": "Model not found", "code": "model_not_found"}
        }
        mock_post.return_value = mock_resp

        provider = self._get_provider()
        with self.assertRaises(ProviderResponseError) as ctx:
            provider._execute_request({})
        self.assertIn("Model not found", str(ctx.exception))

    @patch("pipeline_core.providers.scitely_provider.requests.post")
    def test_retry_after_no_header_is_none(self, mock_post):
        mock_resp = MagicMock()
        mock_resp.status_code = 429
        mock_resp.headers     = {}   # No Retry-After header
        mock_resp.text        = "Rate limited"
        mock_post.return_value = mock_resp

        provider = self._get_provider()
        with self.assertRaises(ProviderRateLimitError) as ctx:
            provider._execute_request({})
        self.assertIsNone(ctx.exception.retry_after)


if __name__ == "__main__":
    unittest.main()
