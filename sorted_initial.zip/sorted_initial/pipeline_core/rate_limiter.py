"""
pipeline_core/resilience/rate_limiter.py
==========================================
Async-first sliding-window rate limiter.

Two separate limiters tuned to Scitely Community tier:

  API_RATE_LIMITER          — translation, polishing, publishing
    1 RPS (safe, never spike), 55 RPM (headroom under 60 hard limit)

  PREPROCESSING_RATE_LIMITER — preprocessing AI calls only
    4 RPS (doc-level calls are cheap, 4 concurrent is safe), 55 RPM shared

Both limiters expose:
  await wait_for_capacity_async()  ← use in async paths (orchestrator)
        wait_for_capacity()        ← sync fallback, backward compatible
"""
import asyncio
import threading
import time
from collections import deque
from typing import Optional


class RateLimiter:
    def __init__(self, max_per_second: int, max_per_minute: int, name: str = ""):
        self.max_per_second = max_per_second
        self.max_per_minute = max_per_minute
        self.name           = name
        self._lock          = threading.Lock()
        self._second_window: deque = deque()
        self._minute_window: deque = deque()

    # ── Internal slot logic (shared by both sync and async paths) ────────────

    def _try_acquire(self) -> float:
        """
        Thread-safe slot acquisition.
        Returns 0.0 if slot taken, else seconds to sleep before retrying.
        """
        with self._lock:
            now = time.monotonic()

            # Evict expired timestamps
            while self._second_window and now - self._second_window[0] >= 1.0:
                self._second_window.popleft()
            while self._minute_window and now - self._minute_window[0] >= 60.0:
                self._minute_window.popleft()

            if len(self._second_window) >= self.max_per_second:
                return max(0.01, 1.0 - (now - self._second_window[0]))

            if len(self._minute_window) >= self.max_per_minute:
                return max(0.01, 60.0 - (now - self._minute_window[0]))

            self._second_window.append(now)
            self._minute_window.append(now)
            return 0.0

    # ── Async path (primary) ─────────────────────────────────────────────────

    async def wait_for_capacity_async(self) -> None:
        """
        Non-blocking async wait. Uses asyncio.sleep so the event loop
        stays free while waiting — never blocks other coroutines.
        """
        while True:
            sleep_for = self._try_acquire()
            if sleep_for == 0.0:
                return
            await asyncio.sleep(sleep_for)

    # ── Sync path (backward compat for existing ThreadPoolExecutor paths) ────

    def wait_for_capacity(self) -> None:
        """Blocking sync wait. Only use in thread-executor contexts."""
        while True:
            sleep_for = self._try_acquire()
            if sleep_for == 0.0:
                return
            time.sleep(sleep_for)

    # ── Observability ────────────────────────────────────────────────────────

    @property
    def current_rps(self) -> float:
        with self._lock:
            now = time.monotonic()
            return float(sum(1 for t in self._second_window if now - t < 1.0))

    @property
    def current_rpm(self) -> float:
        with self._lock:
            now = time.monotonic()
            return float(sum(1 for t in self._minute_window if now - t < 60.0))

    def status(self) -> dict:
        return {
            "name":    self.name,
            "rps":     self.current_rps,
            "rpm":     self.current_rpm,
            "max_rps": self.max_per_second,
            "max_rpm": self.max_per_minute,
        }


# ── Singletons ───────────────────────────────────────────────────────────────

# Translation / Polishing / Publishing — 1 req/sec, 55 RPM
# Conservative: each chunk ~600 tokens, 1RPS = 60 req/min but we cap at 55
# to leave 5 slots headroom against any clock drift
API_RATE_LIMITER = RateLimiter(
    max_per_second=1,
    max_per_minute=55,
    name="api"
)

# Preprocessing AI calls — doc-level only, 4 fire simultaneously
# Still shares the 55 RPM ceiling so total budget is never exceeded
PREPROCESSING_RATE_LIMITER = RateLimiter(
    max_per_second=4,
    max_per_minute=55,
    name="preprocessing"
)

# Legacy alias — anything still importing GLOBAL_RATE_LIMITER gets API limiter
GLOBAL_RATE_LIMITER = API_RATE_LIMITER