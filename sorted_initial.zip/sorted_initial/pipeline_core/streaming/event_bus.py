"""
Thread-safe event bus that streams pipeline events.
Consumers: SSE endpoint in main.py, Conductor WebSocket relay.

Events are queued in-memory. Multiple listeners can subscribe.
Each listener gets its own queue so slow consumers don't block fast ones.
"""
import threading
import time
import json
from queue import Queue
from typing import Optional


class Event:
    def __init__(self, kind: str, data: dict):
        self.kind = kind
        self.data = data
        self.timestamp = time.time()

    def to_sse(self) -> str:
        payload = json.dumps({
            "kind": self.kind,
            "data": self.data,
            "ts": self.timestamp,
        }, ensure_ascii=False)
        return f"event: {self.kind}\ndata: {payload}\n\n"


class EventBus:
    def __init__(self):
        self._lock = threading.Lock()
        self._listeners: list[Queue] = []
        self._history: list[Event] = []
        self._max_history = 500

    def subscribe(self) -> Queue:
        q: Queue = Queue(maxsize=200)
        with self._lock:
            self._listeners.append(q)
        return q

    def unsubscribe(self, q: Queue):
        with self._lock:
            if q in self._listeners:
                self._listeners.remove(q)

    def emit(self, kind: str, **data):
        event = Event(kind, data)
        with self._lock:
            self._history.append(event)
            if len(self._history) > self._max_history:
                self._history = self._history[-self._max_history:]
            for q in self._listeners:
                try:
                    q.put_nowait(event)
                except Exception:
                    pass  # slow consumer, skip

    def recent(self, n: int = 50) -> list[dict]:
        with self._lock:
            return [
                {"kind": e.kind, "data": e.data, "ts": e.timestamp}
                for e in self._history[-n:]
            ]

    # ── Convenience emitters ──────────────────────────────────────────────

    def log(self, job_id: str, stage: str, message: str):
        self.emit("log", job_id=job_id, stage=stage, message=message)

    def progress(
        self,
        job_id: str,
        stage: str,
        pct: float,
        chapter: Optional[int] = None,
        total: Optional[int] = None,
    ):
        """
        Flexible progress emitter.

        Orchestrator calls:  bus.progress(job_id, stage_name, pct)
        Chapter-level calls: bus.progress(job_id, stage, pct, chapter=N, total=M)
        Both are valid.
        """
        self.emit(
            "progress",
            job_id=job_id,
            stage=stage,
            pct=round(pct, 1),
            chapter=chapter,
            total=total,
        )

    def retry(self, job_id: str, chunk_id: str, attempt: int, tier: str, reason: str):
        self.emit("retry", job_id=job_id, chunk_id=chunk_id,
                  attempt=attempt, tier=tier, reason=reason)

    def error(self, job_id: str, stage: str, message: str):
        self.emit("error", job_id=job_id, stage=stage, message=message)

    def status(self, job_id: str, message: str):
        self.emit("status", job_id=job_id, message=message)

    def warning(self, job_id: str, stage: str, message: str):
        self.emit("warning", job_id=job_id, stage=stage, message=message)

    def done(self, job_id: str, export_path: str):
        self.emit("done", job_id=job_id, export_path=export_path)


# Global singleton
bus = EventBus()