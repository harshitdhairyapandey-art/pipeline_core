from typing import Dict, List

# Rendering action rules by term type
_TYPE_ACTION_MAP = {
    "proper_name":  "transliterate",
    "title":        "translate_carefully",
    "special_term": "preserve",
    "generic_term": "translate_carefully",
}

# Tone notes by action
_ACTION_NOTES = {
    "preserve": [
        "Keep this term exactly as written in the source.",
        "Do not substitute with a synonym or approximate translation."
    ],
    "transliterate": [
        "Render this proper name phonetically in Devanagari script.",
        "Do not translate the meaning — only the sound."
    ],
    "translate_carefully": [
        "Translate the meaning of this term with cultural sensitivity.",
        "Prefer standard Hindi equivalents if well-established."
    ],
}


def suggest_term_rendering(term: str, term_type: str) -> Dict:
    """
    Returns a rendering recommendation for a classified term, deterministically.
    No AI calls. Conservative, consistent rules per term type.
    """
    action = _TYPE_ACTION_MAP.get(term_type, "translate_carefully")

    # Suggested rendering is a structured placeholder — not a real translation
    if action == "preserve":
        suggested = term  # keep exactly as-is
    elif action == "transliterate":
        suggested = f"[{term}_devanagari]"  # phonetic placeholder
    else:
        suggested = f"[{term}_translated]"  # meaning-based placeholder

    notes: List[str] = list(_ACTION_NOTES.get(action, []))

    # Type-specific extra notes
    if term_type == "title":
        notes.append("Use honorific register (aap) when addressing this title in dialogue.")
    if term_type == "special_term":
        notes.append("This term is world-specific. Maintain exact form across all chapters.")

    return {
        "source_term": term,
        "recommended_action": action,
        "suggested_rendering": suggested,
        "notes": notes
    }
