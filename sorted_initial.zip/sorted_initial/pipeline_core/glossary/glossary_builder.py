from typing import List, Dict, Any
from collections import Counter

from .term_classifier import classify_term
from .transliteration_rules import suggest_term_rendering
from .glossary_ranker import rank_glossary_terms


def build_global_glossary(units: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
    """
    Extracts, classifies, enriches, and ranks critical terms across all units.
    Returns a structured glossary list — each entry is a rich dict, not a bare string.
    """
    term_counter: Counter = Counter()

    for unit in units:
        critical_terms = unit.get("critical_context", {}).get("critical_terms", [])
        for term in critical_terms:
            if len(term) > 3:
                term_counter[term] += 1

    # Build enriched entries
    enriched: List[Dict[str, Any]] = []
    for term, freq in term_counter.items():
        classification = classify_term(term)
        rendering = suggest_term_rendering(term, classification["term_type"])
        enriched.append({
            "term": term,
            "frequency": freq,
            "term_type": classification["term_type"],
            "confidence": classification["confidence"],
            "recommended_action": rendering["recommended_action"],
            "suggested_rendering": rendering["suggested_rendering"],
            "notes": rendering["notes"]
        })

    return rank_glossary_terms(enriched)
