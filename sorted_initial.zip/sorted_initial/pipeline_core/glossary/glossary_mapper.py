from typing import List, Dict, Any


def create_glossary_map(glossary_entries: List[Dict[str, Any]]) -> Dict[str, Dict[str, Any]]:
    """
    Builds a structured glossary map from ranked glossary entries.
    Keys are source terms; values are rich rendering instruction dicts.
    The structure is compatible with prompt_builder and glossary_enforcer.
    """
    glossary_map: Dict[str, Dict[str, Any]] = {}

    for entry in glossary_entries:
        term = entry.get("term", "")
        if not term:
            continue
        glossary_map[term] = {
            "term_type":          entry.get("term_type", "generic_term"),
            "recommended_action": entry.get("recommended_action", "translate_carefully"),
            "suggested_rendering": entry.get("suggested_rendering", term),
            "notes":              entry.get("notes", [])
        }

    return glossary_map
