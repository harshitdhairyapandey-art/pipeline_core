from typing import List, Dict, Any

# Priority order for term types (lower index = higher priority)
_TYPE_PRIORITY = {
    "special_term":  0,
    "proper_name":   1,
    "title":         2,
    "generic_term":  3,
}

# Confidence score weights
_CONFIDENCE_WEIGHT = {
    "high":   3,
    "medium": 2,
    "low":    1,
}


def rank_glossary_terms(terms: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
    """
    Accepts a list of enriched glossary entry dicts (each with 'term', 'term_type',
    'confidence', 'frequency') and returns them ranked by:
      1. Term type priority (special > proper > title > generic)
      2. Confidence score
      3. Frequency count
    Removes generic_term entries with low confidence and frequency <= 1.
    Returns at most 30 entries.
    """
    filtered = []
    for entry in terms:
        term_type = entry.get("term_type", "generic_term")
        confidence = entry.get("confidence", "low")
        frequency = entry.get("frequency", 1)

        # Drop low-signal generic terms
        if term_type == "generic_term" and confidence == "low" and frequency <= 1:
            continue

        filtered.append(entry)

    # Sort: primary = type priority, secondary = confidence weight (desc), tertiary = frequency (desc)
    ranked = sorted(
        filtered,
        key=lambda e: (
            _TYPE_PRIORITY.get(e.get("term_type", "generic_term"), 99),
            -_CONFIDENCE_WEIGHT.get(e.get("confidence", "low"), 1),
            -e.get("frequency", 1)
        )
    )

    return ranked[:30]
