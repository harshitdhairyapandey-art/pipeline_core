import re
from typing import Dict

# ---------------------------------------------------------------------------
# Heuristic patterns
# ---------------------------------------------------------------------------

# Proper names: Title-case single or compound words (e.g. "Arjun", "Lord Rama")
_PROPER_NAME_PATTERN = re.compile(r'^([A-Z][a-z]+)(\s[A-Z][a-z]+)*$')

# Obvious title words (honorifics / roles)
_TITLE_WORDS = {
    "lord", "lady", "sir", "king", "queen", "prince", "princess", "emperor",
    "empress", "duke", "duchess", "baron", "baroness", "captain", "general",
    "major", "colonel", "admiral", "commander", "master", "guru", "maharaj",
    "saint", "father", "priest", "bishop", "archbishop", "cardinal", "reverend",
    "chief", "elder", "sage", "shaman", "monk", "chancellor", "president",
    "minister", "judge", "prophet", "oracle"
}

# Fantasy / worldbuilding signals: non-standard capitalization or unusual morphology
_FANTASY_PATTERN = re.compile(
    r"(?:[A-Z][a-z]*[A-Z])|(?:[A-Z]{2,}[a-z]+)|(?:'[a-z]+)|(?:-[A-Z][a-z]+)"
)

# Common English stopwords — filter out as generic
_STOPWORDS = {
    "the", "and", "but", "for", "with", "from", "into", "that", "this",
    "they", "them", "their", "then", "than", "when", "where", "which",
    "who", "whom", "what", "how", "all", "not", "are", "was", "were", "had",
    "has", "have", "been", "being", "will", "would", "could", "should",
    "can", "may", "might", "shall", "his", "her", "its", "our", "your",
    "over", "under", "after", "before", "about", "above", "below"
}


def classify_term(term: str) -> Dict[str, str]:
    """
    Deterministically classifies a glossary term into one of four types:
    proper_name | title | special_term | generic_term.
    No AI calls. Conservative confidence.
    """
    stripped = term.strip()
    lower = stripped.lower()

    # Filter stopwords — always generic
    if lower in _STOPWORDS or len(stripped) <= 3:
        return {"term": stripped, "term_type": "generic_term", "confidence": "high"}

    # Title word at start or entire phrase is a known title
    first_word = lower.split()[0]
    if first_word in _TITLE_WORDS:
        return {"term": stripped, "term_type": "title", "confidence": "high"}

    # Any word in the phrase is a title word (e.g. "Grand Priest Valen")
    words_lower = lower.split()
    if any(w in _TITLE_WORDS for w in words_lower):
        return {"term": stripped, "term_type": "title", "confidence": "medium"}

    # Fantasy/special term signal (camelCase, apostrophe, unusual pattern)
    if _FANTASY_PATTERN.search(stripped):
        return {"term": stripped, "term_type": "special_term", "confidence": "medium"}

    # Proper name: Title-case word(s), not a known common word
    if _PROPER_NAME_PATTERN.match(stripped):
        return {"term": stripped, "term_type": "proper_name", "confidence": "medium"}

    # Fallback: generic
    return {"term": stripped, "term_type": "generic_term", "confidence": "low"}
