from typing import Dict, List

class GlossaryStore:
    """
    Static store managing glossary mappings securely for unified pipeline context propagation.
    """
    def __init__(self, mapping: dict = None):
        self.mapping = mapping or {}
        
    def add_mappings(self, new_maps: Dict[str, str]):
        self.mapping.update(new_maps)
        
    def get_map(self) -> Dict[str, str]:
        return self.mapping
        
    def get_keys(self) -> List[str]:
        return list(self.mapping.keys())
