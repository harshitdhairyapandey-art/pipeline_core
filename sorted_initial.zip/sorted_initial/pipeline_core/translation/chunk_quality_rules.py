"""
pipeline_core/translation/chunk_quality_rules.py
=================================================
Validates chunk quality before they are committed to the manifest.
Returns a list of warning strings (empty = clean).
Does NOT modify chunks — only reports issues.
"""
import re
from typing import Dict, Any, List

# Thresholds
_MIN_CHARS          = 50      # chunk too small to be worth a separate API call
_MAX_CHARS_HARD     = 3200    # hard ceiling — must never exceed
_MAX_CHARS_WARN     = 2800    # soft warn if close to ceiling
_MID_DIALOGUE_RE    = re.compile(r'[""«\u201c][^""»\u201d]*$')   # ends with unclosed quote
_CARRYOVER_REQUIRED = 200     # if split, carryover tail must be ≥ this


def validate_chunk(
    chunk_text: str,
    context_bundle: Dict[str, Any],
    is_split: bool = False,
) -> List[str]:
    """
    Run quality checks on a single chunk.

    Args:
        chunk_text:      The raw text content of the chunk.
        context_bundle:  The carryover context dict produced by chunk_context_carryover.
        is_split:        Whether this chunk was produced by splitting a larger unit.

    Returns:
        List of human-readable warning strings. Empty list = no issues.
    """
    warnings: List[str] = []
    length = len(chunk_text.strip())

    # 1. Too short
    if length < _MIN_CHARS:
        warnings.append(
            f"CHUNK_TOO_SHORT: {length} chars (min {_MIN_CHARS}). "
            "Consider merging with adjacent chunk."
        )

    # 2. Hard ceiling violation
    if length > _MAX_CHARS_HARD:
        warnings.append(
            f"CHUNK_EXCEEDS_HARD_LIMIT: {length} chars (max {_MAX_CHARS_HARD}). "
            "This chunk will likely cause provider errors."
        )
    # 3. Approaching ceiling
    elif length > _MAX_CHARS_WARN:
        warnings.append(
            f"CHUNK_NEAR_LIMIT: {length} chars (warn threshold {_MAX_CHARS_WARN})."
        )

    # 4. Mid-dialogue split
    stripped = chunk_text.rstrip()
    if _MID_DIALOGUE_RE.search(stripped):
        warnings.append(
            "MID_DIALOGUE_SPLIT: chunk appears to end mid-dialogue (unclosed quote). "
            "Translation quality may suffer."
        )

    # 5. Split without adequate carryover
    if is_split:
        tail = context_bundle.get("previous_unit_tail", "")
        if len(tail) < _CARRYOVER_REQUIRED:
            warnings.append(
                f"SPLIT_WITHOUT_CARRYOVER: chunk is split but previous_unit_tail is only "
                f"{len(tail)} chars (recommended ≥ {_CARRYOVER_REQUIRED})."
            )

    # 6. No glossary terms provided
    if not context_bundle.get("critical_terms") and not context_bundle.get("global_glossary_keys"):
        warnings.append(
            "NO_GLOSSARY_CONTEXT: chunk has no glossary terms attached. "
            "Proper noun consistency may drift."
        )

    return warnings


def validate_all_chunks(
    chunks: List[Dict[str, Any]],
) -> Dict[str, List[str]]:
    """
    Validate all chunks in a manifest.

    Returns:
        Dict mapping chunk_id -> list of warning strings.
        Only chunks WITH warnings appear in the result.
    """
    issues: Dict[str, List[str]] = {}
    for chunk in chunks:
        chunk_id      = chunk.get("batch_id", chunk.get("chunk_id", "unknown"))
        bundle        = chunk.get("context_bundle", {})
        is_split      = bundle.get("split_warning", False)

        # Reconstruct chunk text from unit_ids if raw text is not stored
        # (text not stored in manifest by design — validate via estimated_chars)
        estimated = chunk.get("estimated_chars", 0)

        # Build a minimal synthetic text representative for length checks only
        synthetic_text = "x" * estimated

        warnings = validate_chunk(synthetic_text, bundle, is_split)
        if warnings:
            issues[chunk_id] = warnings

    return issues
