"""
pipeline_core/translation/translation_strategy.py
===================================================
Evaluates preprocessed unit context to produce a translation strategy.
The strategy drives prompt construction and executor behaviour.
"""
from typing import Dict, Any


def evaluate_translation_strategy(
    unit:           Dict[str, Any],
    global_context: Dict[str, Any],
) -> Dict[str, Any]:
    """
    Returns a strategy dict controlling prompt construction and executor hints.
    All fields have safe defaults so callers never need to guard for missing keys.
    """
    helpful  = unit.get("helpful_context", {})
    critical = unit.get("critical_context", {})
    analysis = unit.get("analysis", {})

    # --- Signal extraction -------------------------------------------------
    dialogue_density = helpful.get("voice_context", {}).get("dialogue_density", "low")
    has_dialogue     = dialogue_density in ("medium", "high")
    has_honorifics   = bool(helpful.get("address_hierarchy"))
    has_deva_hints   = bool(helpful.get("devanagari_hints"))
    has_flow         = bool(helpful.get("flow_context"))
    scene_type       = analysis.get("scene_type", "narrative")
    trans_difficulty = analysis.get("translation_difficulty", "medium")

    tone  = critical.get("tone_hint") or global_context.get("global_tone", "neutral")
    delivery = helpful.get("tts_profile", {}).get("delivery_style", "neutral")

    # --- Policy blocks -----------------------------------------------------
    translation_step = {
        "primary_focus":       "dialogue_dynamics" if has_dialogue else "literary_narrative",
        "tone_override":       tone,
        "tts_delivery_target": delivery,
        "literary_depth": (
            "classic_heavy"  if scene_type in ("ritual", "philosophical") else
            "action_compact" if scene_type in ("action", "climax")        else
            "modern_natural"
        ),
        "translation_difficulty": trans_difficulty,
    }

    context_usage = {
        "use_address_hierarchy": has_honorifics,
        "use_voice_context":     has_dialogue,
        "use_devanagari_hints":  has_deva_hints,
        "use_flow_context":      has_flow,
        "use_global_glossary":   bool(global_context.get("glossary_map")),
        "use_ai_voice_profiles": bool(global_context.get("ai_voice_profiles")),
    }

    mandates = {
        "word_choice_modernization": True,
        "terminology_3_tier_system": True,
        "adaptation_over_literal":   True,
        "dialogue_naturalization":   has_dialogue,
        "preserve_intentional_repetition": True,
        "trust_the_reader":          True,
    }

    glossary_usage = {
        "strict_enforcement":       True,
        "prioritize_transliteration": True,
    }

    polish_handoff = {
        "requires_flow_smoothing":     (
            helpful.get("flow_context", {}).get("narrative_position") == "transition"
        ),
        "requires_dialogue_balancing": has_dialogue,
        "scene_type":                  scene_type,
    }

    return {
        "translation_step": translation_step,
        "context_usage":    context_usage,
        "mandates":         mandates,
        "glossary_usage":   glossary_usage,
        "polish_handoff":   polish_handoff,
    }
