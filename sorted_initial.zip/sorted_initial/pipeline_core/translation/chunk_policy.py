from typing import List, Dict, Any, Tuple
from .provider_profiles import ProviderProfile

def split_large_unit(unit: Dict[str, Any], max_chars: int) -> List[Dict[str, Any]]:
    """
    Splits a single unit into smaller pieces if it exceeds the absolute max_chars_per_chunk.
    Attempts splitting by paragraphs (\n\n) first, then by lines (\n), and lastly character slices.
    """
    text = unit.get("clean_text", "")
    
    if len(text) <= max_chars:
        return [unit]
        
    paragraphs = text.split("\n\n")
    if len(paragraphs) == 1 and len(paragraphs[0]) > max_chars:
        paragraphs = text.split("\n")
        
    parts = []
    current_part = []
    current_len = 0
    
    for p in paragraphs:
        p_len = len(p)
        if current_len + p_len + (2 if current_part else 0) > max_chars and current_part:
            parts.append("\n\n".join(current_part))
            current_part = [p]
            current_len = p_len
        elif p_len > max_chars:
            if current_part:
                parts.append("\n\n".join(current_part))
                current_part = []
                current_len = 0
            
            # Chunk purely by characters because no natural breaks remain
            for i in range(0, p_len, max_chars):
                parts.append(p[i:i+max_chars])
        else:
            current_part.append(p)
            current_len += p_len + (2 if current_part else 0)
            
    if current_part:
        parts.append("\n\n".join(current_part))
        
    sub_units = []
    for i, part_text in enumerate(parts):
        sub_unit = dict(unit)
        sub_unit["clean_text"] = part_text
        sub_unit["unit_id"] = f"{unit.get('unit_id', 'unknown')}_part{i+1}"
        sub_units.append(sub_unit)
        
    return sub_units

def build_chunk_groups(units: List[Dict[str, Any]], profile: ProviderProfile) -> List[Tuple[List[Dict[str, Any]], str]]:
    """
    Assembles units sequentially into groups obeying target_chars_per_chunk without splitting
    unless a single unit itself breaches max_chars_per_chunk.
    """
    groups = []
    current_group = []
    current_chars = 0
    
    for unit in units:
        text = unit.get("clean_text", "")
        unit_len = len(text)
        
        # Rule: Split raw text if single unit bursts absolute limit
        if unit_len > profile.max_chars_per_chunk:
            if current_group:
                groups.append((current_group, "target_limit_reached"))
                current_group = []
                current_chars = 0
                
            sub_units = split_large_unit(unit, profile.max_chars_per_chunk)
            for su in sub_units:
                groups.append(([su], "split_large_unit"))
            continue
            
        # Rule: Close chunk if adding this unit overflows the target limit stringently
        if current_chars + unit_len > profile.target_chars_per_chunk and current_group:
            groups.append((current_group, "target_limit_reached"))
            current_group = [unit]
            current_chars = unit_len
        else:
            current_group.append(unit)
            current_chars += unit_len
            
    if current_group:
        groups.append((current_group, "end_of_units"))
        
    return groups
