"""
pipeline_core/translation/semantic_chunker.py
===============================================
Semantic-aware split logic.

Prefers splitting at:
  1. Section / title boundaries (unit.kind == "chapter" or "section")
  2. Scene-break markers (blank lines, "* * *", "---")
  3. Dialogue boundaries (paragraph ending with closing quote)
  4. Paragraph boundaries
  5. Sentence boundaries (last resort before raw char slice)

Raw character slicing is used only when no natural break can be found.
"""
import re
from typing import List, Dict, Any, Tuple

# ---------------------------------------------------------------------------
# Scene-break patterns
# ---------------------------------------------------------------------------
_SCENE_BREAK_RE = re.compile(
    r"^[\s]*(\*\s*\*\s*\*|[-─—]{3,}|~{3,}|#{3,})\s*$",
    re.MULTILINE,
)

_DIALOGUE_END_RE = re.compile(
    r'[""\'»\u201d\u2019]\s*$'
)

_SENTENCE_END_RE = re.compile(
    r'(?<=[।.!?])\s+'
)


def _find_scene_break(text: str, near: int, window: int = 400) -> int:
    """
    Find the nearest scene-break marker position within ±window chars of `near`.
    Returns -1 if none found.
    """
    search_start = max(0, near - window)
    search_end   = min(len(text), near + window)
    best = -1
    best_dist = window + 1
    for m in _SCENE_BREAK_RE.finditer(text, search_start, search_end):
        dist = abs(m.start() - near)
        if dist < best_dist:
            best_dist = dist
            best = m.start()
    return best


def _find_paragraph_break(text: str, near: int, window: int = 600) -> int:
    """Find the nearest double-newline (paragraph break) within ±window of `near`."""
    search_start = max(0, near - window)
    search_end   = min(len(text), near + window)
    snippet      = text[search_start:search_end]
    offset = snippet.rfind("\n\n")
    if offset == -1:
        offset = snippet.find("\n\n")
    if offset == -1:
        return -1
    return search_start + offset + 2   # position after the break


def _find_sentence_break(text: str, near: int, window: int = 300) -> int:
    """Find the nearest sentence boundary within ±window of `near`."""
    search_start = max(0, near - window)
    search_end   = min(len(text), near + window)
    snippet      = text[search_start:search_end]
    best = -1
    best_dist = window + 1
    for m in _SENTENCE_END_RE.finditer(snippet):
        pos  = search_start + m.start()
        dist = abs(pos - near)
        if dist < best_dist:
            best_dist = dist
            best = pos
    return best


def split_text_semantically(text: str, max_chars: int) -> List[str]:
    """
    Split `text` into parts each ≤ max_chars, preferring semantic boundaries.
    Returns a list of text chunks in original order.
    """
    if len(text) <= max_chars:
        return [text]

    parts = []
    remaining = text

    while len(remaining) > max_chars:
        target = max_chars
        # 1. Scene break near 80% of target
        bp = _find_scene_break(remaining, int(target * 0.8))
        # 2. Paragraph break
        if bp == -1 or bp < 20:
            bp = _find_paragraph_break(remaining, int(target * 0.85))
        # 3. Sentence break
        if bp == -1 or bp < 20:
            bp = _find_sentence_break(remaining, target)
        # 4. Raw char slice fallback
        if bp == -1 or bp < 20:
            bp = target

        parts.append(remaining[:bp].strip())
        remaining = remaining[bp:].strip()

    if remaining:
        parts.append(remaining)

    return [p for p in parts if p]


def split_unit_semantically(
    unit: Dict[str, Any], max_chars: int
) -> List[Dict[str, Any]]:
    """
    Split a single preprocessed unit into sub-units using semantic splitting.
    Preserves all metadata; appends _partN suffix to unit_id.
    """
    text = unit.get("clean_text", "")
    if len(text) <= max_chars:
        return [unit]

    parts = split_text_semantically(text, max_chars)
    sub_units = []
    for i, part_text in enumerate(parts, 1):
        sub = dict(unit)
        sub["clean_text"] = part_text
        sub["unit_id"]    = f"{unit.get('unit_id', 'unknown')}_part{i}"
        sub["_is_split"]  = True
        sub["_part_index"] = i
        sub["_total_parts"] = len(parts)
        sub_units.append(sub)
    return sub_units
