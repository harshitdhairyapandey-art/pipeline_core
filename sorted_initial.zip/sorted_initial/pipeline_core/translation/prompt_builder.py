"""
pipeline_core/translation/prompt_builder.py
=============================================
Builds the per-unit translation prompt.

Structured in clear sections so the model can parse context hierarchically.
Appends FLASH_MANDATE_ADDITIONS from prompts.py.
Keeps prompt compact — no section repeated, no over-stuffing.
"""
from typing import Dict, Any

from .translation_strategy import evaluate_translation_strategy


def build_translation_prompt(
    clean_text:     str,
    bundle:         Dict[str, Any],
    unit:           Dict[str, Any],
    global_context: Dict[str, Any],
) -> str:
    """
    Constructs the full translation prompt for a single unit.
    """
    strategy      = evaluate_translation_strategy(unit, global_context)
    ctx_usage     = strategy["context_usage"]
    mandates      = strategy["mandates"]
    trans_step    = strategy["translation_step"]

    critical      = unit.get("critical_context", {})
    helpful       = unit.get("helpful_context", {})

    tone_hint     = critical.get("tone_hint") or global_context.get("global_tone", "")
    critical_terms = critical.get("critical_terms", [])
    style_notes   = helpful.get("style_notes", [])
    prev_tail     = bundle.get("previous_unit_tail", "")
    glossary_map  = global_context.get("glossary_map", {})

    lines = []

    # ── Header ──────────────────────────────────────────────────────────────
    lines += [
        "TARGET LANGUAGE: Hindi",
        "TASK: Translate the provided English text into literary, context-aware Hindi.",
        "Your role is a professional Hindi literary translator working on a fantasy novel for publication.",
        "Your job is to carry the author's voice, intention, and emotional texture into Hindi — not just convert words.",
        "Output ONLY the translated text. No preamble, no notes, no commentary.",
        "",
    ]

    # ── Literary mandate (compact) ──────────────────────────────────────────
    lines.append("LITERARY MANDATE:")
    lines.append(
        f"- Depth: {trans_step['literary_depth']} | Focus: {trans_step['primary_focus']}"
    )
    lines += [
        "- 70/30 RULE: 70% simple modern Hindi, 30% elegant literary. Prevent reader fatigue.",
        "- NATURALIZE: grief→शोक, moment→पल, silence→ख़ामोशी, dawn→भोर, shadow→छाया.",
        "- INCANTATIONS: Translate chants/prayers into Hindi meaning — never phonetic.",
        "- NUMERALS: Use 'स्तर 4' / 'रैंक 7' — never spell out as words.",
        "- IDIOMS: Adapt English body idioms to Hindi equivalents (नसों में, not हड्डियों में).",
        "- OVER-ADAPTATION: Never invent metaphors not in the source. Never exceed source intent.",
        "- TRUST THE READER: Concise. No interpretive embellishments.",
    ]
    if mandates.get("terminology_3_tier_system"):
        lines.append(
            "- TERMS: Tier 1 Lore→transliterate | Tier 2 World-building→hybrid | Tier 3 Generic→pure Hindi."
        )
    if tone_hint:
        lines.append(f"- TONE: {tone_hint}")
    if style_notes:
        lines.append(f"- STYLE: {'; '.join(style_notes)}")
    lines.append("")

    # ── Locked glossary ─────────────────────────────────────────────────────
    if glossary_map:
        preserve_terms, trans_terms, careful_terms = [], [], []
        for term, instr in glossary_map.items():
            action = instr.get("recommended_action", "translate_carefully") if isinstance(instr, dict) else "translate_carefully"
            if action == "preserve":
                preserve_terms.append(term)
            elif action == "transliterate":
                trans_terms.append(term)
            else:
                careful_terms.append(term)
        if preserve_terms:
            lines.append(f"PRESERVE EXACTLY (locked): {', '.join(preserve_terms)}")
        if trans_terms:
            lines.append(f"TRANSLITERATE (locked): {', '.join(trans_terms)}")
        if careful_terms:
            lines.append(f"CONSISTENT HINDI EQUIVALENTS: {', '.join(careful_terms[:20])}")
        lines.append("")

    # ── Character address hierarchy ─────────────────────────────────────────
    if ctx_usage["use_address_hierarchy"]:
        addr_hints = helpful.get("address_hierarchy", [])
        bundle_addr = bundle.get("address_hierarchy_slice", [])
        all_addr = addr_hints or bundle_addr
        if all_addr:
            lines.append("CHARACTER ADDRESS FORMS (enforce in dialogue):")
            for h in all_addr[:15]:
                char = h.get("character_or_role", "Unknown")
                reg  = h.get("suggested_register", "neutral")
                form_hindi = {
                    "tu":  "तू (intimate/contemptuous)",
                    "tum": "तुम (familiar)",
                    "aap": "आप (formal/respectful)",
                }.get(reg, reg)
                lines.append(f"  {char}: {form_hindi}")
            lines.append("")

    # ── Voice / dialogue context ─────────────────────────────────────────────
    if ctx_usage["use_voice_context"]:
        voice_ctx = helpful.get("voice_context", {})
        profile   = voice_ctx.get("voice_profile", [{}])[0] if voice_ctx.get("voice_profile") else {}
        style     = profile.get("voice_style", "")
        if style:
            lines.append(f"DIALOGUE VOICE: {style}")
        voice_hints = bundle.get("voice_hints", "")
        if voice_hints:
            lines.append(f"VOICE HINTS: {voice_hints}")
        lines.append("")

    # ── AI voice profiles (document-level) ──────────────────────────────────
    if ctx_usage["use_ai_voice_profiles"]:
        ai_voices = global_context.get("ai_voice_profiles", {})
        if ai_voices:
            lines.append("CHARACTER VOICES (document-level):")
            for char, prof in list(ai_voices.items())[:6]:
                style    = prof.get("speech_style", "") if isinstance(prof, dict) else ""
                register = prof.get("register", "")     if isinstance(prof, dict) else ""
                if style or register:
                    lines.append(f"  {char}: {style} — {register}")
            lines.append("")

    # ── Devanagari hints ────────────────────────────────────────────────────
    if ctx_usage["use_devanagari_hints"]:
        deva_hints = helpful.get("devanagari_hints", [])
        real_hints = [
            h for h in deva_hints
            if h.get("suggested_devanagari") and not h["suggested_devanagari"].startswith("[")
        ]
        if real_hints:
            lines.append("DEVANAGARI TRANSLITERATIONS (use these exactly):")
            for h in real_hints[:15]:
                lines.append(f"  {h.get('source_term')} → {h.get('suggested_devanagari')}")
            lines.append("")

    # ── Critical terms ───────────────────────────────────────────────────────
    if critical_terms:
        lines.append(f"CRITICAL TERMS (translate consistently): {', '.join(critical_terms[:30])}")
        lines.append("")

    # ── Context lead-in ─────────────────────────────────────────────────────
    if prev_tail:
        lines.append(f"CONTEXT LEAD-IN (end of previous chunk — do NOT translate, for continuity only):\n...{prev_tail}\n")

    # ── Split warning ────────────────────────────────────────────────────────
    if bundle.get("split_warning"):
        lines.append(
            "NOTE: This chunk is part of a split unit. "
            "Ensure it reads as a seamless continuation of the preceding text.\n"
        )

    # ── FLASH_MANDATE_ADDITIONS ──────────────────────────────────────────────
    try:
        from ..prompts import FLASH_MANDATE_ADDITIONS
        if FLASH_MANDATE_ADDITIONS:
            lines.append(FLASH_MANDATE_ADDITIONS.strip())
            lines.append("")
    except ImportError:
        pass

    # ── Source text ──────────────────────────────────────────────────────────
    lines.append(f"TEXT TO TRANSLATE:\n{clean_text}")

    return "\n".join(lines)
