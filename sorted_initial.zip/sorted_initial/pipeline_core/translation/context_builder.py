from typing import List, Dict, Any

def build_context_bundle(grouped_units: List[Dict[str, Any]], previous_unit: Dict[str, Any] = None) -> Dict[str, Any]:
    """
    Constructs a rich context bundle for a chunk by scanning its aggregated units
    and extracting cross-cutting hints and trailing snippets.
    """
    chapter_titles = []
    critical_terms = []
    tone_hint = ""
    style_notes = []
    
    for u in grouped_units:
        crit = u.get("critical_context", {})
        title = crit.get("chapter_title", "")
        if title and title not in chapter_titles:
            chapter_titles.append(title)
            
        terms = crit.get("critical_terms", [])
        if terms:
            for t in terms:
                if t not in critical_terms:
                    critical_terms.append(t)
                    
        tone = crit.get("tone_hint", "")
        if tone and not tone_hint:
            tone_hint = tone  # Take first available tone hint as chunk primary
            
        helpful = u.get("helpful_context", {})
        notes = helpful.get("style_notes", [])
        if notes:
            for n in notes:
                if n not in style_notes:
                    style_notes.append(n)
                    
    previous_tail = ""
    if previous_unit:
        prev_text = previous_unit.get("clean_text", "")
        if prev_text:
            previous_tail = prev_text[-200:]
            
    return {
        "chapter_titles": chapter_titles,
        "critical_terms": critical_terms,
        "tone_hint": tone_hint,
        "style_notes": style_notes,
        "previous_unit_tail": previous_tail
    }
