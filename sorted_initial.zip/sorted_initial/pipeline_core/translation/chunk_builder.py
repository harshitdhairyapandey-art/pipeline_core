"""
pipeline_core/translation/chunk_builder.py
============================================
Builds the translation chunk manifest from preprocessed units.

Uses semantic_chunker for intelligent splitting and
chunk_context_carryover for rich per-chunk context.
"""
from typing import List, Dict, Any, Tuple, Optional

from .provider_profiles import ProviderProfile
from .semantic_chunker import split_unit_semantically
from .chunk_context_carryover import build_chunk_carryover


def _build_chunk_groups(
    units: List[Dict[str, Any]],
    profile: ProviderProfile,
) -> List[Tuple[List[Dict[str, Any]], str]]:
    """
    Groups units into chunks respecting target/max char limits.
    Uses semantic splitting for oversized units.

    Returns:
        List of (group_of_units, split_reason) tuples.
    """
    groups: List[Tuple[List[Dict[str, Any]], str]] = []
    current_group:  List[Dict[str, Any]] = []
    current_chars:  int = 0

    for unit in units:
        text     = unit.get("clean_text", "")
        unit_len = len(text)

        # Unit exceeds hard maximum — split it semantically before grouping
        if unit_len > profile.max_chars_per_chunk:
            # Flush current group first
            if current_group:
                groups.append((current_group, "target_limit_reached"))
                current_group = []
                current_chars = 0

            sub_units = split_unit_semantically(unit, profile.max_chars_per_chunk)
            for su in sub_units:
                groups.append(([su], "split_large_unit"))
            continue

        # Unit fits within target — check if adding it overflows the current group
        if current_chars + unit_len > profile.target_chars_per_chunk and current_group:
            groups.append((current_group, "target_limit_reached"))
            current_group = [unit]
            current_chars = unit_len
        else:
            current_group.append(unit)
            current_chars += unit_len

    if current_group:
        groups.append((current_group, "end_of_units"))

    return groups


def build_chunks(
    job_id:         str,
    units:          List[Dict[str, Any]],
    profile:        ProviderProfile,
    global_context: Optional[Dict[str, Any]] = None,
) -> List[Dict[str, Any]]:
    """
    Main entry point: converts preprocessed units into a list of chunk dicts
    ready to be stored in the batch manifest.

    Each chunk dict contains:
        chunk_id, unit_ids, order_start, order_end,
        estimated_chars, split_reason, context_bundle
    """
    groups = _build_chunk_groups(units, profile)

    chunks: List[Dict[str, Any]] = []
    previous_unit: Optional[Dict[str, Any]] = None

    for idx, (group, split_reason) in enumerate(groups):
        chunk_id  = f"{job_id}_batch_{idx + 1:04d}"
        unit_ids  = [u.get("unit_id") for u in group]

        order_start: Optional[int] = None
        order_end:   Optional[int] = None
        for u in group:
            order = u.get("display_order")
            if order is not None:
                if order_start is None:
                    order_start = order
                order_end = order

        estimated_chars = sum(len(u.get("clean_text", "")) for u in group)

        # Build rich carryover context bundle
        context_bundle = build_chunk_carryover(
            grouped_units  = group,
            previous_unit  = previous_unit,
            global_context = global_context,
        )

        chunks.append({
            "chunk_id":       chunk_id,
            "unit_ids":       unit_ids,
            "order_start":    order_start,
            "order_end":      order_end,
            "estimated_chars": estimated_chars,
            "split_reason":   split_reason,
            "context_bundle": context_bundle,
        })

        # The last unit of this group becomes the previous_unit for the next chunk
        if group:
            previous_unit = group[-1]

    return chunks
