"""
pipeline_core/translation/chunk_context_carryover.py
======================================================
Builds the context bundle attached to each translation chunk.

Each chunk receives:
  - previous_unit_tail: last 300 chars from the previous chunk (continuity)
  - chapter_titles: deduplicated titles of units in this chunk
  - critical_terms: deduplicated glossary terms (limited to top-50)
  - tone_hint: first non-empty tone signal from the chunk
  - style_notes: deduplicated style signals
  - address_hierarchy_slice: relevant address rules (limited to 20)
  - voice_hints: voice profile summary string
  - split_warning: bool — True if chunk was split mid-unit
"""
from typing import List, Dict, Any, Optional


_MAX_TERMS         = 50
_MAX_ADDRESS_HINTS = 20
_TAIL_CHARS        = 300


def build_chunk_carryover(
    grouped_units:  List[Dict[str, Any]],
    previous_unit:  Optional[Dict[str, Any]] = None,
    global_context: Optional[Dict[str, Any]] = None,
) -> Dict[str, Any]:
    """
    Builds the rich context bundle attached to a translation chunk.
    """
    chapter_titles:    List[str] = []
    critical_terms:    List[str] = []
    tone_hint:         str       = ""
    style_notes:       List[str] = []
    address_slice:     List[Dict[str, Any]] = []
    has_split         = False

    for u in grouped_units:
        # Detect split units
        if u.get("_is_split"):
            has_split = True

        crit = u.get("critical_context", {})
        title = crit.get("chapter_title", "")
        if title and title not in chapter_titles:
            chapter_titles.append(title)

        for t in crit.get("critical_terms", []):
            if t and t not in critical_terms:
                critical_terms.append(t)

        if not tone_hint:
            tone_hint = crit.get("tone_hint", "")

        helpful = u.get("helpful_context", {})
        for n in helpful.get("style_notes", []):
            if n and n not in style_notes:
                style_notes.append(n)

        for entry in helpful.get("address_hierarchy", []):
            if len(address_slice) >= _MAX_ADDRESS_HINTS:
                break
            key = entry.get("character_or_role", "")
            if key and not any(e.get("character_or_role") == key for e in address_slice):
                address_slice.append(entry)

    # Previous chunk tail for continuity
    previous_tail = ""
    if previous_unit:
        prev_text = previous_unit.get("clean_text", "")
        if prev_text:
            previous_tail = prev_text[-_TAIL_CHARS:]

    # Voice hints summary
    voice_hints = ""
    if grouped_units:
        first_unit = grouped_units[0]
        voice_ctx  = first_unit.get("helpful_context", {}).get("voice_context", {})
        density    = voice_ctx.get("dialogue_density", "low")
        profiles   = voice_ctx.get("voice_profile", [])
        if profiles:
            style_label = profiles[0].get("voice_style", "narrative")
            voice_hints = f"dialogue_density={density}, dominant_style={style_label}"
        elif density != "low":
            voice_hints = f"dialogue_density={density}"

    # Global glossary slice (top terms only, from global context)
    global_glossary_keys: List[str] = []
    if global_context:
        gmap = global_context.get("glossary_map", {})
        global_glossary_keys = list(gmap.keys())[:30]

    return {
        "chapter_titles":        chapter_titles,
        "critical_terms":        critical_terms[:_MAX_TERMS],
        "tone_hint":             tone_hint,
        "style_notes":           style_notes,
        "previous_unit_tail":    previous_tail,
        "address_hierarchy_slice": address_slice,
        "voice_hints":           voice_hints,
        "global_glossary_keys":  global_glossary_keys,
        "split_warning":         has_split,
    }
