"""
pipeline_core/translation/provider_profiles.py
================================================
Provider profiles define safe operating limits for each translation backend.

Scitely Community safe defaults:
  - 60 RPM hard limit  → safe target 50 RPM
  - 10 RPS burst limit → safe target 2 RPS
  - 600s request timeout
  - 3200 char max per chunk (proven safe under Cloudflare 100s timeout)
"""
from dataclasses import dataclass, field
from typing import Optional


@dataclass
class ProviderProfile:
    name:                    str
    provider:                str
    model:                   str
    role:                    str
    max_chars_per_chunk:     int
    target_chars_per_chunk:  int
    safe_parallel_requests:  int
    supports_strict_json:    bool
    retry_backoff_seconds:   int
    # Rate limits
    rpm_hard_limit:          int = 60
    rpm_safe_target:         int = 50
    rps_burst_limit:         int = 10
    rps_safe_target:         int = 2
    timeout_seconds:         float = 600.0
    # Minimum text length to justify a separate API call
    min_chars_per_chunk:     int = 50


SCITELY_PROFILE = ProviderProfile(
    name                   = "scitely-deepseek-v3.2",
    provider               = "scitely",
    model                  = "deepseek-v3.2",
    role                   = "translation",
    max_chars_per_chunk    = 3200,
    target_chars_per_chunk = 2400,
    min_chars_per_chunk    = 50,
    safe_parallel_requests = 2,
    supports_strict_json   = False,
    retry_backoff_seconds  = 2,
    rpm_hard_limit         = 60,
    rpm_safe_target        = 50,
    rps_burst_limit        = 10,
    rps_safe_target        = 2,
    timeout_seconds        = 600.0,
)
