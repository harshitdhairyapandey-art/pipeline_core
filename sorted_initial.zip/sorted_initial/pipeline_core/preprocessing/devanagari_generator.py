import re
from typing import Dict, Any

def generate_devanagari_hints(unit: Dict[str, Any]) -> Dict[str, Any]:
    """
    Analyzes generic textual components dynamically and returns deterministic 
    transliteration mappings preserving Hindi localization limits reliably.
    """
    hints = []
    
    clean_text = unit.get("clean_text", "")
    chapter_title = unit.get("title", "")
    
    # Accept pre-calculated terms natively passed from upstream assembler bindings safely
    critical_terms = unit.get("temporary_critical_terms", [])
    
    distinct_names = set(re.findall(r'\b[A-Z][a-z]+\b', clean_text))
    
    for term in critical_terms:
        hints.append({
            "source_term": term,
            "suggested_devanagari": f"[{term}_hindi]",
            "term_type": "special_term",
            "confidence": "low"  # Restricted heuristic confidence bound
        })
        if term in distinct_names:
            distinct_names.remove(term)
            
    for name in distinct_names:
        hints.append({
            "source_term": name,
            "suggested_devanagari": f"[{name}_hindi]",
            "term_type": "name",
            "confidence": "low"
        })
        
    if chapter_title:
        hints.append({
            "source_term": chapter_title,
            "suggested_devanagari": f"[{chapter_title}_hindi]",
            "term_type": "title",
            "confidence": "low"
        })
        
    return {
        "devanagari_hints": hints,
        "transliteration_notes": [
            "Deterministic placeholders generated natively without artificial intelligence generation loops."
        ]
    }
