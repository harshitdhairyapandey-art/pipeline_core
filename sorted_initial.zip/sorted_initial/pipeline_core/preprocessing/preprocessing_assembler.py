"""
pipeline_core/preprocessing/preprocessing_assembler.py
========================================================
Assembles deterministic heuristics + optional AI enrichment
into a unified context artifact per unit.

Design:
- Deterministic path always runs first and produces a valid baseline.
- AI enrichment is overlaid on top — failures are logged and silently skipped.
- Output schema is always the same regardless of whether AI ran.
"""
import logging
from typing import Dict, Any, Optional

from .chapter_context_builder import extract_chapter_context
from .glossary_extractor import extract_glossary_terms
from .style_signal_extractor import extract_style_signals
from .devanagari_generator import generate_devanagari_hints
from .character_address_builder import build_character_address_hierarchy
from .volume_flow_builder import build_unit_flow_context
from .character_voice_builder import build_unit_voice_context
from .tts_profile_builder import build_unit_tts_profile

logger = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# Minimum text length to bother calling AI (skip very short units)
# ---------------------------------------------------------------------------
_AI_MIN_TEXT_LEN = 200


def assemble_context(
    unit: Dict[str, Any],
    analyst=None,          # Optional[AIAnalyst]
) -> Dict[str, Any]:
    """
    Builds a full context bundle for a single unit.

    1. Deterministic heuristics run unconditionally.
    2. AI enrichment runs only if analyst is provided AND text is long enough.
    3. AI results are merged on top; failures fall back to heuristic defaults.
    4. Output schema is always identical.
    """
    clean_text = unit.get("clean_text", "")

    # ------------------------------------------------------------------
    # STEP 1 — Deterministic baseline (always runs)
    # ------------------------------------------------------------------
    chapter_ctx = extract_chapter_context(unit)
    glossary    = extract_glossary_terms(clean_text)
    style       = extract_style_signals(clean_text)
    deva_ctx    = generate_devanagari_hints(unit)
    addr_ctx    = build_character_address_hierarchy(unit)

    previous_unit = unit.pop("temporary_previous_unit", None)
    flow_ctx      = build_unit_flow_context(unit, previous_unit)
    voice_ctx     = build_unit_voice_context(unit)

    unit_with_voice = {
        **unit,
        "helpful_context": {"voice_context": voice_ctx.get("voice_context", {})},
    }
    tts_ctx = build_unit_tts_profile(unit_with_voice)

    # Baseline fields
    chapter_title    = chapter_ctx.get("chapter_title", "")
    tone_hint        = chapter_ctx.get("tone_hint", "")
    short_summary    = chapter_ctx.get("short_summary", "")
    scene_type       = "narrative"
    translation_diff = "medium"
    devanagari_hints = deva_ctx.get("devanagari_hints", [])
    address_hierarchy = addr_ctx.get("address_hierarchy", [])

    # ------------------------------------------------------------------
    # STEP 2 — AI enrichment (optional, safe-wrapped)
    # ------------------------------------------------------------------
    ai_enabled = (
        analyst is not None
        and len(clean_text.strip()) >= _AI_MIN_TEXT_LEN
    )

    if ai_enabled:
        # 2a. Chapter meta + glossary
        ai_meta = {}
        try:
            ai_meta = analyst.analyze_chapter_bulk(clean_text)
        except Exception as e:
            logger.warning(f"AIAnalyst.analyze_chapter_bulk failed: {e}")

        if ai_meta:
            meta = ai_meta.get("meta", {})
            if meta.get("scene_type"):
                scene_type = meta["scene_type"]
            if meta.get("translation_difficulty"):
                translation_diff = meta["translation_difficulty"]
            if meta.get("chapter_title"):
                chapter_title = meta["chapter_title"]
            # Use AI tone only if it's a richer signal than the heuristic
            if meta.get("emotion_timeline"):
                tone_hint = ", ".join(meta["emotion_timeline"])

            # Merge AI-discovered glossary terms into unit's critical terms
            ai_glossary_terms = [
                g["term"] for g in ai_meta.get("glossary", [])
                if isinstance(g, dict) and g.get("term")
            ]
            if ai_glossary_terms:
                existing = list(unit.get("temporary_critical_terms", []))
                merged   = list(dict.fromkeys(existing + ai_glossary_terms))
                unit["temporary_critical_terms"] = merged
                # Also extend the heuristic glossary list
                for t in ai_glossary_terms:
                    if t not in glossary:
                        glossary.append(t)

        # 2b. Devanagari generation (only if we have terms to look up)
        if glossary:
            try:
                ai_deva = analyst.generate_devanagari(glossary)
                if ai_deva:
                    devanagari_hints = ai_deva   # AI hints replace placeholder hints
            except Exception as e:
                logger.warning(f"AIAnalyst.generate_devanagari failed: {e}")

        # 2c. Address hierarchy enhancement (only if text is dialogue-rich)
        voice_density = voice_ctx.get("voice_context", {}).get("dialogue_density", "low")
        if voice_density in ("medium", "high"):
            try:
                ai_addr = analyst.detect_address_hierarchy(clean_text[:5000])
                if ai_addr:
                    # Convert AI format → internal format and merge with heuristic results
                    seen = {e.get("character_or_role", "").lower() for e in address_hierarchy}
                    for rel in ai_addr:
                        key = (rel.get("speaker", "") + "_" + rel.get("addressee", "")).lower()
                        if key not in seen:
                            address_hierarchy.append({
                                "character_or_role": f"{rel.get('speaker')} → {rel.get('addressee')}",
                                "suggested_register": rel.get("address_form", "aap"),
                                "reason": rel.get("reason", "AI-detected relationship"),
                                "confidence": "medium",
                            })
                            seen.add(key)
            except Exception as e:
                logger.warning(f"AIAnalyst.detect_address_hierarchy failed: {e}")

    # ------------------------------------------------------------------
    # STEP 3 — Assemble final output (fixed schema)
    # ------------------------------------------------------------------
    return {
        "critical_context": {
            "chapter_title":  chapter_title,
            "critical_terms": glossary,
            "tone_hint":      tone_hint,
        },
        "helpful_context": {
            "style_notes":      style.get("style_notes", []),
            "devanagari_hints": devanagari_hints,
            "address_hierarchy": address_hierarchy,
            "flow_context":     flow_ctx.get("flow_context", {}),
            "voice_context":    voice_ctx.get("voice_context", {}),
            "tts_profile":      tts_ctx.get("tts_profile", {}),
        },
        "analysis": {
            "summary":               short_summary,
            "tone":                  tone_hint,
            "scene_type":            scene_type,
            "translation_difficulty": translation_diff,
        },
    }
