import re
from typing import List

def extract_glossary_terms(clean_text: str) -> List[str]:
    """
    Extracts simple capitalized terms and specific patterns indicative of 
    lore or character names to retain translation consistency natively.
    """
    words = clean_text.split()
    terms = set()
    
    for i, w in enumerate(words):
        # Ignore plausible sentence starters
        if i > 0 and not words[i-1].endswith(('.', '!', '?')):
            clean_word = re.sub(r'[^a-zA-Z]', '', w)
            if clean_word.istitle() and len(clean_word) > 3:
                terms.add(clean_word)
                
    return sorted(list(terms))
