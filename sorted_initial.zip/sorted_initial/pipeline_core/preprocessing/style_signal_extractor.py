from typing import Dict, List

def extract_style_signals(clean_text: str) -> Dict[str, List[str]]:
    """
    Analyzes raw text for stylistic markers via deterministic criteria
    and assigns translation risks.
    """
    notes = []
    risks = []
    
    dialogue_quotes = clean_text.count('"') + clean_text.count("'")
    if dialogue_quotes > 4:
        notes.append("dialogue-heavy")
        risks.append("character voice consistency")
        
    words = clean_text.split()
    avg_length = sum(len(w) for w in words) / max(1, len(words))
    if avg_length > 6.5:
        notes.append("formal tone / dense terminology")
        risks.append("complex sentence structures")
        
    mystical_triggers = {"ritual", "spirit", "sacred", "divine", "ancient"}
    if any(trigger in clean_text.lower() for trigger in mystical_triggers):
        notes.append("mystical/ritual vocabulary")
        risks.append("cultural nuances")
        
    return {
        "style_notes": notes,
        "translation_risks": risks
    }
