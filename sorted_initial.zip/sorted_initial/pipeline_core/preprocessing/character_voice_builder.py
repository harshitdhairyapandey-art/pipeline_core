import re
from typing import Dict, Any, List, Optional
from collections import Counter

# ---------------------------------------------------------------------------
# Dialogue density signals
# ---------------------------------------------------------------------------

_QUOTE_PATTERN = re.compile(r'[""\'\'«»\u201c\u201d\u2018\u2019]')
_EM_DASH_PATTERN = re.compile(r'(?:^|\n)\s*[—–-]\s+\S', re.MULTILINE)
_SHORT_LINE_PATTERN = re.compile(r'(?:^|\n)(.{1,60})(?:\n|$)', re.MULTILINE)

# ---------------------------------------------------------------------------
# Voice style signal patterns
# ---------------------------------------------------------------------------

_FORMAL_SIGNALS = re.compile(
    r'\b(henceforth|therefore|whereas|pursuant|hereby|shall|thee|thou|thy|verily|'
    r'accordingly|aforementioned|hereinafter)\b', re.IGNORECASE
)
_RITUAL_SIGNALS = re.compile(
    r'\b(bless|blessed|sacred|divine|oath|swear|vow|sanctified|holy|rite|ritual|'
    r'ceremony|prayer|incantation|invocation|consecrate)\b', re.IGNORECASE
)
_HOSTILE_SIGNALS = re.compile(
    r'\b(fool|idiot|traitor|coward|enemy|knave|wretch|cur|scoundrel|villain|die|'
    r'kill|destroy|crush|silence|enough)\b', re.IGNORECASE
)
_INTIMATE_SIGNALS = re.compile(
    r'\b(darling|beloved|sweetheart|my love|dearest|honey|closer|hold me|whisper)\b',
    re.IGNORECASE
)
_CASUAL_SIGNALS = re.compile(
    r'\b(hey|yeah|nah|gonna|wanna|dunno|kinda|sorta|gotta|y\'know|alright|ok|okay|'
    r'yep|nope|cya|bye)\b', re.IGNORECASE
)


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _estimate_dialogue_density(text: str) -> str:
    """
    Returns 'low', 'medium', or 'high' based on quote/dash/short-line density.
    """
    total_lines = max(len(text.splitlines()), 1)

    quote_hits = len(_QUOTE_PATTERN.findall(text))
    dash_hits = len(_EM_DASH_PATTERN.findall(text))
    short_lines = len(_SHORT_LINE_PATTERN.findall(text))
    short_line_ratio = short_lines / total_lines

    # Score: weighted sum
    score = (quote_hits * 2) + (dash_hits * 3) + (short_line_ratio * 10)

    if score >= 15:
        return "high"
    elif score >= 5:
        return "medium"
    return "low"


def _infer_voice_style(text: str) -> str:
    """
    Returns the dominant voice style as a single conservative label.
    """
    scores: Counter = Counter()

    if _FORMAL_SIGNALS.search(text):
        scores["formal"] += 2
    if _RITUAL_SIGNALS.search(text):
        scores["ritualistic"] += 2
    if _HOSTILE_SIGNALS.search(text):
        scores["hostile"] += 1
    if _INTIMATE_SIGNALS.search(text):
        scores["intimate"] += 1
    if _CASUAL_SIGNALS.search(text):
        scores["casual"] += 1

    if not scores:
        return "narrative"  # Default: pure narration, no strong signal

    return scores.most_common(1)[0][0]


def _build_voice_profile(text: str, density: str) -> List[Dict[str, str]]:
    """
    Returns a conservative list of speaker/voice hints inferred from text signals.
    No named speakers invented unless strongly implied by dialogue patterns.
    """
    profiles = []
    style = _infer_voice_style(text)

    if density in ("medium", "high"):
        profiles.append({
            "speaker_hint": "dialogue participants (unnamed)",
            "voice_style": style,
            "confidence": "medium" if density == "high" else "low"
        })
    else:
        profiles.append({
            "speaker_hint": "narrator",
            "voice_style": style,
            "confidence": "medium"
        })

    return profiles


def _build_voice_notes(density: str, style: str) -> List[str]:
    notes = []
    if density == "high":
        notes.append("High dialogue density — preserve speaker rhythm and turn-taking breaks.")
    elif density == "medium":
        notes.append("Moderate dialogue — ensure clean transition between narration and speech.")
    else:
        notes.append("Predominantly narrative — maintain consistent narration register.")

    if style == "formal":
        notes.append("Formal/archaic register detected. Preserve elevated diction in translation.")
    elif style == "ritualistic":
        notes.append("Ritualistic language present. Translate ceremonial phrases with care.")
    elif style == "hostile":
        notes.append("Confrontational tone present. Keep aggressive register in translation.")
    elif style == "intimate":
        notes.append("Intimate tone present. Use appropriate softening in Hindi register.")
    elif style == "casual":
        notes.append("Casual/colloquial speech. Reflect in informal Hindi register where appropriate.")

    return notes


# ---------------------------------------------------------------------------
# Public API — A: per-unit
# ---------------------------------------------------------------------------

def build_unit_voice_context(unit: Dict[str, Any]) -> Dict[str, Any]:
    """
    Deterministically infers dialogue density, voice style, and speaker hints
    for a single unit. No AI calls. Conservative confidence throughout.
    """
    text = unit.get("clean_text", "")

    density = _estimate_dialogue_density(text)
    style = _infer_voice_style(text)
    profile = _build_voice_profile(text, density)
    notes = _build_voice_notes(density, style)

    return {
        "voice_context": {
            "dialogue_density": density,
            "voice_profile": profile,
            "voice_notes": notes
        }
    }


# ---------------------------------------------------------------------------
# Public API — B: document-level
# ---------------------------------------------------------------------------

def build_global_voice_profile(units: List[Dict[str, Any]]) -> Dict[str, Any]:
    """
    Aggregates per-unit voice_context entries into a document-level voice profile.
    """
    density_counter: Counter = Counter()
    style_counter: Counter = Counter()
    voice_risks: List[str] = []

    for i, unit in enumerate(units):
        vc = unit.get("helpful_context", {}).get("voice_context", {})
        density = vc.get("dialogue_density", "low")
        density_counter[density] += 1

        for vp in vc.get("voice_profile", []):
            style = vp.get("voice_style", "narrative")
            style_counter[style] += 1

    dominant_density = density_counter.most_common(1)[0][0] if density_counter else "low"
    dominant_style = style_counter.most_common(1)[0][0] if style_counter else "narrative"

    # Risk: dominant density is high but no formal/ritual anchor — inconsistency risk
    if dominant_density == "high" and dominant_style in ("narrative", "formal"):
        voice_risks.append(
            "High dialogue density with primarily formal/narrative voice. "
            "Risk of register inconsistency in translation."
        )

    # Risk: multiple competing styles
    if len(style_counter) >= 3:
        voice_risks.append(
            f"Multiple voice styles detected ({', '.join(style_counter.keys())}). "
            "Ensure translator maintains distinct registers per scene."
        )

    # Narration style label
    if dominant_style == "narrative":
        narration_style = "third-person literary narration"
    elif dominant_style == "formal":
        narration_style = "formal/archaic narration"
    elif dominant_style == "ritualistic":
        narration_style = "ceremonial/ritualistic prose"
    elif dominant_style == "hostile":
        narration_style = "confrontational dialogue-driven"
    elif dominant_style == "intimate":
        narration_style = "intimate character-focused"
    elif dominant_style == "casual":
        narration_style = "colloquial dialogue-driven"
    else:
        narration_style = "mixed"

    return {
        "global_voice_profile": {
            "dominant_dialogue_density": dominant_density,
            "voice_risks": voice_risks,
            "narration_style": narration_style
        }
    }
