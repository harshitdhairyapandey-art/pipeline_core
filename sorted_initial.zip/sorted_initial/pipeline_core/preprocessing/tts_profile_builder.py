import re
from typing import Dict, Any, List
from collections import Counter

# ---------------------------------------------------------------------------
# Pause density signals — punctuation that causes natural TTS pauses
# ---------------------------------------------------------------------------
_PAUSE_CHARS = re.compile(r'[,;:—–\.\!\?\u2026]')  # commas, colons, dashes, ellipsis, stops
_ELLIPSIS_PATTERN = re.compile(r'\.\.\.|…')
_EM_DASH_PATTERN = re.compile(r'[—–]')

# ---------------------------------------------------------------------------
# Emphasis signals — exclamations, short punchy lines, capitalized words
# ---------------------------------------------------------------------------
_EXCLAMATION_PATTERN = re.compile(r'!')
_CAPS_WORD_PATTERN = re.compile(r'\b[A-Z]{2,}\b')  # ALL-CAPS words
_SHORT_PUNCHY_PATTERN = re.compile(r'(?:^|\n)(.{1,40}[!?])(?:\n|$)', re.MULTILINE)

# ---------------------------------------------------------------------------
# Style-to-delivery mapping (conservative)
# ---------------------------------------------------------------------------
_STYLE_TO_DELIVERY = {
    "formal":       "formal",
    "ritualistic":  "ritualistic",
    "hostile":      "dramatic",
    "intimate":     "intimate",
    "casual":       "neutral",
    "narrative":    "neutral",
}


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _compute_pause_density(text: str) -> str:
    word_count = max(len(text.split()), 1)
    pause_hits = len(_PAUSE_CHARS.findall(text))
    ellipsis_hits = len(_ELLIPSIS_PATTERN.findall(text))
    dash_hits = len(_EM_DASH_PATTERN.findall(text))

    # Weighted score per 100 words
    score = ((pause_hits + ellipsis_hits * 2 + dash_hits * 2) / word_count) * 100

    if score >= 18:
        return "high"
    elif score >= 8:
        return "medium"
    return "low"


def _compute_emphasis_level(text: str) -> str:
    word_count = max(len(text.split()), 1)
    exclamation_count = len(_EXCLAMATION_PATTERN.findall(text))
    caps_count = len(_CAPS_WORD_PATTERN.findall(text))
    punchy_count = len(_SHORT_PUNCHY_PATTERN.findall(text))

    score = ((exclamation_count * 3 + caps_count * 2 + punchy_count * 2) / word_count) * 100

    if score >= 10:
        return "high"
    elif score >= 3:
        return "medium"
    return "low"


def _derive_delivery_style(unit: Dict[str, Any], tone_hint: str) -> str:
    """
    Derive TTS delivery style from voice_context (if present) or tone_hint fallback.
    Conservative: defaults to neutral when signal is weak.
    """
    # Prefer already-computed voice style from voice_context in helpful_context
    voice_ctx = unit.get("helpful_context", {}).get("voice_context", {})
    voice_profile = voice_ctx.get("voice_profile", [])
    if voice_profile:
        raw_style = voice_profile[0].get("voice_style", "narrative")
        return _STYLE_TO_DELIVERY.get(raw_style, "neutral")

    # Fallback: map tone_hint
    tone_lower = (tone_hint or "").lower()
    if "formal" in tone_lower or "archaic" in tone_lower:
        return "formal"
    if "ritual" in tone_lower or "sacred" in tone_lower or "mystical" in tone_lower:
        return "ritualistic"
    if "hostile" in tone_lower or "conflict" in tone_lower or "tense" in tone_lower:
        return "dramatic"
    if "intimate" in tone_lower or "romantic" in tone_lower:
        return "intimate"

    return "neutral"


def _build_tts_notes(delivery: str, pause_density: str, emphasis: str) -> List[str]:
    notes = []

    if delivery == "dramatic":
        notes.append("Dramatic delivery — increase pace variance and emotional weight in TTS.")
    elif delivery == "formal":
        notes.append("Formal delivery — steady pace, clear enunciation, minimal emotion.")
    elif delivery == "ritualistic":
        notes.append("Ritualistic delivery — slow, deliberate, reverential pacing.")
    elif delivery == "intimate":
        notes.append("Intimate delivery — soft tone, lower volume modulation, close register.")
    else:
        notes.append("Neutral delivery — standard pacing and inflection.")

    if pause_density == "high":
        notes.append("High punctuation density — insert TTS pauses at all marked boundaries.")
    elif pause_density == "medium":
        notes.append("Moderate pausing — standard breath markers apply.")

    if emphasis == "high":
        notes.append("High emphasis signals — stress key words at exclamation and caps markers.")
    elif emphasis == "medium":
        notes.append("Moderate emphasis — light stress on punchy phrases.")

    return notes


# ---------------------------------------------------------------------------
# Public API — A: per-unit
# ---------------------------------------------------------------------------

def build_unit_tts_profile(unit: Dict[str, Any]) -> Dict[str, Any]:
    """
    Deterministically infers TTS delivery style, pause density, and emphasis level
    for a single unit using punctuation and voice context signals only.
    No AI calls. Conservative heuristics throughout.
    """
    text = unit.get("clean_text", "")
    tone_hint = unit.get("critical_context", {}).get("tone_hint", "")

    delivery = _derive_delivery_style(unit, tone_hint)
    pause_density = _compute_pause_density(text)
    emphasis = _compute_emphasis_level(text)
    notes = _build_tts_notes(delivery, pause_density, emphasis)

    return {
        "tts_profile": {
            "delivery_style": delivery,
            "pause_density": pause_density,
            "emphasis_level": emphasis,
            "tts_notes": notes
        }
    }


# ---------------------------------------------------------------------------
# Public API — B: document-level
# ---------------------------------------------------------------------------

def build_global_tts_profile(units: List[Dict[str, Any]]) -> Dict[str, Any]:
    """
    Aggregates per-unit tts_profile entries into a document-level TTS summary.
    """
    delivery_counter: Counter = Counter()
    consistency_notes: List[str] = []

    for unit in units:
        tp = unit.get("helpful_context", {}).get("tts_profile", {})
        delivery = tp.get("delivery_style", "neutral")
        delivery_counter[delivery] += 1

    dominant = delivery_counter.most_common(1)[0][0] if delivery_counter else "neutral"

    # Flag significant style fragmentation
    if len(delivery_counter) >= 3:
        styles = ", ".join(delivery_counter.keys())
        consistency_notes.append(
            f"Multiple TTS delivery styles detected ({styles}). "
            "Ensure TTS engine supports dynamic style switching or segment accordingly."
        )

    # Flag dramatic-dominant documents
    if dominant == "dramatic":
        consistency_notes.append(
            "Dominant dramatic delivery — verify the TTS voice model supports emotional variance."
        )

    # Flag ritualistic-dominant documents
    if dominant == "ritualistic":
        consistency_notes.append(
            "Dominant ritualistic delivery — ensure slow pace and reverential tone is consistently applied."
        )

    if not consistency_notes:
        consistency_notes.append(
            f"Consistent '{dominant}' delivery style across units. No major TTS inconsistencies detected."
        )

    return {
        "global_tts_profile": {
            "dominant_delivery_style": dominant,
            "recommended_consistency_notes": consistency_notes
        }
    }
