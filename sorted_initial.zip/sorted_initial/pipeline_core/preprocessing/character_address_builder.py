import re
from typing import Dict, Any, List

# Honorifics that strongly signal "aap" (formal/respectful) register
_HONORIFICS_AAP = {
    "sir", "lord", "mister", "mr", "miss", "ms", "mrs", "madam", "lady",
    "captain", "major", "general", "colonel", "admiral", "commander",
    "priest", "archbishop", "bishop", "cardinal", "reverend", "father",
    "professor", "doctor", "dr", "judge", "chancellor", "minister",
    "president", "emperor", "empress", "king", "queen", "prince", "princess",
    "duke", "duchess", "baron", "baroness", "earl", "countess", "count",
    "master", "guru", "maharaj", "sahib", "saheb"
}

# Words/phrases signalling peer/friendly — "tum" register
_PEER_SIGNALS = {
    "friend", "buddy", "pal", "mate", "dude", "bro", "sis",
    "yaar", "dost", "comrade"
}

# Patterns that may signal hostile/intimate/low-distance — "tu" register (low confidence)
_TU_HOSTILE_PATTERN = re.compile(
    r'\b(enemy|foe|villain|traitor|coward|fool|idiot|bastard|knave|wretch)\b',
    re.IGNORECASE
)
_TU_INTIMATE_PATTERN = re.compile(
    r'\b(darling|sweetheart|beloved|my love|dearest|honey)\b',
    re.IGNORECASE
)


def _infer_register_for_term(term: str, clean_text: str) -> Dict[str, str]:
    """
    Core register inference for a single character/role name or title.
    Returns a dict with suggested_register, reason, confidence.
    """
    term_lower = term.strip().lower()

    # Honorific → aap
    if term_lower in _HONORIFICS_AAP:
        return {
            "suggested_register": "aap",
            "reason": f"'{term}' is a formal honorific or title requiring respectful address.",
            "confidence": "high"
        }

    # Peer signal → tum
    if term_lower in _PEER_SIGNALS:
        return {
            "suggested_register": "tum",
            "reason": f"'{term}' implies a peer or friendly relationship.",
            "confidence": "medium"
        }

    # Check surrounding text for hostile/intimate hints → tu (low confidence)
    if _TU_HOSTILE_PATTERN.search(clean_text):
        return {
            "suggested_register": "tu",
            "reason": "Hostile or confrontational context detected in surrounding text.",
            "confidence": "low"
        }

    if _TU_INTIMATE_PATTERN.search(clean_text):
        return {
            "suggested_register": "tu",
            "reason": "Intimate or romantic context detected in surrounding text.",
            "confidence": "low"
        }

    # Fallback to neutral
    return {
        "suggested_register": "neutral",
        "reason": f"No strong register signal found for '{term}'. Defaulting to neutral.",
        "confidence": "low"
    }


def build_character_address_hierarchy(unit: Dict[str, Any]) -> Dict[str, Any]:
    """
    Analyzes unit context to produce deterministic address register assignments
    for characters, roles, and honorifics present natively in the source text.
    No AI calls. Conservative confidence. Strict heuristic logic only.
    """
    clean_text = unit.get("clean_text", "")
    chapter_title = unit.get("title", "")
    critical_terms: List[str] = unit.get("temporary_critical_terms", [])
    style_notes: List[str] = unit.get("temporary_style_notes", [])

    address_hierarchy: List[Dict[str, str]] = []
    seen: set = set()

    # 1. Scan critical terms passed from assembler
    for term in critical_terms:
        key = term.strip().lower()
        if key in seen:
            continue
        seen.add(key)
        reg = _infer_register_for_term(term, clean_text)
        address_hierarchy.append({
            "character_or_role": term,
            **reg
        })

    # 2. Scan for raw honorifics directly in text (catch titles not in glossary)
    for honorific in _HONORIFICS_AAP:
        pattern = re.compile(r'\b' + re.escape(honorific) + r'\b', re.IGNORECASE)
        if pattern.search(clean_text):
            key = honorific.lower()
            if key not in seen:
                seen.add(key)
                address_hierarchy.append({
                    "character_or_role": honorific.capitalize(),
                    "suggested_register": "aap",
                    "reason": f"Honorific '{honorific}' found directly in text.",
                    "confidence": "high"
                })

    # 3. Include chapter title as a role if present
    if chapter_title:
        key = chapter_title.strip().lower()
        if key not in seen:
            seen.add(key)
            reg = _infer_register_for_term(chapter_title, clean_text)
            address_hierarchy.append({
                "character_or_role": chapter_title,
                **reg
            })

    address_notes = []
    if not address_hierarchy:
        address_notes.append("No clear characters or roles detected. Register defaulted to neutral globally.")
    else:
        address_notes.append(
            f"{len(address_hierarchy)} character/role address entries generated via deterministic heuristics."
        )

    return {
        "address_hierarchy": address_hierarchy,
        "address_notes": address_notes
    }
