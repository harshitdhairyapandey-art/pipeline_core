"""
pipeline_core/preprocessing/ai_analyst.py
==========================================
AIAnalyst — optional AI enrichment for preprocessing.

DESIGN CONTRACT:
- Every public method catches ALL exceptions and returns safe empty defaults.
- Callers must never crash due to AI failure.
- All provider calls go through _call_safe() which has a broad except clause.
"""
import json
import logging
from typing import List, Dict, Any, Optional

logger = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# Prompts
# ---------------------------------------------------------------------------

CHAPTER_ANALYST_SYSTEM = """You are a senior literary analyst. Analyze this chapter and return a JSON object:
{
  "meta": {
    "story_focus": ["3 specific strings"],
    "emotion_timeline": ["3-4 single emotion words"],
    "character_state": {"CharacterName": "one-line psychological state"},
    "scene_type": "action|grief|horror|philosophical|dialogue|investigation|ritual|other",
    "position": "opening|buildup|midpoint|climax|resolution|aftermath",
    "translation_difficulty": "low|medium|high|very_high"
  },
  "glossary": [{"term": "ExactEnglishTerm", "type": "character|place|organization|item|system_term"}]
}
Return raw JSON only. No preamble."""

DEVANAGARI_SYSTEM = """You are a senior Hindi literary translator. Generate Devanagari for each term.
- Names/Lore: Transliterate phonetically.
- Titles/Generic Items: Translate into natural Hindi equivalents (e.g. Noble -> अभिजात).
Return JSON: {"translations": [{"term": "EnglishTerm", "devanagari": "देवनागरी", "type": "character|place|organization|item|system_term"}]}
Return raw JSON only."""

ADDRESS_SYSTEM = """Analyze character relationships and dialogue to determine Hindi address forms (tu|tum|aap).
Return JSON: {"relationships": [{"speaker": "Name", "addressee": "Name", "address_form": "tu|tum|aap", "reason": "brief reason"}]}
Return raw JSON only."""

VOICE_SYSTEM = """Build character voice profiles from the text. Register, speech style, notable patterns.
Return JSON: {"CharacterName": {"speech_style": "description", "register": "Hindi register", "notable_patterns": "one sentence"}}
Return raw JSON only."""

FLOW_SYSTEM = """Analyze narrative structure: arc, turning points, emotional trajectory, dominant tone.
Return JSON: {"arc": "arc description", "turning_points": ["list"], "emotional_trajectory": "trajectory", "dominant_tone": "tone"}
Return raw JSON only."""

TTS_SYSTEM = """Build TTS voice profiles for narrator and named characters.
Return JSON: {"narrator": {"gender": "...", "age": "...", "pace": "...", "pitch": "..."}, "CharacterName": {same fields}}
Return raw JSON only."""

# Minimum text length before bothering the AI
_MIN_TEXT_LEN = 200


def _safe_json_parse(raw: str, expected_type=dict) -> Any:
    """Parse JSON, returning empty default on any failure."""
    if not raw or not raw.strip():
        return expected_type()
    try:
        result = json.loads(raw.strip())
        if isinstance(result, expected_type):
            return result
        return expected_type()
    except (json.JSONDecodeError, ValueError):
        if expected_type is dict:
            s, e = raw.find("{"), raw.rfind("}")
        else:
            s, e = raw.find("["), raw.rfind("]")
        if s >= 0 and e > s:
            try:
                result = json.loads(raw[s:e + 1])
                if isinstance(result, expected_type):
                    return result
            except (json.JSONDecodeError, ValueError):
                pass
        return expected_type()


class AIAnalyst:
    def __init__(self, provider):
        self.provider = provider

    def _call_safe(self, system_prompt: str, user_text: str, temperature: float = 0.2) -> str:
        """Call provider.call_ai with a broad exception catch. Returns '' on any failure."""
        try:
            return self.provider.call_ai(system_prompt, user_text, temperature=temperature)
        except Exception as e:
            logger.warning(f"AIAnalyst provider call failed ({type(e).__name__}): {e}")
            return ""

    def analyze_chapter_bulk(self, text: str) -> Dict[str, Any]:
        """
        Stage 1: Chapter meta + glossary.
        Returns {} on failure OR if 'meta' key is missing (invalid structure).
        """
        if not text or len(text.strip()) < _MIN_TEXT_LEN:
            return {}
        raw    = self._call_safe(CHAPTER_ANALYST_SYSTEM, text[:6000], temperature=0.2)
        result = _safe_json_parse(raw, dict)
        # Require 'meta' key — otherwise the structure is unusable
        if not isinstance(result.get("meta"), dict):
            return {}
        return result

    def generate_devanagari(self, terms: List[str]) -> List[Dict[str, str]]:
        """Stage 1b: Devanagari generation. Returns [] on failure or empty input."""
        if not terms:
            return []
        raw  = self._call_safe(DEVANAGARI_SYSTEM, "\n".join(terms[:40]), temperature=0.1)
        data = _safe_json_parse(raw, dict)
        translations = data.get("translations", [])
        if not isinstance(translations, list):
            return []
        # Keep only entries with both 'term' and non-empty 'devanagari'
        return [
            t for t in translations
            if isinstance(t, dict)
            and t.get("term")
            and t.get("devanagari")
            and t["devanagari"].strip()
        ]

    def detect_address_hierarchy(self, chapters_sample: str) -> List[Dict[str, Any]]:
        """Stage 1c: tu/tum/aap hierarchy. Returns [] on failure."""
        if not chapters_sample or len(chapters_sample.strip()) < 100:
            return []
        raw  = self._call_safe(ADDRESS_SYSTEM, chapters_sample[:10000], temperature=0.1)
        data = _safe_json_parse(raw, dict)
        relationships = data.get("relationships", [])
        if not isinstance(relationships, list):
            return []
        return [
            r for r in relationships
            if isinstance(r, dict) and r.get("speaker") and r.get("address_form")
        ]

    def build_voice_profiles(self, chapters_sample: str) -> Dict[str, Any]:
        """Stage 4: Character voice profiles. Returns {} on failure."""
        if not chapters_sample or len(chapters_sample.strip()) < 100:
            return {}
        raw = self._call_safe(VOICE_SYSTEM, chapters_sample[:8000], temperature=0.3)
        return _safe_json_parse(raw, dict)

    def build_volume_flow(self, chapters_sample: str) -> Dict[str, Any]:
        """Stage 5: Volume flow analysis. Returns {} on failure."""
        if not chapters_sample or len(chapters_sample.strip()) < 100:
            return {}
        raw = self._call_safe(FLOW_SYSTEM, chapters_sample[:10000], temperature=0.2)
        return _safe_json_parse(raw, dict)

    def build_tts_profiles(self, voice_context: str, chapters_sample: str) -> Dict[str, Any]:
        """Stage 5b: TTS profiles. Returns {} on failure."""
        if not chapters_sample:
            return {}
        user_text = f"VOICE CONTEXT:\n{voice_context}\n\nNOVEL SAMPLE:\n{chapters_sample[:5000]}"
        raw = self._call_safe(TTS_SYSTEM, user_text, temperature=0.2)
        return _safe_json_parse(raw, dict)
