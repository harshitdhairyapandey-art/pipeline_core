from typing import Dict, Any

def extract_chapter_context(unit: Dict[str, Any]) -> Dict[str, str]:
    """
    Extracts structural chapter hints from the raw unit utilizing 
    lightweight heuristics.
    """
    text = unit.get("clean_text", "")
    title = unit.get("title", "")
    
    if not title and len(text) < 150 and ("Chapter" in text or "Part" in text):
        title = text.strip()
        
    tone_hint = "Narrative"
    if "!" in text:
        tone_hint = "Dramatic/Exciting"
    elif "?" in text:
        tone_hint = "Inquisitive"
        
    summary = text[:60] + "..." if len(text) > 60 else text
    
    return {
        "chapter_title": title,
        "short_summary": summary,
        "tone_hint": tone_hint,
        "continuity_note": "Follows established narrative flow."
    }
