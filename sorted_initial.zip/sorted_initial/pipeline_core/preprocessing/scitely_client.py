"""
Scitely API client with:
- Slot-reservation rate limiting
- 3-tier smart retry (snap-back, backoff, circuit break)
- Event bus integration for streaming retry status to UI
"""
import os
import re
import json
import time
import requests

from rate_limiter import acquire_slot
from streaming.event_bus import bus


_consecutive_failures = 0
_circuit_open_until = 0.0
CIRCUIT_THRESHOLD = 8
CIRCUIT_COOLDOWN = 30.0


def _check_circuit():
    global _circuit_open_until
    if time.time() < _circuit_open_until:
        raise RuntimeError(
            f"Circuit breaker open until {time.ctime(_circuit_open_until)}"
        )


def _record_failure():
    global _consecutive_failures, _circuit_open_until
    _consecutive_failures += 1
    if _consecutive_failures >= CIRCUIT_THRESHOLD:
        _circuit_open_until = time.time() + CIRCUIT_COOLDOWN
        bus.emit("circuit_break", cooldown=CIRCUIT_COOLDOWN)


def _record_success():
    global _consecutive_failures
    _consecutive_failures = 0


def _raw_call(url, headers, payload, timeout):
    try:
        resp = requests.post(url, headers=headers, json=payload, timeout=timeout)
        raw = (resp.text or "").strip()
        if not raw or raw.startswith("<!DOCTYPE") or raw.startswith("<html"):
            return ""
        data = resp.json()
        status = str(data.get("status", "200"))
        if status == "449":
            time.sleep(2)
            return ""
        if status not in ("200", ""):
            return ""
        choices = data.get("choices", [])
        if not choices:
            return ""
        content = choices[0].get("message", {}).get("content", "").strip()
        return content
    except Exception:
        return ""


def scitely_call(model, system_prompt, user_text,
                 temperature=0.2, max_tokens=4096, timeout=90,
                 job_id="", chunk_id=""):
    _check_circuit()

    api_key = os.getenv("SCITELY_API_KEY", "")
    if not api_key:
        raise ValueError("SCITELY_API_KEY not set")

    url = "https://api.scitely.com/v1/chat/completions"
    headers = {"Authorization": f"Bearer {api_key}"}
    payload = {
        "model": model,
        "messages": [
            {"role": "system", "content": system_prompt},
            {"role": "user", "content": user_text},
        ],
        "max_tokens": max_tokens,
        "temperature": temperature,
    }

    # Tier 1: Snap-back (3 immediate retries, ~100ms jitter)
    for attempt in range(3):
        acquire_slot()
        content = _raw_call(url, headers, payload, timeout)
        if content and len(content.strip()) > 5:
            _record_success()
            return content
        if job_id:
            bus.retry(job_id, chunk_id, attempt + 1, "snap-back", "empty response")
        time.sleep(0.05 + 0.05 * attempt)

    # Tier 2: Short backoff (3 retries, exponential)
    for n in range(1, 4):
        acquire_slot()
        content = _raw_call(url, headers, payload, timeout)
        if content and len(content.strip()) > 5:
            _record_success()
            return content
        sleep_for = 1.5 ** n
        if job_id:
            bus.retry(job_id, chunk_id, 3 + n, "backoff",
                      f"sleeping {sleep_for:.1f}s")
        time.sleep(sleep_for)

    # Tier 3: Circuit breaker check
    _record_failure()
    raise RuntimeError(f"Scitely empty after 6 retries for {chunk_id}")


def scitely_call_json(model, system_prompt, user_text,
                      temperature=0.2, max_tokens=4096, timeout=90,
                      job_id="", chunk_id=""):
    for _ in range(3):
        content = scitely_call(model, system_prompt, user_text,
                               temperature, max_tokens, timeout,
                               job_id, chunk_id)
        if not content:
            continue
        try:
            clean = re.sub(r"```(?:json)?", "", content,
                           flags=re.IGNORECASE).strip().rstrip("`").strip()
            return json.loads(clean)
        except json.JSONDecodeError:
            # Try to find JSON object in the response
            start = clean.find("{")
            end = clean.rfind("}")
            if start >= 0 and end > start:
                try:
                    return json.loads(clean[start:end + 1])
                except json.JSONDecodeError:
                    continue
    raise RuntimeError("Failed to parse JSON from Scitely response")
