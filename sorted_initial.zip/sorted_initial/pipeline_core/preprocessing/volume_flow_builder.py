import re
from typing import Dict, Any, List, Optional

# ---------------------------------------------------------------------------
# Heuristic helpers
# ---------------------------------------------------------------------------

_OPENING_SIGNALS = re.compile(
    r'\b(once upon a time|in the beginning|it began|long ago|chapter one|chapter 1|prologue|introduction|preface)\b',
    re.IGNORECASE
)
_ENDING_SIGNALS = re.compile(
    r'\b(the end|epilogue|conclusion|finally|at last|ever after|thus ends|thus concluded)\b',
    re.IGNORECASE
)
_CLIMAX_SIGNALS = re.compile(
    r'\b(suddenly|at that moment|everything changed|the final|battle|confronted|exploded|screamed|roared|shattered)\b',
    re.IGNORECASE
)
_TRANSITION_SIGNALS = re.compile(
    r'\b(meanwhile|later|the next day|after that|however|on the other hand|some time passed|days later|weeks later|months later)\b',
    re.IGNORECASE
)


def _detect_narrative_position(unit: Dict[str, Any], previous_unit: Optional[Dict[str, Any]]) -> str:
    """Heuristically infers the rough narrative position of this unit."""
    order = unit.get("display_order", 0)
    text = unit.get("clean_text", "")
    title = unit.get("title", "")

    # Explicit title present → likely a chapter/section opener
    if title:
        if order == 0:
            return "opening"
        return "transition"

    if _OPENING_SIGNALS.search(text) and order <= 1:
        return "opening"
    if _ENDING_SIGNALS.search(text):
        return "ending"
    if _CLIMAX_SIGNALS.search(text):
        return "climax"
    if _TRANSITION_SIGNALS.search(text):
        return "transition"
    if previous_unit is None:
        return "opening"

    return "middle"


def _build_continuity_summary(unit: Dict[str, Any], previous_unit: Optional[Dict[str, Any]]) -> str:
    """Produce a short deterministic continuity note linking to previous unit."""
    if previous_unit is None:
        return "First unit in document. No prior context."

    prev_title = previous_unit.get("title", "")
    prev_order = previous_unit.get("display_order", "?")
    curr_order = unit.get("display_order", "?")

    if prev_title:
        return f"Follows unit {prev_order} ('{prev_title}'). Maintain narrative continuity."
    return f"Follows unit {prev_order}. Ensure character voice and context carry forward to unit {curr_order}."


def _detect_flow_notes(unit: Dict[str, Any], position: str) -> List[str]:
    """Generate actionable flow notes based on position and content signals."""
    notes = []
    text = unit.get("clean_text", "")
    word_count = len(text.split())

    if word_count < 30:
        notes.append("Very short unit — likely a scene break or heading. Handle register carefully.")
    elif word_count > 600:
        notes.append("Long unit — check for multiple scene shifts within the same chunk.")

    if position == "climax":
        notes.append("Climax-adjacent unit. Preserve urgency and action-driven pacing in translation.")
    if position == "transition":
        notes.append("Transition unit. Ensure time/scene markers translate clearly.")
    if position == "ending":
        notes.append("Closing unit. Preserve tonal resolution; avoid abrupt endings.")

    if not notes:
        notes.append("Standard narrative unit. Maintain consistent register and pacing.")

    return notes


# ---------------------------------------------------------------------------
# Public API — A: per-unit
# ---------------------------------------------------------------------------

def build_unit_flow_context(
    unit: Dict[str, Any],
    previous_unit: Optional[Dict[str, Any]] = None
) -> Dict[str, Any]:
    """
    Builds a deterministic flow context entry for a single unit, relative to
    the preceding unit. No AI calls. Conservative heuristics only.
    """
    position = _detect_narrative_position(unit, previous_unit)
    summary = _build_continuity_summary(unit, previous_unit)
    notes = _detect_flow_notes(unit, position)

    return {
        "flow_context": {
            "continuity_summary": summary,
            "narrative_position": position,
            "flow_notes": notes
        }
    }


# ---------------------------------------------------------------------------
# Public API — B: document-level
# ---------------------------------------------------------------------------

def build_volume_flow(units: List[Dict[str, Any]]) -> Dict[str, Any]:
    """
    Builds a document-level volume flow summary by aggregating per-unit positions,
    tone progressions, and detecting continuity risks conservatively.
    """
    positions: List[str] = []
    tone_progression: List[str] = []
    continuity_risks: List[str] = []

    for i, unit in enumerate(units):
        fc = unit.get("helpful_context", {}).get("flow_context", {})
        pos = fc.get("narrative_position", "unknown")
        positions.append(pos)

        tone = unit.get("critical_context", {}).get("tone_hint", "")
        if tone and (not tone_progression or tone_progression[-1] != tone):
            tone_progression.append(tone)

        # Flag abrupt consecutive transitions
        if i > 0 and pos == "transition" and positions[i - 1] == "transition":
            continuity_risks.append(
                f"Two consecutive transition units at positions {i - 1}–{i}. "
                "Check for missing bridging content."
            )

        # Flag no ending detected in final unit
        if i == len(units) - 1 and pos not in ("ending", "middle"):
            continuity_risks.append(
                "Final unit does not strongly signal an ending. Verify document completeness."
            )

    # Dominant arc — most common position label
    from collections import Counter
    pos_counter = Counter(positions)
    dominant_arc = pos_counter.most_common(1)[0][0] if pos_counter else "unknown"

    if not tone_progression:
        tone_progression = ["undetermined"]

    return {
        "volume_flow": {
            "dominant_arc": dominant_arc,
            "tone_progression": tone_progression,
            "continuity_risks": continuity_risks
        }
    }
