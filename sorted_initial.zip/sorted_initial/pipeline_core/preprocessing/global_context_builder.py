from typing import List, Dict, Any
from collections import Counter

from .volume_flow_builder import build_volume_flow
from .character_voice_builder import build_global_voice_profile
from .tts_profile_builder import build_global_tts_profile

def build_global_context(units: List[Dict[str, Any]]) -> Dict[str, Any]:
    """
    Computes document-level characteristics organically by aggregating
    unit-level heuristic traits securely and deterministically.
    Includes volume flow summary derived from per-unit flow_context entries.
    """
    term_counter = Counter()
    tone_counter = Counter()
    style_counter = Counter()

    for unit in units:
        # 1. Aggregate Glossary Terms
        critical = unit.get("critical_context", {})
        for term in critical.get("critical_terms", []):
            term_counter[term] += 1

        # 2. Aggregate Tone
        tone = critical.get("tone_hint")
        if tone:
            tone_counter[tone] += 1

        # 3. Aggregate Style Features
        helpful = unit.get("helpful_context", {})
        for notes in helpful.get("style_notes", []):
            style_counter[notes] += 1

    # Compile Glossary Top 25 (deduplicated automatically by Counter)
    global_glossary = [term for term, count in term_counter.most_common(25)]

    # Compile Global Tone (majority rules)
    global_tone = "Narrative"
    if tone_counter:
        global_tone = tone_counter.most_common(1)[0][0]

    # Compile Style Profile (Threshold based heuristic)
    style_profile = []
    total_units = max(len(units), 1)

    # If a trait appears in 20% of text blocks, flag it globally
    threshold = total_units * 0.2

    if style_counter.get("dialogue-heavy", 0) > threshold:
        style_profile.append("dialogue_heavy")
    if style_counter.get("formal tone / dense terminology", 0) > threshold:
        style_profile.append("dense_terminology")
    if not style_profile:
        style_profile.append("descriptive_style")

    # Volume flow — document-level narrative arc summary
    volume_flow_data = build_volume_flow(units)

    # Global voice profile — aggregated dialogue density and narration style
    voice_profile_data = build_global_voice_profile(units)

    # Global TTS profile — dominant delivery style and consistency notes
    tts_profile_data = build_global_tts_profile(units)

    return {
        "global_glossary": global_glossary,
        "global_tone": global_tone,
        "style_profile": style_profile,
        "notes": [],
        **volume_flow_data,
        **voice_profile_data,
        **tts_profile_data
    }

