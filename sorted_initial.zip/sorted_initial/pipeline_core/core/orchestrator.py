"""
pipeline_core/core/orchestrator.py
=====================================
Async orchestrator — replaces sync blocking execution with asyncio.

Key changes from sync version:
  - run_pipeline() is now async
  - Each stage runs in a ThreadPoolExecutor via run_in_executor
    so the event loop stays free during blocking IO / AI calls
  - Dynamic progress: counts total units after ingestion,
    emits per-unit progress within heavy stages (translation, polishing,
    publishing, postprocessing) via a callback injected into stage_input.context
  - Hardcoded STAGE_PROGRESS_MAP replaced with range-based math

Progress ranges (must sum to 100):
  INGESTION        0  → 5
  PREPROCESSING    5  → 25
  BATCH_PLANNING   25 → 30
  TRANSLATION      30 → 75
  POLISHING        75 → 88
  POSTPROCESSING   88 → 93
  PUBLISHING       93 → 98
  EXPORT           98 → 100
"""
import asyncio
import json
import logging
import os
from concurrent.futures import ThreadPoolExecutor
from datetime import datetime
from typing import Optional, Tuple

from .models import PipelineJob, JobStatus, StageType, StageStatus, StageInput, StageResult, StageOutput
from ..runtime.event_logger import EventLogger
from ..runtime.artifact_index import ArtifactIndex
from ..runtime.checkpoint_store import save_checkpoint
from ..runtime.resume_manager import get_resume_state
from ..streaming.event_bus import bus

logger = logging.getLogger(__name__)

# ── Progress ranges per stage ────────────────────────────────────────────────
# (start_pct, end_pct) — end_pct of stage N == start_pct of stage N+1
STAGE_RANGES = {
    "INGESTION":       (0,   5),
    "PREPROCESSING":   (5,   25),
    "BATCH_PLANNING":  (25,  30),
    "TRANSLATION":     (30,  75),
    "POLISHING":       (75,  88),
    "POSTPROCESSING":  (88,  93),
    "PUBLISHING":      (93,  98),
    "EXPORT":          (98,  100),
}


def _make_unit_progress_fn(
    job_id:     str,
    stage_name: str,
    stage_start: float,
    stage_end:   float,
    total_units: int,
) -> callable:
    """
    Returns a callback: on_unit_done(units_done: int) → None

    Stages that loop over units call this after each unit completes.
    Emits a fine-grained progress event so the frontend progress bar
    advances smoothly within the stage instead of jumping at stage boundaries.

    math:  pct = stage_start + (units_done / total_units) * (stage_end - stage_start)
    """
    span = stage_end - stage_start

    def _on_unit_done(units_done: int) -> None:
        if total_units <= 0:
            return
        pct = stage_start + (units_done / total_units) * span
        bus.progress(job_id, stage_name, round(pct, 1),
                     chapter=units_done, total=total_units)

    return _on_unit_done


def _read_unit_count(artifact_path: Optional[str]) -> int:
    """
    Try to read unit count from a stage artifact JSON.
    Returns 0 on any failure — progress math degrades gracefully to stage-level only.
    """
    if not artifact_path or not os.path.exists(artifact_path):
        return 0
    try:
        with open(artifact_path, "r", encoding="utf-8") as f:
            data = json.load(f)
        return len(data.get("units", []))
    except Exception:
        return 0


def validate_stage_transition(current_status: StageStatus, next_status: StageStatus):
    valid_transitions = {
        StageStatus.NOT_STARTED: [StageStatus.RUNNING, StageStatus.SKIPPED, StageStatus.CANCELLED],
        StageStatus.RUNNING:     [StageStatus.COMPLETED, StageStatus.FAILED, StageStatus.CANCELLED],
        StageStatus.COMPLETED:   [],
        StageStatus.FAILED:      [],
        StageStatus.SKIPPED:     [],
        StageStatus.CANCELLED:   [],
    }
    if next_status not in valid_transitions.get(current_status, []):
        raise ValueError(
            f"Invalid stage transition: {current_status.name} → {next_status.name}"
        )


def validate_stage_output(output: StageOutput):
    if output.status == StageStatus.COMPLETED:
        if not output.output_artifact_path:
            raise ValueError(f"Stage {output.stage.name} COMPLETED but missing output_artifact_path")
        if not os.path.exists(output.output_artifact_path):
            raise FileNotFoundError(f"Output artifact {output.output_artifact_path} does not exist")
    elif output.status == StageStatus.FAILED:
        if not output.error_message:
            raise ValueError(f"Stage {output.stage.name} FAILED but missing error_message")
    elif output.status in (StageStatus.CANCELLED, StageStatus.SKIPPED):
        if output.output_artifact_path:
            raise ValueError(
                f"Stage {output.stage.name} {output.status.name} must not produce output_artifact_path"
            )


class Orchestrator:
    def __init__(self, stages: list):
        self.stages   = stages
        self._executor = ThreadPoolExecutor(
            max_workers=4,
            thread_name_prefix="pipeline_stage"
        )

    async def run_pipeline(self, job: PipelineJob):
        """
        Async pipeline runner.

        Each stage.execute() is a sync blocking call — it runs in a
        ThreadPoolExecutor so it never blocks the FastAPI event loop.
        Between stages the event loop is fully free.
        """
        loop = asyncio.get_event_loop()

        job.status     = JobStatus.RUNNING
        job.updated_at = datetime.now()
        job.progress   = 0

        logger_ev = EventLogger(job.working_dir)
        index     = ArtifactIndex(job.working_dir)

        bus.status(job.job_id, "Initializing async pipeline execution.")

        resume_state          = get_resume_state(job, self.stages)
        start_index: int      = resume_state["start_index"]
        current_artifact_path = resume_state["artifact_path"] or job.source_path

        index.register("SOURCE", job.source_path)

        # Already fully completed via checkpoint
        if start_index >= len(self.stages):
            job.status            = JobStatus.COMPLETED
            job.final_output_path = current_artifact_path
            job.current_stage     = None
            job.progress          = 100
            job.updated_at        = datetime.now()
            logger_ev.log_event("job_resumed_already_complete", {"job_id": job.job_id})
            bus.done(job.job_id, current_artifact_path)
            return

        # Register already-completed stage artifacts
        for stage in self.stages[:start_index]:
            st = stage.stage_type
            existing_path = index.get(st.name)
            if existing_path:
                index.register(st.name, existing_path)
            logger_ev.log_event("stage_skipped_via_checkpoint", {"stage": st.name})

        # Total units — populated after ingestion artifact is available
        total_units: int = 0

        # ── EXECUTION LOOP ───────────────────────────────────────────────────
        for stage in self.stages[start_index:]:
            stage_type = stage.stage_type
            stage_name = stage_type.name
            stage_start, stage_end = STAGE_RANGES.get(stage_name, (0, 100))

            stage_result = StageResult(
                stage=stage_type,
                status=StageStatus.NOT_STARTED,
                input_artifact_path=current_artifact_path,
                started_at=None,
            )
            job.stage_results[stage_type] = stage_result

            if job.cancel_requested:
                job.status        = JobStatus.CANCELLED
                job.current_stage = None
                job.updated_at    = datetime.now()
                stage_result.status = StageStatus.CANCELLED
                logger_ev.log_event("stage_cancelled", {"stage": stage_name})
                bus.status(job.job_id, f"Pipeline cancelled at {stage_name}")
                break

            job.current_stage = stage_type
            job.updated_at    = datetime.now()

            # Emit stage-start progress (start of range)
            job.progress = stage_start
            bus.progress(job.job_id, stage_name, float(stage_start))

            validate_stage_transition(stage_result.status, StageStatus.RUNNING)
            stage_result.status     = StageStatus.RUNNING
            stage_result.started_at = datetime.now()

            # Build per-unit progress callback for unit-looping stages
            on_unit_done = _make_unit_progress_fn(
                job.job_id, stage_name, stage_start, stage_end, total_units
            )

            stage_input = StageInput(
                job_id=job.job_id,
                stage=stage_type,
                working_dir=job.working_dir,
                input_artifact_path=current_artifact_path,
                config=job.config,
                context={
                    "artifact_index": index.artifacts,
                    # Stages that loop over units call:
                    #   stage_input.context["on_unit_done"](units_done_so_far)
                    # This is optional — stages that don't use it work unchanged.
                    "on_unit_done": on_unit_done,
                    "total_units":  total_units,
                },
            )

            try:
                logger.info(f"stage_started: {stage_name} for job {job.job_id}")
                logger_ev.log_event("stage_started", {"stage": stage_name})

                # Run sync stage in thread — keeps event loop free
                output: StageOutput = await loop.run_in_executor(
                    self._executor, stage.execute, stage_input
                )

                if job.cancel_requested:
                    stage_result.status     = StageStatus.CANCELLED
                    stage_result.finished_at = datetime.now()
                    job.status              = JobStatus.CANCELLED
                    job.current_stage       = None
                    job.updated_at          = datetime.now()
                    bus.status(job.job_id, f"Pipeline cancelled during {stage_name}")
                    break

                validate_stage_output(output)
                stage_result.status              = output.status
                stage_result.finished_at         = datetime.now()
                stage_result.output_artifact_path = output.output_artifact_path
                stage_result.metrics             = output.metrics

                if output.status == StageStatus.FAILED:
                    job.status        = JobStatus.FAILED
                    job.error_message = output.error_message
                    bus.error(job.job_id, stage_name, output.error_message)
                    break

                elif output.status == StageStatus.COMPLETED:
                    current_artifact_path = output.output_artifact_path
                    index.register(stage_name, current_artifact_path)
                    save_checkpoint(job, stage_type, current_artifact_path)
                    logger_ev.log_event("stage_completed", {"stage": stage_name})
                    job.updated_at = datetime.now()

                    # Emit stage-end progress (end of range)
                    job.progress = stage_end
                    bus.progress(job.job_id, stage_name, float(stage_end))

                    # After ingestion — read total units for downstream progress math
                    if stage_name == "INGESTION":
                        total_units = _read_unit_count(current_artifact_path)
                        if total_units:
                            bus.log(job.job_id, "ORCHESTRATOR",
                                    f"Dynamic progress tracking: {total_units} units detected.")

            except Exception as e:
                stage_result.status       = StageStatus.FAILED
                stage_result.error_message = str(e)
                job.status                = JobStatus.FAILED
                job.error_message         = str(e)
                bus.error(job.job_id, stage_name, f"Crash: {str(e)}")
                break

        if job.status == JobStatus.RUNNING:
            job.status            = JobStatus.COMPLETED
            job.final_output_path = current_artifact_path
            job.progress          = 100
            bus.done(job.job_id, current_artifact_path)

        job.current_stage = None
        job.updated_at    = datetime.now()