from dataclasses import dataclass, field
from enum import Enum
from typing import Any, Dict, List, Optional
from datetime import datetime

class JobStatus(Enum):
    PENDING = "PENDING"
    RUNNING = "RUNNING"
    COMPLETED = "COMPLETED"
    FAILED = "FAILED"
    CANCELLED = "CANCELLED"

class StageStatus(Enum):
    NOT_STARTED = "NOT_STARTED"
    RUNNING = "RUNNING"
    COMPLETED = "COMPLETED"
    FAILED = "FAILED"
    SKIPPED = "SKIPPED"
    CANCELLED = "CANCELLED"

class StageType(Enum):
    INGESTION = "INGESTION"
    PREPROCESSING = "PREPROCESSING"
    BATCH_PLANNING = "BATCH_PLANNING"
    TRANSLATION = "TRANSLATION"
    POLISHING = "POLISHING"
    POSTPROCESSING = "POSTPROCESSING"
    PUBLISHING = "PUBLISHING"
    EXPORT = "EXPORT"

@dataclass
class JobConfig:
    parameters: Dict[str, Any] = field(default_factory=dict)

@dataclass
class StageInput:
    job_id: str
    stage: StageType
    working_dir: str
    input_artifact_path: str
    config: JobConfig
    context: Dict[str, Any] = field(default_factory=dict)

@dataclass
class StageOutput:
    stage: StageType
    status: StageStatus
    output_artifact_path: Optional[str] = None
    warnings: List[str] = field(default_factory=list)
    metrics: Dict[str, Any] = field(default_factory=dict)
    error_code: Optional[str] = None
    error_message: Optional[str] = None

@dataclass
class StageResult:
    stage: StageType
    status: StageStatus
    input_artifact_path: str
    output_artifact_path: Optional[str] = None
    started_at: Optional[datetime] = None
    finished_at: Optional[datetime] = None
    warnings: List[str] = field(default_factory=list)
    metrics: Dict[str, Any] = field(default_factory=dict)
    error_code: Optional[str] = None
    error_message: Optional[str] = None

@dataclass
class PipelineJob:
    job_id: str
    status: JobStatus
    source_path: str
    working_dir: str
    final_output_path: Optional[str] = None
    current_stage: Optional[StageType] = None
    created_at: datetime = field(default_factory=datetime.now)
    updated_at: datetime = field(default_factory=datetime.now)
    config: JobConfig = field(default_factory=JobConfig)
    stage_results: Dict[StageType, StageResult] = field(default_factory=dict)
    error_message: Optional[str] = None
    cancel_requested: bool = False
