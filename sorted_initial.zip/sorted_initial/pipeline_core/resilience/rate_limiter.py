"""
pipeline_core/resilience/rate_limiter.py
==========================================
Thread-safe sliding-window rate limiter.

Scitely Community safe defaults:
  - 2 RPS (safe burst ceiling)
  - 50 RPM (safe minute target, hard limit is 60)
"""
import threading
import time
from collections import deque


class RateLimiter:
    """
    Sliding-window rate limiter.  Thread-safe.  Sleeps OUTSIDE the lock
    to avoid blocking other threads while waiting for capacity.
    """

    def __init__(self, max_per_second: int = 2, max_per_minute: int = 50):
        self.max_per_second = max_per_second
        self.max_per_minute = max_per_minute
        self._lock          = threading.Lock()
        self._second_window: deque = deque()
        self._minute_window: deque = deque()

    def wait_for_capacity(self) -> None:
        """Block until a request slot is available, then consume it."""
        while True:
            sleep_time = self._try_acquire()
            if sleep_time == 0:
                return
            time.sleep(sleep_time)

    def _try_acquire(self) -> float:
        """
        Attempt to acquire a slot.
        Returns 0.0 if acquired, or the number of seconds to sleep before retrying.
        """
        with self._lock:
            now = time.time()

            # Evict expired entries
            while self._second_window and now - self._second_window[0] >= 1.0:
                self._second_window.popleft()
            while self._minute_window and now - self._minute_window[0] >= 60.0:
                self._minute_window.popleft()

            # Check per-second limit
            if len(self._second_window) >= self.max_per_second:
                sleep = max(0.01, 1.0 - (now - self._second_window[0]))
                return sleep

            # Check per-minute limit
            if len(self._minute_window) >= self.max_per_minute:
                sleep = max(0.01, 60.0 - (now - self._minute_window[0]))
                return sleep

            # Capacity available — consume it
            self._second_window.append(now)
            self._minute_window.append(now)
            return 0.0

    @property
    def current_rps(self) -> float:
        """Approximate current request rate (per second)."""
        with self._lock:
            now = time.time()
            count = sum(1 for t in self._second_window if now - t < 1.0)
            return float(count)

    @property
    def current_rpm(self) -> float:
        """Approximate current request rate (per minute)."""
        with self._lock:
            now = time.time()
            count = sum(1 for t in self._minute_window if now - t < 60.0)
            return float(count)


# Singleton used by throughput_controller — matches Scitely Community safe targets
GLOBAL_RATE_LIMITER = RateLimiter(max_per_second=2, max_per_minute=50)
