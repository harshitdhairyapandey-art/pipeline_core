"""
pipeline_core/resilience/throughput_controller.py
===================================================
Async-first throughput control wrapping rate limiting + retry.

  execute_with_throughput_control_async(coro_fn, limiter)
    — primary path used by orchestrator async stages

  execute_with_throughput_control(operation, limiter)
    — sync fallback, kept for any ThreadPoolExecutor paths still in use
"""
import asyncio
from typing import Callable, Any, Optional

from .rate_limiter import RateLimiter, API_RATE_LIMITER
from .retry_handler import with_retry
from .fallback_policy import ResilienceFailure


# ── Async path ───────────────────────────────────────────────────────────────

async def execute_with_throughput_control_async(
    coro_fn:  Callable,
    limiter:  Optional[RateLimiter] = None,
    max_attempts: int = 3,
) -> Any:
    """
    Async rate-limited execution with exponential backoff.

    Args:
        coro_fn:      Zero-arg async callable — e.g. lambda: provider.call_ai_async(...)
        limiter:      RateLimiter instance (defaults to API_RATE_LIMITER)
        max_attempts: Max retry attempts before raising ResilienceFailure

    Respects Retry-After header via exponential backoff:
      attempt 1 → 1s wait
      attempt 2 → 2s wait
      attempt 3 → 4s wait
    """
    if limiter is None:
        limiter = API_RATE_LIMITER

    base_delay = 1.0
    last_exc   = None

    for attempt in range(1, max_attempts + 1):
        await limiter.wait_for_capacity_async()
        try:
            return await coro_fn()
        except ResilienceFailure:
            raise
        except Exception as exc:
            last_exc = exc
            if attempt == max_attempts:
                break
            delay = base_delay * (2 ** (attempt - 1))
            await asyncio.sleep(delay)

    raise ResilienceFailure(
        f"Exhausted {max_attempts} attempts. Last error: {last_exc}"
    ) from last_exc


# ── Sync path (backward compat) ──────────────────────────────────────────────

def execute_with_throughput_control(
    operation: Callable[[], Any],
    limiter:   Optional[RateLimiter] = None,
) -> Any:
    """
    Sync rate-limited execution. Used by any ThreadPoolExecutor paths.
    Wraps original retry_handler.with_retry unchanged.
    """
    if limiter is None:
        limiter = API_RATE_LIMITER

    def controlled():
        limiter.wait_for_capacity()
        return operation()

    return with_retry(controlled)