class ResilienceFailure(Exception):
    """
    Structured Exception thrown when the translation engine exceeds its retry thresholds 
    or faces deterministically fatal authorization errors natively.
    """
    def __init__(self, message: str, category: str, attempts: int):
        super().__init__(message)
        self.category = category
        self.attempts = attempts

def execute_fallback(original_exception: Exception, category: str, attempts: int) -> None:
    """
    Strict fallback halting pipeline execution transparently rather than
    allowing silent logic truncation or AI hallucination failures natively.
    """
    raise ResilienceFailure(
        message=f"Operation failed permanently after {attempts} attempts. Final error: {str(original_exception)}",
        category=category,
        attempts=attempts
    ) from original_exception
