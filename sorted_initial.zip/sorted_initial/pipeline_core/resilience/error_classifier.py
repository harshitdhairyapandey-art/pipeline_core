def classify_error(exception: Exception) -> str:
    """
    Classifies generic and provider-specific exceptions into bounded resilience categories safely.
    """
    error_name = type(exception).__name__.lower()
    error_msg = str(exception).lower()
    
    if "timeout" in error_name or "timeout" in error_msg:
        return "timeout"
    if "ratelimit" in error_name or "429" in error_msg or "rate limit" in error_msg:
        return "rate_limit"
    if "auth" in error_name or "401" in error_msg or "403" in error_msg:
        return "auth"
    if "server" in error_name or "500" in error_msg or "502" in error_msg or "503" in error_msg:
        return "server_error"
    if "invalid" in error_name or "format" in error_name or "decode" in error_name:
        return "invalid_response"
        
    return "unknown"

def is_transient(error_category: str) -> bool:
    """
    Determines if a categorized error is likely to succeed upon immediate exponential retry.
    """
    return error_category in ["timeout", "rate_limit", "server_error"]
