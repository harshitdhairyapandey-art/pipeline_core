import time
from typing import Callable, Any

from .error_classifier import classify_error, is_transient
from .fallback_policy import execute_fallback

def with_retry(operation: Callable[[], Any], max_attempts: int = 3) -> Any:
    """
    Executes an operation with structured exponential backoff for transient errors.
    Passes directly to failure handler on auth or formatting logic failures natively.
    """
    attempt = 1
    base_delay = 1.0  # seconds
    
    while attempt <= max_attempts:
        try:
            return operation()
        except Exception as e:
            category = classify_error(e)
            
            if attempt == max_attempts or not is_transient(category):
                # Escalates to explicit fallback if retries bound exhausted or non-transient
                return execute_fallback(e, category, attempt)
                
            # Compute exponential backoff deterministically (1s, 2s, 4s...)
            delay = base_delay * (2 ** (attempt - 1))
            time.sleep(delay)
            attempt += 1

    raise RuntimeError("Retry cycle bypassed structured execution path.")
