import json
import os
from typing import List, Dict, Any

from .base import BaseStage
from ..core.models import StageInput, StageOutput, StageType, StageStatus

class ExportStage(BaseStage):
    @property
    def stage_type(self) -> StageType:
        return StageType.EXPORT

    def execute(self, stage_input: StageInput) -> StageOutput:
        try:
            input_path = stage_input.input_artifact_path
            
            if not input_path or not os.path.exists(input_path):
                return StageOutput(
                    stage=self.stage_type,
                    status=StageStatus.FAILED,
                    error_message=f"Input artifact not found: {input_path}",
                    error_code="ARTIFACT_NOT_FOUND"
                )
                
            # Read compiled post-processed schema payload safely
            with open(input_path, 'r', encoding='utf-8') as f:
                final_data = json.load(f)
                
            final_units = final_data.get("units", [])
            
            if not final_units:
                return StageOutput(
                    stage=self.stage_type,
                    status=StageStatus.FAILED,
                    error_message="Final data contains no units to export.",
                    error_code="EMPTY_INPUT_UNITS"
                )
                
            blocks = []
            
            # Sequentially loop JSON units into plain-text blocks
            for unit in final_units:
                text = unit.get("final_text", "").strip()
                if text:
                    blocks.append(text)
                    
            export_string = "\n\n".join(blocks)
            
            # Generate the final runtime plain-text file
            output_filepath = self.get_output_path(stage_input, "exported_output.txt")
            
            with open(output_filepath, 'w', encoding='utf-8') as f:
                f.write(export_string)
                
            return StageOutput(
                stage=self.stage_type,
                status=StageStatus.COMPLETED,
                output_artifact_path=output_filepath,
                metrics={
                    "total_units": len(blocks)
                }
            )
            
        except json.JSONDecodeError as e:
            return StageOutput(
                stage=self.stage_type,
                status=StageStatus.FAILED,
                error_message=f"Corrupt json read detected: {str(e)}",
                error_code="INVALID_JSON"
            )
        except Exception as e:
            return StageOutput(
                stage=self.stage_type,
                status=StageStatus.FAILED,
                error_message=f"Export execution failed: {str(e)}",
                error_code=e.__class__.__name__
            )
