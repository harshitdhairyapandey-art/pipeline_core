import json
import os
from typing import List, Dict, Any

from .base import BaseStage
from ..core.models import StageInput, StageOutput, StageType, StageStatus
from ..providers.scitely_provider import ScitelyProvider
from ..translation.prompt_builder import build_translation_prompt

class TranslationStage(BaseStage):
    @property
    def stage_type(self) -> StageType:
        return StageType.TRANSLATION

    def execute(self, stage_input: StageInput) -> StageOutput:
        try:
            # 1. Resolve Artifact Paths
            manifest_path = stage_input.input_artifact_path
            
            if not manifest_path or not os.path.exists(manifest_path):
                return StageOutput(
                    stage=self.stage_type,
                    status=StageStatus.FAILED,
                    error_message=f"Batch manifest not found: {manifest_path}",
                    error_code="ARTIFACT_NOT_FOUND"
                )
                
            # Context schema is robustly acquired from the dynamically propagated artifact index
            artifact_index = stage_input.context.get("artifact_index", {})
            context_path = artifact_index.get("PREPROCESSING")
            
            if not context_path or not os.path.exists(context_path):
                return StageOutput(
                    stage=self.stage_type,
                    status=StageStatus.FAILED,
                    error_message=f"Preprocessed context dependency not found in execution index natively.",
                    error_code="DEPENDENCY_NOT_FOUND"
                )
                
            # Initialize provider (fails early if no API key is provided)
            provider = ScitelyProvider()
                
            # 2. Parse Memory Structures
            with open(manifest_path, 'r', encoding='utf-8') as f:
                manifest_data = json.load(f)
                
            with open(context_path, 'r', encoding='utf-8') as f:
                context_data = json.load(f)
                
            batches = manifest_data.get("batches", [])
            units_context = context_data.get("units", [])
            
            global_context = context_data.get("global_context", {})
            
            # Lookup mapping for efficient textual resolution without duplicate scans
            unit_lookup = {u.get("unit_id"): u for u in units_context if u.get("unit_id")}
            
            # 3. Process Execution Loop (Strict Linear Sequence) using formal Executor
            from ..runtime.translation_executor import execute_translation_batches
            
            success, result_payload = execute_translation_batches(
                batches=batches,
                unit_lookup=unit_lookup,
                global_context=global_context,
                provider_callable=provider.translate_text,
                prompt_builder=build_translation_prompt
            )
            
            if not success:
               return StageOutput(
                    stage=self.stage_type,
                    status=StageStatus.FAILED,
                    error_message=result_payload.get("message", "Unknown Translation Layer Error"),
                    error_code=result_payload.get("code", "TRANSLATION_FAILURE")
               )
            
            translated_units = result_payload
            
            # 4. Formulate Stage Payload Output
            translated_payload = {
                "job_id": stage_input.job_id,
                "units": translated_units
            }
            
            output_filepath = self.get_output_path(stage_input, "translated_output.json")
            
            with open(output_filepath, 'w', encoding='utf-8') as f:
                json.dump(translated_payload, f, ensure_ascii=False, indent=2)
                
            # 5. Commit Stable Output Node
            return StageOutput(
                stage=self.stage_type,
                status=StageStatus.COMPLETED,
                output_artifact_path=output_filepath,
                metrics={
                    "total_units": len(translated_units),
                    "total_batches": len(batches)
                }
            )
            
        except json.JSONDecodeError as e:
            return StageOutput(
                stage=self.stage_type,
                status=StageStatus.FAILED,
                error_message=f"Corrupt json read detected: {str(e)}",
                error_code="INVALID_JSON"
            )
        except ValueError as e:
            return StageOutput(
                stage=self.stage_type,
                status=StageStatus.FAILED,
                error_message=f"Configuration error: {str(e)}",
                error_code="CONFIG_ERROR"
            )
        except Exception as e:
            return StageOutput(
                stage=self.stage_type,
                status=StageStatus.FAILED,
                error_message=f"Translation execution loop failed: {str(e)}",
                error_code=e.__class__.__name__
            )
