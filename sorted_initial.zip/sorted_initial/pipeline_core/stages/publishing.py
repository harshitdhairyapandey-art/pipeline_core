"""
pipeline_core/stages/publishing.py
=====================================
PUBLISHING stage — deterministic formatting only.

Responsibilities:
  - Paragraph spacing and dialogue formatting
  - Punctuation standardisation
  - Whitespace cleanup
  - Corruption/encoding repair (proofreading)

This stage does NOT:
  - Rewrite content
  - Fix grammar
  - Change word choices
  - Call AI for any creative purpose

The AI call here is tightly constrained (temperature=0.1) and
uses the PUBLISHING_SYSTEM prompt which forbids creative changes.
If the AI call fails for any unit, the original text is kept — the stage
does NOT fail.
"""
import json
import logging
import os
import concurrent.futures
from typing import List, Dict, Any

from .base import BaseStage
from ..core.models import StageInput, StageOutput, StageType, StageStatus

logger = logging.getLogger(__name__)


class PublishingStage(BaseStage):
    @property
    def stage_type(self) -> StageType:
        return StageType.PUBLISHING

    def execute(self, stage_input: StageInput) -> StageOutput:
        try:
            input_path = stage_input.input_artifact_path

            if not input_path or not os.path.exists(input_path):
                return StageOutput(
                    stage=self.stage_type,
                    status=StageStatus.FAILED,
                    error_message="POSTPROCESSING artifact not found.",
                    error_code="DEPENDENCY_NOT_FOUND",
                )

            # Load publishing prompt
            try:
                from ..prompts import PUBLISHING_SYSTEM, PUBLISHING_USER_TEMPLATE
            except ImportError:
                PUBLISHING_SYSTEM = (
                    "You are a Hindi book formatter preparing text for publication. "
                    "Your ONLY jobs: paragraph spacing, punctuation standardisation, "
                    "whitespace cleanup, and fixing visibly corrupted Devanagari characters. "
                    "ZERO content rewriting. Return the formatted Hindi text ONLY."
                )
                PUBLISHING_USER_TEMPLATE = "Format for publication:\n\n{hindi_text}"

            # Initialize provider — tolerate missing API key
            provider = None
            try:
                from ..providers.scitely_provider import ScitelyProvider
                provider = ScitelyProvider()
            except ValueError:
                logger.info(
                    "SCITELY_API_KEY not set — publishing will use deterministic formatting only."
                )
            except Exception as e:
                logger.warning(f"Provider init failed in publishing: {e} — using deterministic path.")

            with open(input_path, "r", encoding="utf-8") as f:
                postprocessed_data = json.load(f)

            units = postprocessed_data.get("units", [])
            published_units: List[Dict[str, Any]] = []
            ai_formatted = 0
            deterministic_formatted = 0

            def _process_publishing_unit(idx: int, unit: Dict[str, Any]) -> tuple:
                unit_id = unit.get("unit_id")
                final_text = unit.get("final_text", "")
                formatted_text = final_text
                ai_fmt, det_fmt = 0, 0

                if provider and final_text and final_text.strip():
                    user_msg = PUBLISHING_USER_TEMPLATE.format(hindi_text=final_text)
                    try:
                        result = provider.call_ai(
                            PUBLISHING_SYSTEM,
                            user_msg,
                            temperature=0.1,
                            sampling_params={"max_tokens": 16000},
                        )
                        if result and result.strip() and len(result) >= len(final_text) * 0.70:
                            formatted_text = result
                            ai_fmt = 1
                        else:
                            logger.warning(f"Publishing: AI output rejected or empty for unit {unit_id} — keeping original.")
                            det_fmt = 1
                    except Exception as e:
                        logger.warning(f"Publishing AI call failed for unit {unit_id}: {e} — keeping original.")
                        det_fmt = 1
                else:
                    det_fmt = 1

                processed_unit = {
                    "unit_id": unit_id,
                    "final_text": formatted_text,
                    "metadata": unit.get("metadata", {}),
                }
                return idx, processed_unit, ai_fmt, det_fmt

            # Execute publishing calls in parallel to vastly increase speed
            results = []
            with concurrent.futures.ThreadPoolExecutor(max_workers=8) as executor:
                futures = [executor.submit(_process_publishing_unit, i, u) for i, u in enumerate(units)]
                for future in concurrent.futures.as_completed(futures):
                    results.append(future.result())

            # Re-sort to maintain exact document order
            results.sort(key=lambda x: x[0])
            for _, p_unit, a_fmt, d_fmt in results:
                published_units.append(p_unit)
                ai_formatted += a_fmt
                deterministic_formatted += d_fmt

            output_payload = {
                "job_id": stage_input.job_id,
                "units":  published_units,
            }

            output_filepath = self.get_output_path(stage_input, "publishing_ready.json")
            with open(output_filepath, "w", encoding="utf-8") as f:
                json.dump(output_payload, f, ensure_ascii=False, indent=2)

            return StageOutput(
                stage=self.stage_type,
                status=StageStatus.COMPLETED,
                output_artifact_path=output_filepath,
                metrics={
                    "total_units":            len(published_units),
                    "ai_formatted":           ai_formatted,
                    "deterministic_formatted": deterministic_formatted,
                },
            )

        except json.JSONDecodeError as e:
            return StageOutput(
                stage=self.stage_type,
                status=StageStatus.FAILED,
                error_message=f"Corrupt input artifact: {e}",
                error_code="INVALID_JSON",
            )
        except Exception as e:
            logger.exception("PublishingStage crashed")
            return StageOutput(
                stage=self.stage_type,
                status=StageStatus.FAILED,
                error_message=f"Publishing stage failed: {e}",
                error_code=e.__class__.__name__,
            )
