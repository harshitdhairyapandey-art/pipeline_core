import json
import os
from typing import List, Dict, Any

from .base import BaseStage
from ..core.models import StageInput, StageOutput, StageType, StageStatus
from ..postprocessing.postprocessing_assembler import assemble_postprocessing
from ..providers.scitely_provider import ScitelyProvider
from ..postprocessing.ai_critics import ActorCriticEngine

class PostprocessingStage(BaseStage):
    @property
    def stage_type(self) -> StageType:
        return StageType.POSTPROCESSING

    def execute(self, stage_input: StageInput) -> StageOutput:
        try:
            input_path = stage_input.input_artifact_path
            
            if not input_path or not os.path.exists(input_path):
                return StageOutput(
                    stage=self.stage_type,
                    status=StageStatus.FAILED,
                    error_message=f"Input artifact not found: {input_path}",
                    error_code="ARTIFACT_NOT_FOUND"
                )
                
            artifact_index = stage_input.context.get("artifact_index", {})
            context_path = artifact_index.get("PREPROCESSING")
            
            if not context_path or not os.path.exists(context_path):
                return StageOutput(
                    stage=self.stage_type,
                    status=StageStatus.FAILED,
                    error_message=f"Preprocessed context dependency missing sequentially natively.",
                    error_code="DEPENDENCY_NOT_FOUND"
                )
                
            # Read translated output safely
            with open(input_path, 'r', encoding='utf-8') as f:
                translated_data = json.load(f)
                
            with open(context_path, 'r', encoding='utf-8') as f:
                context_data = json.load(f)
                
            # Initialize AI Actor-Critic logic natively
            provider = ScitelyProvider()
            critics_engine = ActorCriticEngine(provider)

            translated_units = translated_data.get("units", [])
            
            if not translated_units:
                return StageOutput(
                    stage=self.stage_type,
                    status=StageStatus.FAILED,
                    error_message="Translated data contains no units to post-process.",
                    error_code="EMPTY_INPUT_UNITS"
                )
                
            preprocessed_lookup = {u.get("unit_id"): u for u in context_data.get("units", [])}
            
            # Unpack real global contexts directly from prior artifact chains
            global_context = context_data.get("global_context", {})
            global_glossary_map = global_context.get("glossary_map", {})
            
            final_units: List[Dict[str, Any]] = []
            total_warnings = 0

            # Assembler Execution Loop running Native Postprocessing Tasks
            for unit in translated_units:
                unit_id = unit.get("unit_id")
                preprocessed_unit = preprocessed_lookup.get(unit_id, {})

                final_unit = assemble_postprocessing(
                    unit, 
                    preprocessed_unit, 
                    global_glossary_map, 
                    critics_engine=critics_engine,
                    global_context=global_context
                )
                total_warnings += len(final_unit.get("warnings", []))
                final_units.append(final_unit)
                
            # after existing loop — merge split parts back by base_id
            merged = {}
            remainder = []

            for unit in final_units:
                meta = unit.get("metadata", {})
                base_id    = meta.get("base_id")
                part_total = meta.get("part_total", 1)
                part_idx   = meta.get("part_idx", 0)

                if part_total > 1 and base_id:
                    if base_id not in merged:
                        merged[base_id] = {"unit": dict(unit), "parts": {}}
                    
                    # Capture whichever text key is present
                    text_content = unit.get("final_text", unit.get("translated_text", ""))
                    merged[base_id]["parts"][part_idx] = text_content
                else:
                    remainder.append(unit)

            # stitch parts in order
            for base_id, data in merged.items():
                ordered = [data["parts"][i] for i in sorted(data["parts"])]
                data["unit"]["final_text"] = "\n\n".join(ordered)
                data["unit"]["translated_text"] = "\n\n".join(ordered)
                data["unit"]["unit_id"] = base_id  # restore clean base_id
                remainder.append(data["unit"])

            # re-sort by display_order
            final_units = sorted(remainder, key=lambda u: u.get("display_order", 0))

            final_payload = {
                "job_id": stage_input.job_id,
                "units": final_units,
                "warnings_summary": {
                    "total_warnings": total_warnings,
                    "units_with_warnings": sum(
                        1 for u in final_units if u.get("warnings")
                    )
                }
            }
            
            output_filepath = self.get_output_path(stage_input, "final_output.json")
            
            with open(output_filepath, 'w', encoding='utf-8') as f:
                json.dump(final_payload, f, ensure_ascii=False, indent=2)
                
            return StageOutput(
                stage=self.stage_type,
                status=StageStatus.COMPLETED,
                output_artifact_path=output_filepath,
                metrics={
                    "total_units": len(final_units),
                    "total_warnings": total_warnings
                }
            )
            
        except json.JSONDecodeError as e:
            return StageOutput(
                stage=self.stage_type,
                status=StageStatus.FAILED,
                error_message=f"Corrupt json read detected: {str(e)}",
                error_code="INVALID_JSON"
            )
        except Exception as e:
            return StageOutput(
                stage=self.stage_type,
                status=StageStatus.FAILED,
                error_message=f"Postprocessing execution failed: {str(e)}",
                error_code=e.__class__.__name__
            )
