from __future__ import annotations

import json
import os
import re
import hashlib
import unicodedata
from dataclasses import dataclass, asdict, field
from html import unescape
from typing import Any, Dict, Iterable, List, Optional, Tuple

# Optional deps
try:
    import fitz  # PyMuPDF
    PYMUPDF_AVAILABLE = True
except Exception:
    PYMUPDF_AVAILABLE = False

try:
    import pypdf
    PYPDF_AVAILABLE = True
except Exception:
    PYPDF_AVAILABLE = False

try:
    from docx import Document as DocxDocument
    DOCX_AVAILABLE = True
except Exception:
    DOCX_AVAILABLE = False

try:
    from bs4 import BeautifulSoup
    BS4_AVAILABLE = True
except Exception:
    BS4_AVAILABLE = False

# These imports assume your existing project layout.
from .base import BaseStage
from ..core.models import StageInput, StageOutput, StageType, StageStatus


SKIP_PATTERNS = [
    'table of contents', 'pathways guide', 'image gallery',
    'characters', 'back cover', 'front cover', 'full cover',
    'map of', 'to be continued', 'copyright', 'synopsis',
    'volume', 'translator', 'editor', 'acknowledgement',
    'illustrations', 'illustration', "author's note", 'character design',
    'color pages', 'color illustrations', 'inserts', 'appendix'
]

SCENE_BREAK_PATTERNS = [
    re.compile(r'^\*\s*\*\s*\*+$'),
    re.compile(r'^\-\s*\-\s*\-+$'),
    re.compile(r'^•\s*•\s*•+$'),
    re.compile(r'^—+$'),
    re.compile(r'^~+$'),
]

ROMAN_NUMERAL = r'(?:M{0,4}(CM|CD|D?C{0,3})(XC|XL|L?X{0,3})(IX|IV|V?I{0,3}))'
CHAPTER_PATTERNS = [
    re.compile(rf'^(?:chapter|chap|ch\.)\s+(\d+|{ROMAN_NUMERAL}|one|two|three|four|five|six|seven|eight|nine|ten|eleven|twelve)\b\s*[:\-\u2013]?\s*(.*)$', re.IGNORECASE),
    re.compile(r'^(prologue|epilogue|interlude|afterword|foreword|preface|postscript)\b\s*[:\-\u2013]?\s*(.*)$', re.IGNORECASE),
    re.compile(r'^(?:part|book|arc|episode|section|volume)\s+(\d+|[ivxlcdm]+|one|two|three|four|five|six|seven|eight|nine|ten)\b\s*[:\-\u2013]?\s*(.*)$', re.IGNORECASE),
]

HEADER_FOOTER_MIN_REPEAT = 3
MAX_HEADER_FOOTER_LEN = 80
DEFAULT_MODEL = "generic"


@dataclass
class ModelProfile:
    name: str
    context_window: int
    reserved_output_tokens: int = 1800
    prompt_wrapper_tokens: int = 350
    target_input_ratio: float = 0.72
    hard_margin_tokens: int = 300
    chars_per_token_fallback: float = 3.6


MODEL_PROFILES: Dict[str, ModelProfile] = {
    "generic": ModelProfile(name="generic", context_window=8192, reserved_output_tokens=1400, prompt_wrapper_tokens=350, target_input_ratio=0.70, hard_margin_tokens=300),
    "gpt-4.1": ModelProfile(name="gpt-4.1", context_window=128000, reserved_output_tokens=3500, prompt_wrapper_tokens=450, target_input_ratio=0.78, hard_margin_tokens=600),
    "gpt-4o": ModelProfile(name="gpt-4o", context_window=128000, reserved_output_tokens=3500, prompt_wrapper_tokens=450, target_input_ratio=0.78, hard_margin_tokens=600),
    "claude": ModelProfile(name="claude", context_window=200000, reserved_output_tokens=4000, prompt_wrapper_tokens=600, target_input_ratio=0.78, hard_margin_tokens=700),
    "claude-sonnet": ModelProfile(name="claude-sonnet", context_window=200000, reserved_output_tokens=4000, prompt_wrapper_tokens=600, target_input_ratio=0.78, hard_margin_tokens=700),
    "qwen-max": ModelProfile(name="qwen-max", context_window=32768, reserved_output_tokens=2500, prompt_wrapper_tokens=450, target_input_ratio=0.72, hard_margin_tokens=500),
    "deepseek": ModelProfile(name="deepseek", context_window=65536, reserved_output_tokens=2500, prompt_wrapper_tokens=450, target_input_ratio=0.75, hard_margin_tokens=500),
}


@dataclass
class ExtractionBlock:
    block_id: str
    text: str
    source_page: int = 1
    source_order: int = 0
    block_type: str = "paragraph"  # paragraph|heading|header|footer|scene_break|unknown
    style: Dict[str, Any] = field(default_factory=dict)
    position: Dict[str, Any] = field(default_factory=dict)
    warnings: List[str] = field(default_factory=list)


@dataclass
class DocumentUnit:
    unit_id: str
    title: str
    kind: str
    text: str
    display_order: int
    metadata: Dict[str, Any]
    warnings: List[str] = field(default_factory=list)
    confidence: float = 1.0


class TokenEstimator:
    """Cheap token estimator with optional model-specific calibration.

    For production, replace/augment this with a real tokenizer per provider.
    """

    def estimate(self, text: str, model_name: str = DEFAULT_MODEL) -> int:
        profile = MODEL_PROFILES.get(model_name, MODEL_PROFILES[DEFAULT_MODEL])
        if not text:
            return 0

        # Mixed heuristic: whitespace/token-ish units + punctuation density + chars fallback.
        words = re.findall(r"\S+", text)
        punct = re.findall(r"[.,!?;:()\[\]{}'\"“”‘’—–-]", text)
        newline_bonus = text.count("\n") * 0.15
        approx_by_words = len(words) + int(len(punct) * 0.35 + newline_bonus)
        approx_by_chars = int(len(text) / profile.chars_per_token_fallback)
        return max(1, int((approx_by_words * 0.45) + (approx_by_chars * 0.55)))


class BudgetPlanner:
    def __init__(self, estimator: TokenEstimator):
        self.estimator = estimator

    def get_profile(self, model_name: Optional[str]) -> ModelProfile:
        if not model_name:
            return MODEL_PROFILES[DEFAULT_MODEL]
        return MODEL_PROFILES.get(model_name, MODEL_PROFILES[DEFAULT_MODEL])

    def compute_safe_input_budget(
        self,
        model_name: Optional[str],
        dynamic_overhead_tokens: int = 0,
    ) -> Dict[str, int]:
        profile = self.get_profile(model_name)
        target_cap = int(profile.context_window * profile.target_input_ratio)
        safe_budget = min(
            target_cap,
            profile.context_window
            - profile.reserved_output_tokens
            - profile.prompt_wrapper_tokens
            - dynamic_overhead_tokens
            - profile.hard_margin_tokens,
        )
        hard_budget = max(512, safe_budget)
        target_chunk_budget = max(320, int(hard_budget * 0.82))
        return {
            "context_window": profile.context_window,
            "safe_input_budget": hard_budget,
            "target_chunk_budget": target_chunk_budget,
            "reserved_output_tokens": profile.reserved_output_tokens,
            "prompt_wrapper_tokens": profile.prompt_wrapper_tokens,
            "dynamic_overhead_tokens": dynamic_overhead_tokens,
            "hard_margin_tokens": profile.hard_margin_tokens,
        }


class TextNormalizer:
    def normalize_text(self, raw: str) -> Tuple[str, List[str], Dict[str, int]]:
        warnings: List[str] = []
        stats = {
            "chars_in": len(raw or ""),
            "chars_out": 0,
            "control_removed": 0,
            "lines_collapsed": 0,
            "hyphen_repairs": 0,
        }

        if not raw:
            return "", warnings, stats

        s = raw.encode("utf-8", errors="ignore").decode("utf-8", errors="ignore")
        s = unicodedata.normalize("NFC", s)
        before = len(s)
        s = ''.join(ch for ch in s if (ch == '\n' or ch == '\t' or unicodedata.category(ch)[0] != 'C'))
        stats["control_removed"] = before - len(s)

        s = re.sub(r'\r\n?', '\n', s)
        s = re.sub(r'[ \t]+', ' ', s)
        s = re.sub(r'\u00a0', ' ', s)
        s = re.sub(r'[ \t]*\n[ \t]*', '\n', s)

        # De-hyphenate simple line-break hyphen cases: "some-\nthing" -> "something"
        s, n_rep = re.subn(r'(?<=\w)-\n(?=\w)', '', s)
        stats["hyphen_repairs"] = n_rep

        # Collapse excessive blank lines but preserve paragraph gaps.
        before_lines = s.count("\n")
        s = re.sub(r'\n{3,}', '\n\n', s)
        stats["lines_collapsed"] = max(0, before_lines - s.count("\n"))

        # Normalize quotes/dashes lightly; do not flatten literary markers.
        s = s.replace('“', '"').replace('”', '"').replace('‘', "'").replace('’', "'")
        s = s.replace('–', '—')

        if re.search(r'[�]', s):
            warnings.append('replacement_char_present')
        if len(re.findall(r'\b[a-zA-Z]{1}\b', s)) > 50:
            warnings.append('possible_ocr_fragmentation')

        s = s.strip()
        stats["chars_out"] = len(s)
        return s, warnings, stats


class StructureDetector:
    def __init__(self) -> None:
        self.chapter_patterns = CHAPTER_PATTERNS

    def is_front_matter(self, text: str) -> bool:
        low = text.strip().lower()
        return any(p in low for p in SKIP_PATTERNS)

    def is_scene_break(self, text: str) -> bool:
        stripped = text.strip()
        return any(p.match(stripped) for p in SCENE_BREAK_PATTERNS)

    def heading_score(self, block: ExtractionBlock) -> Tuple[float, str, Optional[str], Optional[str]]:
        text = block.text.strip()
        if not text:
            return 0.0, "none", None, None

        score = 0.0
        kind = "none"
        title = None
        chapter_key = None

        # Hard scene break early.
        if self.is_scene_break(text):
            return 0.95, "scene_break", None, None

        for pattern in self.chapter_patterns:
            match = pattern.match(text)
            if match:
                score += 0.78
                kind = "chapter_heading"
                chapter_key = match.group(1).strip() if match.groups() else text
                title = text
                break

        font_size = float(block.style.get("font_size", 0) or 0)
        is_bold = bool(block.style.get("bold", False))
        align = str(block.style.get("alignment", "")).lower()
        is_isolated = block.style.get("is_isolated", False)
        near_top = block.position.get("near_top", False)

        if font_size >= 14:
            score += 0.12
        if is_bold:
            score += 0.05
        if align == "center":
            score += 0.05
        if is_isolated:
            score += 0.04
        if near_top:
            score += 0.03

        if len(text) <= 80 and text == text.upper() and re.search(r'[A-Z]', text):
            score += 0.07
        if len(text.split()) <= 8:
            score += 0.04
        if text.endswith((':', '-', '—')):
            score -= 0.08

        if score >= 0.62 and kind == "none":
            kind = "possible_heading"
            title = text

        return min(score, 0.99), kind, title, chapter_key


class SmartSegmenter:
    def __init__(self, estimator: TokenEstimator, planner: BudgetPlanner):
        self.estimator = estimator
        self.planner = planner

    def segment_units(
        self,
        structural_units: List[Dict[str, Any]],
        source_filename: str,
        model_name: Optional[str],
        dynamic_overhead_tokens: int,
    ) -> Tuple[List[DocumentUnit], Dict[str, Any]]:
        budgets = self.planner.compute_safe_input_budget(model_name, dynamic_overhead_tokens)
        target_budget = budgets["target_chunk_budget"]
        hard_budget = budgets["safe_input_budget"]

        out: List[DocumentUnit] = []
        total_tokens = 0
        oversize_splits = 0
        order = 1

        for structural_index, unit in enumerate(structural_units, 1):
            title = unit["title"]
            kind = unit["kind"]
            text = unit["text"].strip()
            source_pages = unit.get("source_pages", [])
            warnings = list(unit.get("warnings", []))
            confidence = float(unit.get("confidence", 0.9))

            parts = self._split_text_safely(text, target_budget, hard_budget, model_name)
            if len(parts) > 1:
                oversize_splits += 1

            base_fingerprint = self._fingerprint(f"{source_filename}|{structural_index}|{title}|{kind}")
            for idx, part_text in enumerate(parts, 1):
                est_tokens = self.estimator.estimate(part_text, model_name or DEFAULT_MODEL)
                total_tokens += est_tokens
                unit_id = f"{base_fingerprint}_part{idx}" if len(parts) > 1 else base_fingerprint
                part_title = f"{title} (part {idx})" if len(parts) > 1 else title
                part_warnings = list(warnings)
                if len(parts) > 1:
                    part_warnings.append("oversize_unit_split")
                if est_tokens > hard_budget:
                    part_warnings.append("token_budget_overrun")
                    confidence = max(0.35, confidence - 0.25)

                out.append(DocumentUnit(
                    unit_id=unit_id,
                    title=part_title,
                    kind=kind,
                    text=part_text,
                    display_order=order,
                    metadata={
                        "parent_title": title,
                        "part_idx": idx - 1,
                        "part_total": len(parts),
                        "estimated_tokens": est_tokens,
                        "model_name": model_name or DEFAULT_MODEL,
                        "source_pages": source_pages,
                        "source_structural_index": structural_index,
                        "split_reason": "semantic_packing" if len(parts) > 1 else "natural_boundary_fit",
                        "base_id": base_fingerprint,
                    },
                    warnings=part_warnings,
                    confidence=round(confidence, 3),
                ))
                order += 1

        stats = {
            "unit_count": len(out),
            "estimated_total_tokens": total_tokens,
            "oversize_units_split": oversize_splits,
            "budget": budgets,
        }
        return out, stats

    def _split_text_safely(self, text: str, target_budget: int, hard_budget: int, model_name: Optional[str]) -> List[str]:
        if self.estimator.estimate(text, model_name or DEFAULT_MODEL) <= hard_budget:
            return [text.strip()]

        paragraphs = [p.strip() for p in text.split("\n\n") if p.strip()]
        if not paragraphs:
            return [text.strip()]

        parts: List[str] = []
        cur: List[str] = []
        cur_tokens = 0

        for para in paragraphs:
            para_tokens = self.estimator.estimate(para, model_name or DEFAULT_MODEL)

            if para_tokens > hard_budget:
                if cur:
                    parts.append("\n\n".join(cur).strip())
                    cur, cur_tokens = [], 0
                parts.extend(self._split_long_paragraph(para, target_budget, hard_budget, model_name))
                continue

            if cur and cur_tokens + para_tokens > target_budget:
                parts.append("\n\n".join(cur).strip())
                cur, cur_tokens = [para], para_tokens
            else:
                cur.append(para)
                cur_tokens += para_tokens

        if cur:
            parts.append("\n\n".join(cur).strip())

        return [p for p in parts if p.strip()]

    def _split_long_paragraph(self, para: str, target_budget: int, hard_budget: int, model_name: Optional[str]) -> List[str]:
        sentences = self._split_sentences(para)
        if len(sentences) <= 1:
            return self._hard_split_by_words(para, target_budget, model_name)

        out: List[str] = []
        cur: List[str] = []
        cur_tokens = 0

        for sent in sentences:
            sent_tokens = self.estimator.estimate(sent, model_name or DEFAULT_MODEL)
            if sent_tokens > hard_budget:
                if cur:
                    out.append(" ".join(cur).strip())
                    cur, cur_tokens = [], 0
                out.extend(self._hard_split_by_words(sent, target_budget, model_name))
                continue
            if cur and cur_tokens + sent_tokens > target_budget:
                out.append(" ".join(cur).strip())
                cur, cur_tokens = [sent], sent_tokens
            else:
                cur.append(sent)
                cur_tokens += sent_tokens

        if cur:
            out.append(" ".join(cur).strip())
        return out

    def _split_sentences(self, text: str) -> List[str]:
        pieces = re.split(r'(?<=[.!?。！？])\s+(?=["\'A-Z0-9])', text)
        pieces = [p.strip() for p in pieces if p.strip()]
        if len(pieces) == 1 and len(text) > 1200:
            # fallback for prose without standard sentence punctuation
            pieces = re.split(r'(?<=,|;|—)\s+', text)
            pieces = [p.strip() for p in pieces if p.strip()]
        return pieces or [text]

    def _hard_split_by_words(self, text: str, target_budget: int, model_name: Optional[str]) -> List[str]:
        words = text.split()
        out: List[str] = []
        cur: List[str] = []

        for word in words:
            test = (" ".join(cur + [word])).strip()
            if cur and self.estimator.estimate(test, model_name or DEFAULT_MODEL) > target_budget:
                out.append(" ".join(cur).strip())
                cur = [word]
            else:
                cur.append(word)
        if cur:
            out.append(" ".join(cur).strip())
        return out or [text]

    @staticmethod
    def _fingerprint(text: str) -> str:
        return hashlib.md5(text.encode("utf-8")).hexdigest()[:12]


class IngestionEngine:
    def __init__(self) -> None:
        self.normalizer = TextNormalizer()
        self.detector = StructureDetector()
        self.estimator = TokenEstimator()
        self.planner = BudgetPlanner(self.estimator)
        self.segmenter = SmartSegmenter(self.estimator, self.planner)

    def ingest(
        self,
        input_path: str,
        model_name: Optional[str] = None,
        dynamic_overhead_tokens: int = 0,
    ) -> Dict[str, Any]:
        ext = (input_path.rsplit('.', 1)[-1].lower() if '.' in input_path else '')
        blocks, extraction_meta = self._extract_blocks(input_path, ext)
        if not blocks:
            raise ValueError("No extractable text blocks found")

        cleaned_blocks, cleaning_stats = self._normalize_blocks(blocks)
        filtered_blocks, repeated_noise = self._strip_repeated_headers_footers(cleaned_blocks)
        structure, structure_stats = self._reconstruct_structure(filtered_blocks)
        units, segmentation_stats = self.segmenter.segment_units(
            structural_units=structure,
            source_filename=os.path.basename(input_path),
            model_name=model_name,
            dynamic_overhead_tokens=dynamic_overhead_tokens,
        )

        payload = {
            "source_file": os.path.basename(input_path),
            "source_format": ext,
            "model_name": model_name or DEFAULT_MODEL,
            "artifacts": {
                "extraction_meta": extraction_meta,
                "cleaning_stats": cleaning_stats,
                "repeated_noise_removed": repeated_noise,
                "structure_stats": structure_stats,
                "segmentation_stats": segmentation_stats,
            },
            "document_structure": structure,
            "units": [
                {
                    "unit_id": u.unit_id,
                    "display_order": u.display_order,
                    "kind": u.kind,
                    "title": u.title,
                    "text": u.text,
                    "confidence": u.confidence,
                    "warnings": u.warnings,
                    "metadata": u.metadata,
                }
                for u in units
            ],
            "stats": {
                "unit_count": len(units),
                "total_chars": sum(len(u.text) for u in units),
                "estimated_total_tokens": segmentation_stats["estimated_total_tokens"],
                "oversize_units_split": segmentation_stats["oversize_units_split"],
                "safe_input_budget": segmentation_stats["budget"]["safe_input_budget"],
                "target_chunk_budget": segmentation_stats["budget"]["target_chunk_budget"],
            },
        }
        return payload

    # ---------- extraction ----------

    def _extract_blocks(self, path: str, ext: str) -> Tuple[List[ExtractionBlock], Dict[str, Any]]:
        if ext == 'txt':
            return self._extract_txt_blocks(path), {"strategy": "txt_lines"}
        if ext == 'docx':
            return self._extract_docx_blocks(path), {"strategy": "docx_paragraphs"}
        if ext == 'epub':
            return self._extract_epub_blocks(path), {"strategy": "epub_dom" if BS4_AVAILABLE else "epub_regex_fallback"}
        if ext == 'pdf':
            return self._extract_pdf_blocks(path), {"strategy": "pymupdf" if PYMUPDF_AVAILABLE else "pypdf" if PYPDF_AVAILABLE else "none"}

        # plain-text fallback
        return self._extract_txt_blocks(path), {"strategy": "fallback_txt"}

    def _extract_txt_blocks(self, path: str) -> List[ExtractionBlock]:
        with open(path, 'r', encoding='utf-8', errors='ignore') as f:
            content = f.read()
        lines = content.splitlines()
        out: List[ExtractionBlock] = []
        order = 0
        for line in lines:
            text = line.strip()
            if not text:
                continue
            order += 1
            out.append(ExtractionBlock(
                block_id=f"txt_{order}",
                text=text,
                source_page=1,
                source_order=order,
                block_type="unknown",
                style={"is_isolated": True if len(text.split()) <= 8 else False},
            ))
        return out

    def _extract_docx_blocks(self, path: str) -> List[ExtractionBlock]:
        if not DOCX_AVAILABLE:
            raise RuntimeError("python-docx is not installed")
        doc = DocxDocument(path)
        out: List[ExtractionBlock] = []
        order = 0

        for para in doc.paragraphs:
            text = para.text.strip()
            if not text:
                continue
            order += 1
            style_name = (para.style.name.lower() if para.style and para.style.name else "")
            is_heading = 'heading' in style_name or 'title' in style_name
            run_bold = any(bool(r.bold) for r in para.runs if r.text.strip())
            run_italic = any(bool(r.italic) for r in para.runs if r.text.strip())
            out.append(ExtractionBlock(
                block_id=f"docx_{order}",
                text=text,
                source_page=1,
                source_order=order,
                block_type="heading" if is_heading else "paragraph",
                style={
                    "style_name": style_name,
                    "bold": run_bold,
                    "italic": run_italic,
                    "is_isolated": len(text.split()) <= 10,
                },
            ))
        return out

    def _extract_epub_blocks(self, path: str) -> List[ExtractionBlock]:
        import zipfile
        out: List[ExtractionBlock] = []
        order = 0

        with zipfile.ZipFile(path, 'r') as zf:
            html_names = sorted([n for n in zf.namelist() if n.lower().endswith(('.html', '.xhtml', '.htm'))])
            for page_num, name in enumerate(html_names, 1):
                raw = zf.read(name).decode('utf-8', errors='ignore')
                if BS4_AVAILABLE:
                    soup = BeautifulSoup(raw, 'html.parser')
                    for tag in soup.find_all(['h1', 'h2', 'h3', 'p', 'div', 'blockquote', 'hr']):
                        txt = unescape(tag.get_text(" ", strip=True)).strip()
                        if not txt:
                            continue
                        order += 1
                        block_type = 'heading' if tag.name in {'h1', 'h2', 'h3'} else 'paragraph'
                        if tag.name == 'hr':
                            txt = '***'
                            block_type = 'scene_break'
                        out.append(ExtractionBlock(
                            block_id=f"epub_{page_num}_{order}",
                            text=txt,
                            source_page=page_num,
                            source_order=order,
                            block_type=block_type,
                            style={
                                "tag": tag.name,
                                "bold": tag.name in {'h1', 'h2', 'h3'},
                                "is_isolated": len(txt.split()) <= 10,
                            },
                        ))
                else:
                    for m in re.finditer(r'<(h1|h2|h3|p|blockquote)[^>]*>(.*?)</\1>', raw, re.IGNORECASE | re.DOTALL):
                        txt = unescape(re.sub(r'<[^>]+>', ' ', m.group(2))).strip()
                        if not txt:
                            continue
                        order += 1
                        tag = m.group(1).lower()
                        out.append(ExtractionBlock(
                            block_id=f"epub_{page_num}_{order}",
                            text=txt,
                            source_page=page_num,
                            source_order=order,
                            block_type='heading' if tag.startswith('h') else 'paragraph',
                            style={"tag": tag, "is_isolated": len(txt.split()) <= 10},
                        ))
        return out

    def _extract_pdf_blocks(self, path: str) -> List[ExtractionBlock]:
        if PYMUPDF_AVAILABLE:
            return self._extract_pdf_blocks_pymupdf(path)
        if PYPDF_AVAILABLE:
            return self._extract_pdf_blocks_pypdf(path)
        raise RuntimeError("Neither PyMuPDF nor pypdf is installed")

    def _extract_pdf_blocks_pymupdf(self, path: str) -> List[ExtractionBlock]:
        doc = fitz.open(path)
        out: List[ExtractionBlock] = []
        order = 0
        for page_index, page in enumerate(doc, 1):
            page_rect = page.rect
            page_h = float(page_rect.height or 1)
            page_dict = page.get_text("dict")
            for block in page_dict.get("blocks", []):
                if block.get("type") != 0:
                    continue
                block_lines = []
                block_font_sizes: List[float] = []
                block_bold = False
                for line in block.get("lines", []):
                    line_text = []
                    for span in line.get("spans", []):
                        text = span.get("text", "")
                        if text:
                            line_text.append(text)
                        size = span.get("size", 0)
                        if size:
                            block_font_sizes.append(float(size))
                        font_name = str(span.get("font", "")).lower()
                        if 'bold' in font_name:
                            block_bold = True
                    line_joined = ''.join(line_text).strip()
                    if line_joined:
                        block_lines.append(line_joined)
                if not block_lines:
                    continue
                order += 1
                text = "\n".join(block_lines).strip()
                bbox = block.get("bbox", [0, 0, 0, 0])
                y_top = float(bbox[1]) if len(bbox) > 1 else 0.0
                y_bottom = float(bbox[3]) if len(bbox) > 3 else 0.0
                font_size = max(block_font_sizes) if block_font_sizes else 0.0
                out.append(ExtractionBlock(
                    block_id=f"pdf_{page_index}_{order}",
                    text=text,
                    source_page=page_index,
                    source_order=order,
                    block_type="unknown",
                    style={
                        "font_size": font_size,
                        "bold": block_bold,
                        "is_isolated": len(text.split()) <= 12,
                    },
                    position={
                        "y_top": y_top,
                        "y_bottom": y_bottom,
                        "near_top": y_top <= page_h * 0.15,
                        "near_bottom": y_bottom >= page_h * 0.87,
                    }
                ))
        doc.close()
        return out

    def _extract_pdf_blocks_pypdf(self, path: str) -> List[ExtractionBlock]:
        out: List[ExtractionBlock] = []
        with open(path, 'rb') as f:
            reader = pypdf.PdfReader(f)
            order = 0
            for page_index, page in enumerate(reader.pages, 1):
                text = page.extract_text() or ''
                for line in text.splitlines():
                    line = line.strip()
                    if not line:
                        continue
                    order += 1
                    out.append(ExtractionBlock(
                        block_id=f"pdf_{page_index}_{order}",
                        text=line,
                        source_page=page_index,
                        source_order=order,
                        block_type="unknown",
                        style={"is_isolated": len(line.split()) <= 10},
                    ))
        return out

    # ---------- normalization / cleanup ----------

    def _normalize_blocks(self, blocks: List[ExtractionBlock]) -> Tuple[List[ExtractionBlock], Dict[str, Any]]:
        out: List[ExtractionBlock] = []
        aggregate = {
            "block_count_in": len(blocks),
            "block_count_out": 0,
            "chars_in": 0,
            "chars_out": 0,
            "control_removed": 0,
            "hyphen_repairs": 0,
            "warnings": {},
        }

        for block in blocks:
            cleaned, warnings, stats = self.normalizer.normalize_text(block.text)
            aggregate["chars_in"] += stats["chars_in"]
            aggregate["chars_out"] += stats["chars_out"]
            aggregate["control_removed"] += stats["control_removed"]
            aggregate["hyphen_repairs"] += stats["hyphen_repairs"]
            for w in warnings:
                aggregate["warnings"][w] = aggregate["warnings"].get(w, 0) + 1
            if not cleaned:
                continue
            block.text = cleaned
            block.warnings.extend(warnings)
            out.append(block)

        aggregate["block_count_out"] = len(out)
        return out, aggregate

    def _strip_repeated_headers_footers(self, blocks: List[ExtractionBlock]) -> Tuple[List[ExtractionBlock], Dict[str, Any]]:
        by_text_top: Dict[str, int] = {}
        by_text_bottom: Dict[str, int] = {}

        for b in blocks:
            txt = re.sub(r'\s+', ' ', b.text).strip().lower()
            if not txt or len(txt) > MAX_HEADER_FOOTER_LEN:
                continue
            if b.position.get("near_top"):
                by_text_top[txt] = by_text_top.get(txt, 0) + 1
            if b.position.get("near_bottom"):
                by_text_bottom[txt] = by_text_bottom.get(txt, 0) + 1

        top_noise = {t for t, c in by_text_top.items() if c >= HEADER_FOOTER_MIN_REPEAT}
        bottom_noise = {t for t, c in by_text_bottom.items() if c >= HEADER_FOOTER_MIN_REPEAT}

        filtered: List[ExtractionBlock] = []
        removed = {"top": 0, "bottom": 0}
        for b in blocks:
            txt = re.sub(r'\s+', ' ', b.text).strip().lower()
            if txt in top_noise and b.position.get("near_top"):
                removed["top"] += 1
                continue
            if txt in bottom_noise and b.position.get("near_bottom"):
                removed["bottom"] += 1
                continue
            filtered.append(b)

        return filtered, {
            "top_candidates": len(top_noise),
            "bottom_candidates": len(bottom_noise),
            "removed_top_blocks": removed["top"],
            "removed_bottom_blocks": removed["bottom"],
        }

    # ---------- structure ----------

    def _reconstruct_structure(self, blocks: List[ExtractionBlock]) -> Tuple[List[Dict[str, Any]], Dict[str, Any]]:
        units: List[Dict[str, Any]] = []
        current: Optional[Dict[str, Any]] = None
        untitled_counter = 0
        warnings: Dict[str, int] = {}

        def warn(name: str) -> None:
            warnings[name] = warnings.get(name, 0) + 1

        def flush_current() -> None:
            nonlocal current
            if not current:
                return
            text = "\n\n".join(p for p in current["paragraphs"] if p.strip()).strip()
            if text:
                current["text"] = text
                current["confidence"] = round(self._score_unit_confidence(current), 3)
                units.append({
                    "title": current["title"],
                    "kind": current["kind"],
                    "text": text,
                    "source_pages": sorted(list(current["source_pages"])),
                    "warnings": current["warnings"],
                    "confidence": current["confidence"],
                })
            current = None

        for block in blocks:
            txt = block.text.strip()
            if not txt:
                continue

            if self.detector.is_front_matter(txt):
                warn("front_matter_skipped")
                continue

            score, heading_kind, title, chapter_key = self.detector.heading_score(block)

            if heading_kind == "scene_break":
                if current:
                    current["paragraphs"].append("***")
                    current["warnings"].append("scene_break_preserved")
                continue

            if heading_kind in {"chapter_heading", "possible_heading"} and score >= 0.62:
                flush_current()
                current = {
                    "title": title or txt,
                    "kind": "chapter" if heading_kind == "chapter_heading" else "section",
                    "paragraphs": [],
                    "source_pages": {block.source_page},
                    "warnings": list(block.warnings),
                    "heading_score": score,
                    "chapter_key": chapter_key,
                }
                continue

            if current is None:
                untitled_counter += 1
                current = {
                    "title": f"Section {untitled_counter}",
                    "kind": "section",
                    "paragraphs": [],
                    "source_pages": {block.source_page},
                    "warnings": ["implicit_section_start"],
                    "heading_score": 0.35,
                    "chapter_key": None,
                }

            current["paragraphs"].append(txt)
            current["source_pages"].add(block.source_page)
            current["warnings"].extend(block.warnings)

        flush_current()

        # Post-validate suspicious units.
        for unit in units:
            if len(unit["text"]) < 150:
                unit["warnings"].append("very_short_unit")
                unit["confidence"] = round(max(0.35, unit["confidence"] - 0.20), 3)
            if len(unit["text"]) > 60000:
                unit["warnings"].append("very_long_unit")
                unit["confidence"] = round(max(0.35, unit["confidence"] - 0.15), 3)
            if unit["text"].count("\n\n") < 1 and len(unit["text"]) > 5000:
                unit["warnings"].append("low_paragraph_density")
                unit["confidence"] = round(max(0.4, unit["confidence"] - 0.1), 3)

        stats = {
            "structural_unit_count": len(units),
            "warnings": warnings,
            "avg_confidence": round(sum(u["confidence"] for u in units) / max(1, len(units)), 3),
        }
        return units, stats

    def _score_unit_confidence(self, current: Dict[str, Any]) -> float:
        score = 0.78
        text = "\n\n".join(current["paragraphs"]).strip()
        para_count = max(1, text.count("\n\n") + 1)

        score += min(0.14, float(current.get("heading_score", 0)) * 0.18)
        if para_count < 2 and len(text) < 400:
            score -= 0.18
        if len(text) > 30000:
            score -= 0.08
        if current["warnings"]:
            score -= min(0.18, len(current["warnings"]) * 0.03)
        return max(0.25, min(0.99, score))


class IngestionStage(BaseStage):
    """Model-aware ingestion with structure reconstruction and confidence metadata.

    Expected stage_input.metadata optional keys:
      - target_model: str
      - prompt_overhead_tokens: int

    Output artifacts:
      - raw_extracted_blocks.json
      - normalized_structure.json
      - segmented_units.json
      - normalized_input.json  (compat payload for downstream stages)
    """

    @property
    def stage_type(self) -> StageType:
        return StageType.INGESTION

    def execute(self, stage_input: StageInput) -> StageOutput:
        try:
            input_path = stage_input.input_artifact_path
            if not input_path or not os.path.exists(input_path):
                return StageOutput(
                    stage=self.stage_type,
                    status=StageStatus.FAILED,
                    error_message=f"Input file not found: {input_path}",
                    error_code="FILE_NOT_FOUND",
                )

            metadata = getattr(stage_input, "metadata", {}) or {}
            model_name = metadata.get("target_model") or DEFAULT_MODEL
            dynamic_overhead_tokens = int(metadata.get("prompt_overhead_tokens", 0) or 0)

            engine = IngestionEngine()
            payload = engine.ingest(
                input_path=input_path,
                model_name=model_name,
                dynamic_overhead_tokens=dynamic_overhead_tokens,
            )

            # Persist decomposed artifacts for better debugging / re-segmentation.
            raw_blocks_path = self.get_output_path(stage_input, "raw_extracted_blocks.json")
            structure_path = self.get_output_path(stage_input, "normalized_structure.json")
            segmented_path = self.get_output_path(stage_input, "segmented_units.json")
            compat_path = self.get_output_path(stage_input, "normalized_input.json")

            # raw block export omitted from payload; reconstruct shallow export from structure artifacts for debug.
            with open(raw_blocks_path, 'w', encoding='utf-8') as f:
                json.dump(payload["artifacts"], f, ensure_ascii=False, indent=2)

            with open(structure_path, 'w', encoding='utf-8') as f:
                json.dump({
                    "source_file": payload["source_file"],
                    "source_format": payload["source_format"],
                    "model_name": payload["model_name"],
                    "document_structure": payload["document_structure"],
                    "artifacts": {
                        "cleaning_stats": payload["artifacts"]["cleaning_stats"],
                        "repeated_noise_removed": payload["artifacts"]["repeated_noise_removed"],
                        "structure_stats": payload["artifacts"]["structure_stats"],
                    }
                }, f, ensure_ascii=False, indent=2)

            with open(segmented_path, 'w', encoding='utf-8') as f:
                json.dump({
                    "source_file": payload["source_file"],
                    "model_name": payload["model_name"],
                    "units": payload["units"],
                    "segmentation_stats": payload["artifacts"]["segmentation_stats"],
                }, f, ensure_ascii=False, indent=2)

            # Compatibility payload for downstream code that expects normalized_input.json
            compat_payload = {
                "source_file": payload["source_file"],
                "source_format": payload["source_format"],
                "units": payload["units"],
                "stats": payload["stats"],
                "artifacts": payload["artifacts"],
            }
            with open(compat_path, 'w', encoding='utf-8') as f:
                json.dump(compat_payload, f, ensure_ascii=False, indent=2)

            return StageOutput(
                stage=self.stage_type,
                status=StageStatus.COMPLETED,
                output_artifact_path=compat_path,
                metrics={
                    **payload["stats"],
                    "avg_structure_confidence": payload["artifacts"]["structure_stats"].get("avg_confidence", 0),
                    "model_name": payload["model_name"],
                },
            )

        except Exception as e:
            return StageOutput(
                stage=self.stage_type,
                status=StageStatus.FAILED,
                error_message=f"Ingestion failed: {str(e)}",
                error_code=e.__class__.__name__,
            )
