"""
pipeline_core/stages/batch_planning.py
========================================
BATCH_PLANNING stage.

Reads the preprocessed context, builds the chunk manifest using smart
semantic chunking, attaches rich carryover context to each chunk, runs
quality validation, and writes the manifest artifact.
"""
import json
import logging
import os
from typing import List, Dict, Any

from .base import BaseStage
from ..core.models import StageInput, StageOutput, StageType, StageStatus
from ..translation.provider_profiles import SCITELY_PROFILE
from ..translation.chunk_builder import build_chunks
from ..translation.chunk_quality_rules import validate_all_chunks

logger = logging.getLogger(__name__)


class BatchPlanningStage(BaseStage):
    @property
    def stage_type(self) -> StageType:
        return StageType.BATCH_PLANNING

    def execute(self, stage_input: StageInput) -> StageOutput:
        try:
            input_path = stage_input.input_artifact_path

            if not input_path or not os.path.exists(input_path):
                return StageOutput(
                    stage=self.stage_type,
                    status=StageStatus.FAILED,
                    error_message=f"Input artifact not found: {input_path}",
                    error_code="ARTIFACT_NOT_FOUND",
                )

            with open(input_path, "r", encoding="utf-8") as f:
                context_data = json.load(f)

            units = context_data.get("units", [])
            if not units:
                return StageOutput(
                    stage=self.stage_type,
                    status=StageStatus.FAILED,
                    error_message="Context data contains no units to batch.",
                    error_code="EMPTY_INPUT_UNITS",
                )

            global_context = context_data.get("global_context", {})
            profile        = SCITELY_PROFILE

            # Build chunks with semantic splitting + rich carryover context
            chunks = build_chunks(
                job_id         = stage_input.job_id,
                units          = units,
                profile        = profile,
                global_context = global_context,
            )

            # Run quality validation — warnings are attached to manifest,
            # but do NOT fail the stage
            quality_issues = validate_all_chunks(chunks)
            total_warnings = sum(len(v) for v in quality_issues.values())
            if quality_issues:
                logger.warning(
                    f"Batch quality issues: {total_warnings} warning(s) across "
                    f"{len(quality_issues)} chunk(s)."
                )

            # Build the batch list expected by TranslationStage
            batches: List[Dict[str, Any]] = []
            for chunk in chunks:
                batches.append({
                    "batch_id":       chunk["chunk_id"],
                    "unit_ids":       chunk["unit_ids"],
                    "order_start":    chunk["order_start"],
                    "order_end":      chunk["order_end"],
                    "estimated_chars": chunk["estimated_chars"],
                    "split_reason":   chunk["split_reason"],
                    "context_bundle": chunk["context_bundle"],
                    "retry_count":    0,
                    # Quality warnings embedded in manifest for inspection
                    "quality_warnings": quality_issues.get(chunk["chunk_id"], []),
                })

            manifest_payload = {
                "job_id":                 stage_input.job_id,
                "provider_profile":       profile.name,
                "target_chars_per_chunk": profile.target_chars_per_chunk,
                "max_chars_per_chunk":    profile.max_chars_per_chunk,
                "total_units":            len(units),
                "total_batches":          len(batches),
                "quality_summary": {
                    "chunks_with_warnings": len(quality_issues),
                    "total_warnings":       total_warnings,
                },
                "batches": batches,
            }

            output_filepath = self.get_output_path(stage_input, "batch_manifest.json")
            with open(output_filepath, "w", encoding="utf-8") as f:
                json.dump(manifest_payload, f, ensure_ascii=False, indent=2)

            return StageOutput(
                stage=self.stage_type,
                status=StageStatus.COMPLETED,
                output_artifact_path=output_filepath,
                metrics={
                    "total_units":           len(units),
                    "total_batches":         len(batches),
                    "chunks_with_warnings":  len(quality_issues),
                    "total_quality_warnings": total_warnings,
                },
            )

        except json.JSONDecodeError as e:
            return StageOutput(
                stage=self.stage_type,
                status=StageStatus.FAILED,
                error_message=f"Corrupt input artifact: {e}",
                error_code="INVALID_JSON",
            )
        except Exception as e:
            logger.exception("BatchPlanningStage crashed")
            return StageOutput(
                stage=self.stage_type,
                status=StageStatus.FAILED,
                error_message=f"Batch planning failed: {e}",
                error_code=e.__class__.__name__,
            )
