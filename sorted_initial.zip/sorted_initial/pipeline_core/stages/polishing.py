import json
import os
from typing import List, Dict, Any

from .base import BaseStage
from ..core.models import StageInput, StageOutput, StageType, StageStatus
from ..providers.scitely_provider import ScitelyProvider
from ..polishing.polish_service import polish_units

class PolishingStage(BaseStage):
    @property
    def stage_type(self) -> StageType:
        return StageType.POLISHING

    def execute(self, stage_input: StageInput) -> StageOutput:
        try:
            input_path = stage_input.input_artifact_path
            
            if not input_path or not os.path.exists(input_path):
                return StageOutput(
                    stage=self.stage_type,
                    status=StageStatus.FAILED,
                    error_message=f"TRANSLATION artifact dependency not found.",
                    error_code="DEPENDENCY_NOT_FOUND"
                )
                
            artifact_index = stage_input.context.get("artifact_index", {})
            context_path = artifact_index.get("PREPROCESSING")
            
            if not context_path or not os.path.exists(context_path):
                return StageOutput(
                    stage=self.stage_type,
                    status=StageStatus.FAILED,
                    error_message=f"PREPROCESSING dependency missing natively.",
                    error_code="DEPENDENCY_NOT_FOUND"
                )
                
            provider = ScitelyProvider()
            
            with open(input_path, 'r', encoding='utf-8') as f:
                translation_data = json.load(f)
                
            with open(context_path, 'r', encoding='utf-8') as f:
                context_data = json.load(f)
                
            trans_units = translation_data.get("units", [])
            
            global_context = context_data.get("global_context", {})
            glossary_map = global_context.get("glossary_map", {})
            
            # Map units for context injection (Address, Voice, Flow) 
            units_context = context_data.get("units", [])
            unit_lookup = {u.get("unit_id"): u for u in units_context if u.get("unit_id")}
            
            success, result_payload = polish_units(
                trans_units, 
                unit_lookup, 
                global_context, 
                provider
            )
            
            if not success:
               return StageOutput(
                    stage=self.stage_type,
                    status=StageStatus.FAILED,
                    error_message=result_payload.get("message", "Polishing Failed"),
                    error_code=result_payload.get("code", "POLISHING_FAILURE")
               )
            
            output_payload = {
                "job_id": stage_input.job_id,
                "units": result_payload
            }
            
            output_filepath = self.get_output_path(stage_input, "polished_output.json")
            
            with open(output_filepath, 'w', encoding='utf-8') as f:
                json.dump(output_payload, f, ensure_ascii=False, indent=2)
                
            return StageOutput(
                stage=self.stage_type,
                status=StageStatus.COMPLETED,
                output_artifact_path=output_filepath,
                metrics={
                    "total_units_polished": len(result_payload)
                }
            )
            
        except json.JSONDecodeError as e:
            return StageOutput(
                stage=self.stage_type,
                status=StageStatus.FAILED,
                error_message=f"Corrupt json read detected: {str(e)}",
                error_code="INVALID_JSON"
            )
        except Exception as e:
            return StageOutput(
                stage=self.stage_type,
                status=StageStatus.FAILED,
                error_message=f"Polishing execution loop failed: {str(e)}",
                error_code=e.__class__.__name__
            )
