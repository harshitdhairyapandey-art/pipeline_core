import os
from abc import ABC, abstractmethod
from ..core.models import StageInput, StageOutput, StageType

class BaseStage(ABC):
    @property
    @abstractmethod
    def stage_type(self) -> StageType:
        """Define the stage type for tracking in the orchestrator."""
        pass

    @abstractmethod
    def execute(self, stage_input: StageInput) -> StageOutput:
        """
        Reads one artifact defined in stage_input and writes one artifact.
        Returns a StageOutput representing the result of the stage.
        """
        pass

    def get_output_path(self, stage_input: StageInput, filename: str) -> str:
        """
        Enforce artifact paths logically grouped under working_dir/artifacts/<stage_name>/
        Safely creates the directory if it does not exist.
        """
        stage_dir = os.path.join(stage_input.working_dir, "artifacts", self.stage_type.value.lower())
        os.makedirs(stage_dir, exist_ok=True)
        return os.path.join(stage_dir, filename)
