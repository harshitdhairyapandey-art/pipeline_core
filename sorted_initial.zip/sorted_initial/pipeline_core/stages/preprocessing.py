"""
pipeline_core/stages/preprocessing.py
=======================================
PREPROCESSING stage — deterministic by default, AI-enriched when available.

Key behaviours:
- AI Analyst is initialized once per stage execution.
- If SCITELY_API_KEY is absent the stage still completes (heuristics only).
- Document-level AI enrichment (address hierarchy, voice profiles, volume flow,
  TTS profiles) runs ONCE over a sample of units — not per-unit — to save quota.
- Per-unit AI enrichment (chapter analysis, devanagari) runs per unit.
- Any AI failure at any level is caught and logged; never crashes the stage.
"""
import json
import logging
import os
import re
from typing import List, Dict, Any, Optional

from .base import BaseStage
from ..core.models import StageInput, StageOutput, StageType, StageStatus

logger = logging.getLogger(__name__)

# Minimum characters in a unit before we bother enriching with AI
_AI_MIN_UNIT_LEN = 200
# Max chars to sample from the document for doc-level AI calls
_DOC_SAMPLE_CHARS = 12000


def _build_doc_sample(units: List[Dict[str, Any]]) -> str:
    """Build a compact document sample for doc-level AI calls."""
    parts = []
    total = 0
    for u in units:
        text = u.get("clean_text", "")
        if total + len(text) > _DOC_SAMPLE_CHARS:
            remaining = _DOC_SAMPLE_CHARS - total
            if remaining > 100:
                parts.append(text[:remaining])
            break
        parts.append(text)
        total += len(text)
    return "\n\n".join(parts)


class PreprocessingStage(BaseStage):
    @property
    def stage_type(self) -> StageType:
        return StageType.PREPROCESSING

    def execute(self, stage_input: StageInput) -> StageOutput:
        try:
            input_path = stage_input.input_artifact_path

            if not input_path or not os.path.exists(input_path):
                return StageOutput(
                    stage=self.stage_type,
                    status=StageStatus.FAILED,
                    error_message=f"Input artifact not found: {input_path}",
                    error_code="ARTIFACT_NOT_FOUND",
                )

            with open(input_path, "r", encoding="utf-8") as f:
                ingested_data = json.load(f)

            raw_units = ingested_data.get("units", [])
            if not raw_units:
                return StageOutput(
                    stage=self.stage_type,
                    status=StageStatus.FAILED,
                    error_message="Ingested data contains no units to preprocess.",
                    error_code="EMPTY_INPUT_UNITS",
                )

            # ------------------------------------------------------------------
            # Initialize AI Analyst (optional — tolerate missing API key)
            # ------------------------------------------------------------------
            analyst: Optional[object] = None
            try:
                from ..providers.scitely_provider import ScitelyProvider
                from ..preprocessing.ai_analyst import AIAnalyst
                provider = ScitelyProvider()
                analyst  = AIAnalyst(provider)
                logger.info("AIAnalyst initialized — AI enrichment enabled.")
            except ValueError:
                logger.info("SCITELY_API_KEY not set — running heuristics-only preprocessing.")
            except Exception as e:
                logger.warning(f"AIAnalyst init failed ({e}) — falling back to heuristics.")

            # ------------------------------------------------------------------
            # Per-unit processing
            # ------------------------------------------------------------------
            from ..preprocessing.preprocessing_assembler import assemble_context

            processed_units: List[Dict[str, Any]] = []
            total_chars     = 0
            invalid_count   = 0

            for unit in raw_units:
                unit_id      = unit.get("unit_id")
                display_order = unit.get("display_order")
                raw_text      = unit.get("text")

                if not unit_id or display_order is None or raw_text is None:
                    invalid_count += 1
                    continue

                clean_text = raw_text.replace("\r\n", "\n").replace("\r", "\n")
                clean_text = re.sub(r"\n{3,}", "\n\n", clean_text).strip()
                total_chars += len(clean_text)

                processed_unit: Dict[str, Any] = {
                    "unit_id":       unit_id,
                    "display_order": display_order,
                    "kind":          unit.get("kind", "text"),
                    "title":         unit.get("title", ""),
                    "clean_text":    clean_text,
                    "metadata":      unit.get("metadata", {}),
                }

                # Inject previous unit for flow context (assembler pops it)
                if processed_units:
                    processed_unit["temporary_previous_unit"] = processed_units[-1]

                # Pass analyst only if text is long enough to justify AI calls
                unit_analyst = analyst if len(clean_text) >= _AI_MIN_UNIT_LEN else None

                context_bundle = assemble_context(processed_unit, analyst=unit_analyst)
                processed_unit.update(context_bundle)
                processed_units.append(processed_unit)

            if not processed_units:
                return StageOutput(
                    stage=self.stage_type,
                    status=StageStatus.FAILED,
                    error_message=f"All {invalid_count} units failed schema validation.",
                    error_code="ALL_UNITS_INVALID",
                )

            # ------------------------------------------------------------------
            # Document-level AI enrichment (once, over a sample)
            # ------------------------------------------------------------------
            doc_sample = _build_doc_sample(processed_units)

            ai_volume_flow    = {}
            ai_voice_profiles = {}
            ai_address_global = []
            ai_tts_profiles   = {}

            if analyst and doc_sample:
                # Volume flow
                try:
                    ai_volume_flow = analyst.build_volume_flow(doc_sample)
                except Exception as e:
                    logger.warning(f"AIAnalyst.build_volume_flow failed: {e}")

                # Voice profiles
                try:
                    ai_voice_profiles = analyst.build_voice_profiles(doc_sample)
                except Exception as e:
                    logger.warning(f"AIAnalyst.build_voice_profiles failed: {e}")

                # Global address hierarchy (supplement per-unit heuristics)
                try:
                    ai_address_global = analyst.detect_address_hierarchy(doc_sample)
                except Exception as e:
                    logger.warning(f"AIAnalyst global address detection failed: {e}")

                # TTS profiles
                voice_ctx_str = json.dumps(ai_voice_profiles, ensure_ascii=False)[:2000]
                try:
                    ai_tts_profiles = analyst.build_tts_profiles(voice_ctx_str, doc_sample)
                except Exception as e:
                    logger.warning(f"AIAnalyst.build_tts_profiles failed: {e}")

            # ------------------------------------------------------------------
            # Global context assembly
            # ------------------------------------------------------------------
            from ..preprocessing.global_context_builder import build_global_context
            from ..glossary.glossary_builder import build_global_glossary
            from ..glossary.glossary_mapper import create_glossary_map

            global_context = build_global_context(processed_units)

            # Overlay AI volume flow data if available
            if ai_volume_flow:
                global_context["ai_volume_flow"] = ai_volume_flow
                if ai_volume_flow.get("dominant_tone"):
                    global_context["global_tone"] = ai_volume_flow["dominant_tone"]

            if ai_voice_profiles:
                global_context["ai_voice_profiles"] = ai_voice_profiles

            if ai_address_global:
                global_context["ai_address_hierarchy"] = ai_address_global

            if ai_tts_profiles:
                global_context["ai_tts_profiles"] = ai_tts_profiles

            # Build and attach glossary map
            raw_glossary  = build_global_glossary(processed_units)
            glossary_map  = create_glossary_map(raw_glossary)
            global_context["glossary_map"] = glossary_map

            # ------------------------------------------------------------------
            # Write output artifact
            # ------------------------------------------------------------------
            preprocessed_payload = {
                "job_id":         stage_input.job_id,
                "units":          processed_units,
                "global_context": global_context,
            }

            output_filepath = self.get_output_path(stage_input, "preprocessed_context.json")
            with open(output_filepath, "w", encoding="utf-8") as f:
                json.dump(preprocessed_payload, f, ensure_ascii=False, indent=2)

            ai_status = "enabled" if analyst else "heuristics_only"
            return StageOutput(
                stage=self.stage_type,
                status=StageStatus.COMPLETED,
                output_artifact_path=output_filepath,
                metrics={
                    "unit_count":      len(processed_units),
                    "total_chars":     total_chars,
                    "invalid_units":   invalid_count,
                    "ai_enrichment":   ai_status,
                },
            )

        except json.JSONDecodeError as e:
            return StageOutput(
                stage=self.stage_type,
                status=StageStatus.FAILED,
                error_message=f"Corrupt input artifact: {e}",
                error_code="INVALID_JSON",
            )
        except Exception as e:
            logger.exception("Preprocessing stage crashed")
            return StageOutput(
                stage=self.stage_type,
                status=StageStatus.FAILED,
                error_message=f"Preprocessing failed: {e}",
                error_code=e.__class__.__name__,
            )
