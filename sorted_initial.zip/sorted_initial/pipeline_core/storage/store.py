"""
Full DuckDB storage — 8 tables for complete pipeline lineage.

Tables:
  books             source file metadata
  chapters          chapter-level records
  chunks            translation-unit records
  runs              pipeline execution records
  batches           micro-batch records
  events            timestamped log events
  errors            classified error records
  preprocessing_log chapter preprocessing results
"""
import duckdb
import threading
import time
import uuid
from pathlib import Path


class Store:
    def __init__(self, db_path: str = "data/pipeline.duckdb"):
        Path(db_path).parent.mkdir(parents=True, exist_ok=True)
        self._path = db_path
        self._lock = threading.Lock()
        self._local = threading.local()
        self._init_schema()

    def _conn(self):
        if not getattr(self._local, "con", None):
            self._local.con = duckdb.connect(self._path)
        return self._local.con

    def _exec(self, sql, params=None):
        with self._lock:
            return self._conn().execute(sql, params or [])

    def _query(self, sql, params=None):
        with self._lock:
            cur = self._conn().execute(sql, params or [])
            rows = cur.fetchall()
            cols = [d[0] for d in cur.description] if cur.description else []
            return [dict(zip(cols, r)) for r in rows]

    def _init_schema(self):
        self._exec("""CREATE TABLE IF NOT EXISTS books (
            book_id VARCHAR PRIMARY KEY, source_path VARCHAR,
            title VARCHAR, total_chapters INTEGER, created_at DOUBLE
        )""")
        self._exec("""CREATE TABLE IF NOT EXISTS chapters (
            chapter_id VARCHAR PRIMARY KEY, book_id VARCHAR,
            chapter_num INTEGER, heading VARCHAR, char_count INTEGER,
            status VARCHAR DEFAULT 'pending'
        )""")
        self._exec("""CREATE TABLE IF NOT EXISTS chunks (
            chunk_id VARCHAR PRIMARY KEY, chapter_id VARCHAR,
            chunk_index INTEGER, source_text_len INTEGER,
            translated_len INTEGER DEFAULT 0, polished_len INTEGER DEFAULT 0,
            status VARCHAR DEFAULT 'pending'
        )""")
        self._exec("""CREATE TABLE IF NOT EXISTS runs (
            run_id VARCHAR PRIMARY KEY, book_id VARCHAR,
            status VARCHAR, started_at DOUBLE, finished_at DOUBLE,
            total_chapters INTEGER, completed_chapters INTEGER DEFAULT 0
        )""")
        self._exec("""CREATE TABLE IF NOT EXISTS batches (
            batch_id VARCHAR PRIMARY KEY, run_id VARCHAR,
            chunk_ids VARCHAR, status VARCHAR, api_calls INTEGER DEFAULT 0,
            created_at DOUBLE
        )""")
        self._exec("""CREATE TABLE IF NOT EXISTS events (
            event_id VARCHAR, run_id VARCHAR, ts DOUBLE,
            stage VARCHAR, message VARCHAR
        )""")
        self._exec("""CREATE TABLE IF NOT EXISTS errors (
            error_id VARCHAR, run_id VARCHAR, ts DOUBLE,
            category VARCHAR, stage VARCHAR, message VARCHAR,
            chunk_id VARCHAR
        )""")
        self._exec("""CREATE TABLE IF NOT EXISTS preprocessing_log (
            chapter_num INTEGER, stage VARCHAR, ts DOUBLE,
            result_json VARCHAR
        )""")

    def _uid(self, prefix=""):
        return f"{prefix}{uuid.uuid4().hex[:12]}"

    # ── Books ──
    def register_book(self, source_path, title, total_chapters):
        bid = self._uid("book_")
        self._exec(
            "INSERT INTO books VALUES (?,?,?,?,?)",
            [bid, source_path, title, total_chapters, time.time()],
        )
        return bid

    # ── Chapters ──
    def register_chapter(self, book_id, chapter_num, heading="", char_count=0):
        cid = self._uid("ch_")
        self._exec(
            "INSERT INTO chapters VALUES (?,?,?,?,?,?)",
            [cid, book_id, chapter_num, heading, char_count, "pending"],
        )
        return cid

    def set_chapter_status(self, chapter_id, status):
        self._exec("UPDATE chapters SET status=? WHERE chapter_id=?",
                    [status, chapter_id])

    # ── Chunks ──
    def register_chunk(self, chapter_id, chunk_index, source_len):
        cid = self._uid("ck_")
        self._exec(
            "INSERT INTO chunks VALUES (?,?,?,?,?,?,?)",
            [cid, chapter_id, chunk_index, source_len, 0, 0, "pending"],
        )
        return cid

    def update_chunk(self, chunk_id, **kwargs):
        sets = ", ".join(f"{k}=?" for k in kwargs)
        vals = list(kwargs.values()) + [chunk_id]
        self._exec(f"UPDATE chunks SET {sets} WHERE chunk_id=?", vals)

    # ── Runs ──
    def create_run(self, book_id, total_chapters):
        rid = self._uid("run_")
        self._exec(
            "INSERT INTO runs VALUES (?,?,?,?,?,?,?)",
            [rid, book_id, "running", time.time(), 0.0, total_chapters, 0],
        )
        return rid

    def finish_run(self, run_id, status="complete"):
        self._exec(
            "UPDATE runs SET status=?, finished_at=? WHERE run_id=?",
            [status, time.time(), run_id],
        )

    def increment_completed(self, run_id):
        self._exec(
            "UPDATE runs SET completed_chapters = completed_chapters + 1 WHERE run_id=?",
            [run_id],
        )

    def list_runs(self):
        return self._query("SELECT * FROM runs ORDER BY started_at DESC")

    # ── Events ──
    def log_event(self, run_id, stage, message):
        self._exec(
            "INSERT INTO events VALUES (?,?,?,?,?)",
            [self._uid("evt_"), run_id, time.time(), stage, message],
        )

    # ── Errors ──
    def log_error(self, run_id, category, stage, message, chunk_id=""):
        self._exec(
            "INSERT INTO errors VALUES (?,?,?,?,?,?,?)",
            [self._uid("err_"), run_id, time.time(), category,
             stage, message, chunk_id],
        )

    def get_errors(self, run_id):
        return self._query(
            "SELECT * FROM errors WHERE run_id=? ORDER BY ts", [run_id]
        )

    # ── Preprocessing log ──
    def log_preprocessing(self, chapter_num, stage, result_json):
        self._exec(
            "INSERT INTO preprocessing_log VALUES (?,?,?,?)",
            [chapter_num, stage, time.time(), result_json],
        )


store = Store()
