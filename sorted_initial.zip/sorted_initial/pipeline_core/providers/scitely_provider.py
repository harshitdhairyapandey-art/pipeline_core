"""
pipeline_core/providers/scitely_provider.py
=============================================
Hardened Scitely provider.

Key improvements over v1:
- Safe response extraction (never blindly index response["choices"])
- Structured Retry-After surfacing on 429
- Structured error payload detection before raising
- Timeout configurable via env / provider profile
- min_p graceful fallback per model
- Streaming via openai client, requests fallback
- call_json() with JSON retry cap
- All retry/backoff logic contained here; resilience layer wraps it externally
"""
import os
import re
import json
import time
import logging
import threading
import requests
from typing import Dict, Any, Optional

from .client import (
    AIProviderClient,
    ProviderError,
    ProviderTimeoutError,
    ProviderRateLimitError,
    ProviderAuthError,
    ProviderTemporaryError,
    ProviderResponseError,
    extract_text_from_response,
    extract_error_from_response,
)

try:
    from openai import OpenAI as _OpenAI
    _OPENAI_AVAILABLE = True
except ImportError:
    _OPENAI_AVAILABLE = False

# ---------------------------------------------------------------------------
# Module-level rate limiter (slot-reservation, sleep OUTSIDE the lock)
# Scitely Community: 60 RPM hard limit, 10 RPS burst
# Safe operating target: 50 RPM (≈ 0.83 RPS), 2 RPS burst ceiling
# ---------------------------------------------------------------------------
_rate_lock      = threading.Lock()
_last_req_time  = 0.0
# 0.5s interval ≈ 2 RPS burst ceiling — well under 10 RPS hard limit
MIN_INTERVAL    = float(os.getenv("SCITELY_MIN_INTERVAL", "0.5"))
MIN_P_DEFAULT   = float(os.getenv("SCITELY_MIN_P", "0.07"))

MAX_EMPTY_RETRIES   = 5
MAX_GENERAL_RETRIES = 5
RETRY_BACKOFF_BASE  = 2   # seconds; doubles per attempt
DEFAULT_TIMEOUT     = float(os.getenv("SCITELY_TIMEOUT", "600.0"))  # 600s per spec


def _acquire_slot() -> None:
    """Rate-limit: sleep outside the lock to avoid holding it during sleep."""
    global _last_req_time
    sleep_until: Optional[float] = None
    with _rate_lock:
        now = time.time()
        if now >= _last_req_time + MIN_INTERVAL:
            _last_req_time = now
        else:
            _last_req_time += MIN_INTERVAL
            sleep_until = _last_req_time
    if sleep_until is not None:
        remaining = sleep_until - time.time()
        if remaining > 0:
            time.sleep(remaining)


def _parse_retry_after(headers: dict) -> Optional[float]:
    """Extract Retry-After value (seconds) from response headers if present."""
    val = headers.get("Retry-After") or headers.get("retry-after")
    if val is None:
        return None
    try:
        return float(val)
    except (ValueError, TypeError):
        return None


class ScitelyProvider(AIProviderClient):
    def __init__(
        self,
        retry_policy: Optional[Dict[str, Any]] = None,
        timeout: Optional[float] = None,
    ):
        if retry_policy is None:
            retry_policy = {"max_retries": 3, "backoff": 2}
        super().__init__(retry_policy)

        self.api_key = os.getenv("SCITELY_API_KEY")
        if not self.api_key:
            raise ValueError("SCITELY_API_KEY environment variable is required.")

        self.model    = os.getenv("SCITELY_MODEL", "deepseek-v3.2")
        self.endpoint = os.getenv("SCITELY_API_URL", "https://api.scitely.com/v1/chat/completions")
        self.timeout  = timeout or DEFAULT_TIMEOUT
        self._min_p_supported: Optional[bool] = None  # tri-state: None = unknown

    # ------------------------------------------------------------------
    # Public interface
    # ------------------------------------------------------------------

    def call_ai(
        self,
        system_prompt: str,
        user_text: str,
        temperature: float = 0.3,
        sampling_params: Optional[Dict[str, Any]] = None,
    ) -> str:
        """
        Generic entry point for all AI calls.
        Routes to streaming path (preferred) or requests fallback.
        Returns cleaned text content string.
        """
        if not user_text or not user_text.strip():
            return ""

        sampling_params = dict(sampling_params or {})

        if _OPENAI_AVAILABLE:
            return self._stream_call(system_prompt, user_text, temperature, sampling_params)
        return self._requests_call(system_prompt, user_text, temperature, sampling_params)

    def translate_text(self, text: str, **kwargs) -> str:
        system_prompt = kwargs.pop("system_prompt", "You are a professional Hindi literary translator.")
        temperature   = kwargs.pop("temperature", 0.3)
        return self.call_ai(system_prompt, text, temperature=temperature, sampling_params=kwargs)

    def call_json(
        self,
        system_prompt: str,
        user_text: str,
        temperature: float = 0.2,
    ) -> dict:
        """
        Call Scitely and parse a JSON response.
        Retries up to MAX_JSON_RETRIES times on bad JSON before raising.
        """
        MAX_JSON_RETRIES = 5
        json_attempts = 0

        while True:
            content = self.call_ai(system_prompt, user_text, temperature=temperature)
            if not content:
                json_attempts += 1
                if json_attempts >= MAX_JSON_RETRIES:
                    raise ProviderResponseError(
                        f"Scitely returned empty content {MAX_JSON_RETRIES} times."
                    )
                time.sleep(RETRY_BACKOFF_BASE * json_attempts)
                continue

            cleaned = self._clean_response(content, system_prompt)
            try:
                return json.loads(cleaned)
            except json.JSONDecodeError:
                # Try to extract the outermost JSON object/array
                start = cleaned.find("{")
                end   = cleaned.rfind("}")
                if start >= 0 and end > start:
                    try:
                        return json.loads(cleaned[start:end + 1])
                    except json.JSONDecodeError:
                        pass
                # Try array
                start_a = cleaned.find("[")
                end_a   = cleaned.rfind("]")
                if start_a >= 0 and end_a > start_a:
                    try:
                        return json.loads(cleaned[start_a:end_a + 1])
                    except json.JSONDecodeError:
                        pass

            json_attempts += 1
            if json_attempts >= MAX_JSON_RETRIES:
                raise ProviderResponseError(
                    f"Scitely returned invalid JSON {MAX_JSON_RETRIES} times. "
                    f"Last snippet: {content[:300]}"
                )
            time.sleep(RETRY_BACKOFF_BASE * json_attempts)

    # ------------------------------------------------------------------
    # Streaming path
    # ------------------------------------------------------------------

    def _stream_call(
        self,
        system_prompt: str,
        user_text: str,
        temperature: float,
        sampling_params: Dict[str, Any],
    ) -> str:
        client = _OpenAI(
            api_key=self.api_key,
            base_url="https://api.scitely.com/v1",
            timeout=self.timeout,
        )
        extra = {
            k: v for k, v in sampling_params.items()
            if k in ("min_p", "top_p", "frequency_penalty", "presence_penalty")
        }
        max_tokens = sampling_params.get("max_tokens", 8192)

        # If we already know min_p is unsupported, skip it
        if self._min_p_supported is False:
            extra.pop("min_p", None)

        # If min_p not explicitly supplied, add our default
        if "min_p" not in extra and self._min_p_supported is not False:
            extra["min_p"] = MIN_P_DEFAULT

        empty_attempts   = 0
        general_attempts = 0

        while True:
            _acquire_slot()
            try:
                stream = client.chat.completions.create(
                    model=self.model,
                    messages=[
                        {"role": "system", "content": system_prompt},
                        {"role": "user",   "content": user_text},
                    ],
                    temperature=temperature,
                    max_tokens=max_tokens,
                    stream=True,
                    **extra,
                )
                content = ""
                for chunk in stream:
                    if chunk.choices:
                        delta = chunk.choices[0].delta.content
                        if delta:
                            content += delta

                if content.strip():
                    if self._min_p_supported is None and "min_p" in extra:
                        self._min_p_supported = True
                    return self._clean_response(content, system_prompt)

                empty_attempts += 1
                if empty_attempts >= MAX_EMPTY_RETRIES:
                    raise ProviderResponseError(
                        f"Scitely returned empty response {MAX_EMPTY_RETRIES} times."
                    )
                time.sleep(RETRY_BACKOFF_BASE * empty_attempts)

            except (ProviderError, ProviderResponseError):
                raise
            except Exception as e:
                err_str = str(e).lower()
                # Detect min_p rejection and retry without it
                if ("min_p" in err_str or "unexpected" in err_str) and "min_p" in extra:
                    logging.warning("min_p rejected by model — retrying without it.")
                    self._min_p_supported = False
                    extra.pop("min_p", None)
                    continue
                general_attempts += 1
                if general_attempts >= MAX_GENERAL_RETRIES:
                    raise ProviderError(
                        f"Scitely stream call failed after {MAX_GENERAL_RETRIES} retries. "
                        f"Last error: {e}"
                    ) from e
                logging.warning(f"Stream error (attempt {general_attempts}): {e}")
                time.sleep(RETRY_BACKOFF_BASE * (2 ** (general_attempts - 1)))

    # ------------------------------------------------------------------
    # Requests fallback path
    # ------------------------------------------------------------------

    def _requests_call(
        self,
        system_prompt: str,
        user_text: str,
        temperature: float,
        sampling_params: Dict[str, Any],
    ) -> str:
        request_data: Dict[str, Any] = {
            "model": self.model,
            "messages": [
                {"role": "system", "content": system_prompt},
                {"role": "user",   "content": user_text},
            ],
            "temperature": temperature,
        }
        for param in ("top_p", "frequency_penalty", "presence_penalty", "max_tokens", "stop"):
            if param in sampling_params:
                request_data[param] = sampling_params[param]
        if self._min_p_supported is not False:
            request_data["min_p"] = sampling_params.get("min_p", MIN_P_DEFAULT)

        _acquire_slot()
        response = self.call_provider(request_data)

        text = extract_text_from_response(response)
        if text is None:
            err = extract_error_from_response(response)
            raise ProviderResponseError(
                f"Malformed response from Scitely: no content found. "
                f"Error field: {err}. Keys: {list(response.keys())}"
            )
        return self._clean_response(text, system_prompt)

    # ------------------------------------------------------------------
    # Low-level HTTP (used by call_provider via base class)
    # ------------------------------------------------------------------

    def _execute_request(self, request_data: dict) -> dict:
        headers = {
            "Authorization": f"Bearer {self.api_key}",
            "Content-Type": "application/json",
        }
        try:
            response = requests.post(
                self.endpoint,
                headers=headers,
                json=request_data,
                timeout=self.timeout,
            )
        except requests.exceptions.Timeout as e:
            raise ProviderTimeoutError(f"Request timed out after {self.timeout}s: {e}") from e
        except requests.exceptions.ConnectionError as e:
            raise ProviderTemporaryError(f"Connection error: {e}") from e
        except Exception as e:
            raise ProviderError(f"Scitely network error: {e}") from e

        # Handle HTTP error codes before parsing body
        if response.status_code == 429:
            retry_after = _parse_retry_after(dict(response.headers))
            msg = f"Rate limited by Scitely (429)."
            if retry_after:
                msg += f" Retry-After: {retry_after}s."
            raise ProviderRateLimitError(msg, retry_after=retry_after)

        if response.status_code in (401, 403):
            raise ProviderAuthError(
                f"Authentication failed ({response.status_code}): {response.text[:200]}"
            )

        if response.status_code >= 500:
            raise ProviderTemporaryError(
                f"Server error ({response.status_code}): {response.text[:200]}"
            )

        if not response.ok:
            raise ProviderError(
                f"Unexpected HTTP {response.status_code}: {response.text[:200]}"
            )

        try:
            body = response.json()
        except ValueError as e:
            raise ProviderResponseError(
                f"Response body is not valid JSON. Status={response.status_code}. "
                f"Body preview: {response.text[:200]}"
            ) from e

        # Surface provider-level error payloads clearly
        err_msg = extract_error_from_response(body)
        if err_msg and "choices" not in body:
            raise ProviderResponseError(f"Provider error payload: {err_msg}")

        return body

    # ------------------------------------------------------------------
    # Hygiene
    # ------------------------------------------------------------------

    @staticmethod
    def _clean_response(content: str, system_prompt: str) -> str:
        """Strip AI reasoning blocks and markdown code fences from response."""
        content = re.sub(
            r"<think>.*?</think>", "", content, flags=re.DOTALL | re.IGNORECASE
        )
        if "json" in system_prompt.lower():
            content = re.sub(r"```(?:json)?", "", content, flags=re.IGNORECASE)
            content = content.replace("```", "").strip()
        return content.strip()
