"""
pipeline_core/providers/client.py
===================================
Base provider client with structured exception hierarchy and safe
response extraction helpers.
"""
import logging
import time
from typing import Optional


# ---------------------------------------------------------------------------
# Exception hierarchy
# ---------------------------------------------------------------------------

class ProviderError(Exception):
    """Base for all provider-related errors."""
    pass

class ProviderTimeoutError(ProviderError):
    pass

class ProviderRateLimitError(ProviderError):
    """Includes optional retry_after hint (seconds) from the Retry-After header."""
    def __init__(self, message: str, retry_after: Optional[float] = None):
        super().__init__(message)
        self.retry_after = retry_after

class ProviderAuthError(ProviderError):
    pass

class ProviderTemporaryError(ProviderError):
    pass

class ProviderResponseError(ProviderError):
    pass


# ---------------------------------------------------------------------------
# Safe response extraction helpers (module-level, importable by tests)
# ---------------------------------------------------------------------------

def extract_text_from_response(response: dict) -> Optional[str]:
    """
    Safely extract the assistant text from an OpenAI-compatible response dict.
    Returns None if the structure is absent or malformed rather than raising.
    """
    if not isinstance(response, dict):
        return None
    choices = response.get("choices")
    if not choices or not isinstance(choices, list):
        return None
    first = choices[0]
    if not isinstance(first, dict):
        return None
    message = first.get("message", {})
    if isinstance(message, dict):
        content = message.get("content")
        if content is not None:
            return content
    # Some providers put the text directly on the choice dict
    return first.get("text")


def extract_error_from_response(response: dict) -> Optional[str]:
    """
    Safely extract an error description from a provider error payload.
    Handles: {"error": {"message": "..."}}, {"error": "..."}, {"message": "..."}
    """
    if not isinstance(response, dict):
        return None
    err = response.get("error")
    if isinstance(err, dict):
        return err.get("message") or err.get("code") or str(err)
    if isinstance(err, str):
        return err
    return response.get("message")


# ---------------------------------------------------------------------------
# Base client
# ---------------------------------------------------------------------------

class AIProviderClient:
    def __init__(self, retry_policy: dict):
        self.retry_policy = retry_policy

    def call_provider(self, request_data: dict) -> dict:
        attempts = 0
        max_retries = self.retry_policy.get("max_retries", 3)

        while attempts < max_retries:
            attempts += 1
            start_time = time.time()
            try:
                response = self._execute_request(request_data)
                latency = time.time() - start_time
                logging.info(f"Attempt: {attempts}, Status: 200, Latency: {latency:.2f}s")
                return self._validate_response(response)

            except (ProviderTimeoutError, ProviderRateLimitError, ProviderTemporaryError) as e:
                latency = time.time() - start_time
                logging.warning(
                    f"Attempt: {attempts}, ErrorType: {e.__class__.__name__}, "
                    f"Latency: {latency:.2f}s. Retrying..."
                )
                if attempts >= max_retries:
                    raise ProviderError(f"Max retries ({max_retries}) exceeded: {e}") from e
                retry_after = getattr(e, "retry_after", None)
                backoff = retry_after if retry_after else (
                    self.retry_policy.get("backoff", 1) * attempts
                )
                time.sleep(backoff)

            except ProviderError:
                latency = time.time() - start_time
                logging.error(f"Fatal Provider Error, Latency: {latency:.2f}s")
                raise

            except Exception as e:
                latency = time.time() - start_time
                logging.error(f"Unexpected System Error: {e}, Latency: {latency:.2f}s")
                raise ProviderError(f"Unexpected underlying error: {e}") from e

        raise ProviderError("Execution ended without returning or throwing explicitly.")

    def _execute_request(self, request_data: dict) -> dict:
        raise NotImplementedError("Subclasses must implement _execute_request")

    def _validate_response(self, response: dict) -> dict:
        if not isinstance(response, dict):
            raise ProviderResponseError(
                f"Expected response dict, got {type(response).__name__}"
            )
        error_msg = extract_error_from_response(response)
        if error_msg and "choices" not in response and "data" not in response:
            raise ProviderResponseError(f"Provider returned error: {error_msg}")
        if "choices" not in response and "data" not in response and "status" not in response:
            raise ProviderResponseError(
                "Response missing expected keys ('choices', 'data', or 'status'). "
                f"Keys present: {list(response.keys())}"
            )
        return response
