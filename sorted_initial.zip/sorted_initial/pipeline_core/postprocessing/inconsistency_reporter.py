import re
from typing import Dict, Any, List

# Characters that look like untranslated English leaked through
_ENGLISH_WORD_PATTERN = re.compile(r'\b[a-zA-Z]{4,}\b')

# Length ratio thresholds — Hindi translations are typically 10–40% longer than English source
_MIN_LENGTH_RATIO = 0.5
_MAX_LENGTH_RATIO = 3.5


def build_inconsistency_report(
    clean_source: str,
    final_text: str,
    preprocessed_unit: Dict[str, Any],
    glossary_map: Dict[str, Any]
) -> List[str]:
    """
    Performs a multi-axis consistency check between source and final translated text.
    Returns a list of human-readable warning strings. Does NOT modify text.
    """
    if not final_text:
        return ["CRITICAL: Final text is empty after postprocessing."]

    warnings: List[str] = []
    critical_terms: List[str] = preprocessed_unit.get("critical_context", {}).get("critical_terms", [])

    # 1. Untranslated critical term leakage
    # Terms that should have been translated/transliterated but are still raw English
    for term in critical_terms:
        if not term:
            continue
        action = "translate_carefully"
        if isinstance(glossary_map.get(term), dict):
            action = glossary_map[term].get("recommended_action", "translate_carefully")

        # Only flag 'translate_carefully' terms found still in English in the final text
        if action == "translate_carefully":
            pattern = re.compile(r'\b' + re.escape(term) + r'\b', re.IGNORECASE)
            if pattern.search(final_text):
                warnings.append(
                    f"Term leakage: '{term}' appears untranslated in final output. "
                    f"Expected Hindi equivalent."
                )

    # 2. Suspicious English word density (broad leak detection)
    english_matches = _ENGLISH_WORD_PATTERN.findall(final_text)

    # Filter out preserved terms — those are allowed
    preserved_terms = set()
    for term, instruction in glossary_map.items():
        if isinstance(instruction, dict) and instruction.get("recommended_action") == "preserve":
            preserved_terms.add(term.lower())

    leaked = [w for w in english_matches if w.lower() not in preserved_terms]
    total_words = max(len(final_text.split()), 1)
    leak_ratio = len(leaked) / total_words

    if leak_ratio > 0.3:
        warnings.append(
            f"High English word density in final output ({len(leaked)} of {total_words} words). "
            f"Possible incomplete translation."
        )
    elif leak_ratio > 0.1:
        warnings.append(
            f"Moderate English word residue detected ({len(leaked)} words). Verify translation completeness."
        )

    # 3. Length mismatch
    source_len = max(len(clean_source), 1)
    output_len = len(final_text)
    ratio = output_len / source_len

    if ratio < _MIN_LENGTH_RATIO:
        warnings.append(
            f"Output is suspiciously short (ratio {ratio:.2f}x source length). "
            f"Possible truncation or incomplete translation."
        )
    elif ratio > _MAX_LENGTH_RATIO:
        warnings.append(
            f"Output is suspiciously long (ratio {ratio:.2f}x source length). "
            f"Possible repetition or hallucination."
        )

    # 4. Tone mismatch hint — detect formal tone violated by casual markers
    tone_hint = preprocessed_unit.get("critical_context", {}).get("tone_hint", "").lower()
    if "formal" in tone_hint or "archaic" in tone_hint:
        casual_pattern = re.compile(r'\b(gonna|wanna|dunno|kinda|gotta)\b', re.IGNORECASE)
        if casual_pattern.search(final_text):
            warnings.append(
                "Tone mismatch: casual language detected in formally-toned unit. "
                "Review translation register."
            )

    return warnings
