def enforce_glossary(text: str, glossary_map: dict) -> str:
    """
    Deterministically enforces glossary consistency on translated text.
    Handles both the legacy string map and the upgraded structured dict map.

    For 'preserve' action: replaces English source term still in the text (failsafe).
    For 'transliterate' / 'translate_carefully': only enforces if a non-placeholder
    suggested_rendering is available; otherwise leaves the text as-is.
    """
    if not glossary_map:
        return text

    for source_term, instruction in glossary_map.items():
        if isinstance(instruction, str):
            # Legacy identity map — only replace if the English term leaked through
            if source_term in text and instruction != source_term:
                text = text.replace(source_term, instruction)
            continue

        # Structured map
        action = instruction.get("recommended_action", "translate_carefully")
        rendering = instruction.get("suggested_rendering", source_term)

        # Only enforce 'preserve' strictly (keep source term exactly)
        if action == "preserve":
            # If source term leaked through untranslated, it's correct — leave it
            # If it was incorrectly altered, no reliable way to fix without AI — skip
            continue

        # For transliterate/translate_carefully: only enforce if rendering is a real string
        # (not a placeholder like "[Term_devanagari]" or "[Term_translated]")
        is_placeholder = rendering.startswith("[") and rendering.endswith("]")
        if is_placeholder:
            continue

        # Real rendering available — enforce consistently
        if source_term in text:
            text = text.replace(source_term, rendering)

    return text
