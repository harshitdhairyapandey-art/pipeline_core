"""
pipeline_core/postprocessing/postprocessing_assembler.py
=========================================================
Postprocessing assembler.

Responsibilities (DETERMINISTIC ONLY — no full rewrites):
  1. Cleanup rules (strip AI preamble artifacts)
  2. Glossary enforcement (deterministic find/replace)
  3. Name normalization (variant drift correction)
  4. Tone stabilization (flag violations, strip preamble)
  5. AI Actor-Critic loop (OPTIONAL — surgical edits only, not rewrites)
  6. Inconsistency reporting (QA warnings, non-blocking)

The Actor-Critic loop applies surgical fixes via the 6-pass system.
Synthesis is constrained to ~5% of text modified — if output < 80% of
input length the original polished text is returned unchanged.
"""
import json
import logging
from typing import Dict, Any, Optional, List

from .glossary_enforcer import enforce_glossary
from .cleanup_rules import apply_cleanup_rules
from .name_normalizer import normalize_names
from .tone_stabilizer import stabilize_tone
from .inconsistency_reporter import build_inconsistency_report
from .ai_critics import ActorCriticEngine

logger = logging.getLogger(__name__)


def assemble_postprocessing(
    unit:              Dict[str, Any],
    preprocessed_unit: Dict[str, Any],
    glossary_map:      Dict[str, Any],
    critics_engine:    Optional[ActorCriticEngine] = None,
    global_context:    Optional[Dict[str, Any]] = None,
) -> Dict[str, Any]:
    """
    Run all postprocessing steps for a single unit.

    Steps 1-4 are deterministic and always run.
    Step 5 (Actor-Critic) runs only when critics_engine is provided.
    Step 6 (QA report) always runs.

    Returns:
        {unit_id, final_text, warnings, metadata}
    """
    # Prefer polished_text; fall back to translated_text
    raw_text    = unit.get("polished_text") or unit.get("translated_text", "")
    clean_source = preprocessed_unit.get("clean_text", "")
    all_warnings: List[str] = []

    # ------------------------------------------------------------------
    # Step 1: Cleanup (strip AI preamble artifacts, normalize whitespace)
    # ------------------------------------------------------------------
    cleaned_text = apply_cleanup_rules(raw_text)

    # ------------------------------------------------------------------
    # Step 2: Glossary enforcement (deterministic find/replace)
    # ------------------------------------------------------------------
    enforced_text = enforce_glossary(cleaned_text, glossary_map)

    # ------------------------------------------------------------------
    # Step 3: Name normalization (correct variant drift)
    # ------------------------------------------------------------------
    normalized_text, name_warnings = normalize_names(enforced_text, glossary_map)
    all_warnings.extend(name_warnings)

    # ------------------------------------------------------------------
    # Step 4: Tone stabilization (flag violations, strip preamble)
    # ------------------------------------------------------------------
    stabilized_text, tone_warnings = stabilize_tone(normalized_text, preprocessed_unit)
    all_warnings.extend(tone_warnings)

    final_text = stabilized_text

    # ------------------------------------------------------------------
    # Step 5: AI Actor-Critic (optional — surgical, never full rewrite)
    # ------------------------------------------------------------------
    if critics_engine and global_context and clean_source:
        try:
            critic_result = critics_engine.run_full_actor_critic(
                english_text     = clean_source,
                hindi_text       = stabilized_text,
                global_context   = global_context,
                preprocessed_unit = preprocessed_unit,
            )
            if critic_result and critic_result.strip():
                final_text = critic_result
        except Exception as e:
            logger.warning(
                f"Actor-Critic failed for unit {unit.get('unit_id')} — "
                f"using stabilized text. Error: {e}"
            )
            all_warnings.append(f"Actor-Critic skipped (error): {e}")

    # ------------------------------------------------------------------
    # Step 6: Inconsistency report (QA — non-blocking)
    # ------------------------------------------------------------------
    qa_warnings = build_inconsistency_report(
        clean_source, final_text, preprocessed_unit, glossary_map
    )
    all_warnings.extend(qa_warnings)

    return {
        "unit_id":  unit.get("unit_id"),
        "final_text": final_text,
        "warnings": all_warnings,
        "metadata": unit.get("metadata", {}),
    }
