import re

def apply_cleanup_rules(text: str) -> str:
    """
    Normalizes formatting anomalies and automatically strips 
    frequent generative AI conversational prefixes natively.
    """
    artifacts = [
        "Here is the translation:", 
        "Translated text:", 
        "Translation:", 
        "Sure, here is the text:"
    ]
    
    for artifact in artifacts:
        if text.lower().startswith(artifact.lower()):
            text = text[len(artifact):].lstrip(': \n')
            
    # Normalize punctuation spacing explicitly tracking structural shapes
    text = text.replace('\r\n', '\n').replace('\r', '\n')
    text = re.sub(r'\n{3,}', '\n\n', text)
    
    # Strip any loose boundary whitespace
    lines = [line.strip() for line in text.split('\n')]
    
    return '\n'.join(lines).strip()
