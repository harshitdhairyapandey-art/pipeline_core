import re
from typing import Dict, Any, Tuple, List

# Tone-to-forbidden pattern mapping
# Each entry is (tone_keyword, forbidden_pattern, suggested_fix_description)
_TONE_CONSTRAINTS = [
    # Formal/archaic tones must not contain casual contractions
    ("formal",    re.compile(r"\b(gonna|wanna|dunno|kinda|gotta|y'know|cya)\b", re.IGNORECASE),
     "Casual contraction found in formal context."),
    ("archaic",   re.compile(r"\b(gonna|wanna|dunno|kinda|gotta|y'know|cya)\b", re.IGNORECASE),
     "Casual contraction found in archaic context."),
    # Ritualistic tones must not contain slang
    ("ritualistic", re.compile(r"\b(dude|bro|sis|lol|omg|wtf|nah|yeah|yep)\b", re.IGNORECASE),
     "Slang detected in ritualistic context."),
    # Intimate tone must not have hostile markers
    ("intimate",  re.compile(r"\b(enemy|traitor|coward|villain|fool|idiot|kill)\b", re.IGNORECASE),
     "Hostile language detected in intimate context."),
]

# Cleanup: strip common AI-artifact preamble phrases that slip through polishing
_AI_PREAMBLE = re.compile(
    r'^(sure[,!]?\s*|of course[,!]?\s*|here(?:\'s| is)(?: the)?(?: translation)?[:\s]*|'
    r'certainly[,!]?\s*|as requested[,!]?\s*)',
    re.IGNORECASE
)


def stabilize_tone(text: str, preprocessed_unit: Dict[str, Any]) -> Tuple[str, List[str]]:
    """
    Applies conservative deterministic tone fixes based on the preprocessed unit's
    tone_hint and voice_context. Returns (stabilized_text, warnings).
    Does NOT rewrite sentences — only flags violations and strips AI artifacts.
    """
    if not text:
        return text, []

    warnings: List[str] = []
    stabilized = text

    # 1. Strip AI preamble artifacts that slipped through cleanup/polishing
    stripped = _AI_PREAMBLE.sub("", stabilized).strip()
    if stripped != stabilized:
        warnings.append("AI preamble artifact removed during tone stabilization.")
        stabilized = stripped

    # 2. Resolve tone hint from preprocessed unit
    tone_hint = (
        preprocessed_unit.get("critical_context", {}).get("tone_hint", "") or
        preprocessed_unit.get("analysis", {}).get("tone", "")
    ).lower()

    # 3. Check voice context for dominant style
    voice_style = (
        preprocessed_unit
        .get("helpful_context", {})
        .get("voice_context", {})
        .get("voice_profile", [{}])[0]
        .get("voice_style", "")
        .lower()
    )

    active_tone = tone_hint or voice_style

    # 4. Apply tone constraint checks (report only — do not auto-rewrite)
    for tone_keyword, pattern, description in _TONE_CONSTRAINTS:
        if tone_keyword in active_tone:
            matches = pattern.findall(stabilized)
            if matches:
                warnings.append(
                    f"Tone violation — {description} "
                    f"Offending term(s): {', '.join(set(matches))}. "
                    f"Manual review recommended."
                )

    return stabilized, warnings
