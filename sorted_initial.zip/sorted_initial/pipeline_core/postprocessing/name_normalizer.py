import re
from typing import Dict, Any, Tuple, List


def normalize_names(text: str, glossary_map: Dict[str, Any]) -> Tuple[str, List[str]]:
    """
    Detects and corrects simple variant drift for terms with 'preserve' or 'transliterate'
    recommended_action. Conservative: only acts when a suggested_rendering is a real non-placeholder
    string. Returns (normalized_text, warnings).
    """
    if not glossary_map or not text:
        return text, []

    warnings: List[str] = []
    normalized = text

    for source_term, instruction in glossary_map.items():
        if isinstance(instruction, str):
            continue  # Legacy map — skip, enforcer handles this

        action = instruction.get("recommended_action", "translate_carefully")
        rendering = instruction.get("suggested_rendering", source_term)
        is_placeholder = rendering.startswith("[") and rendering.endswith("]")

        # Only act on preserve/transliterate terms with real renderings
        if action not in ("preserve", "transliterate") or is_placeholder:
            continue

        # Build a case-insensitive variant detector for common drift patterns
        # e.g. "Arjun" drifting to "Arjuna", "Arjun's" mangled to plain variants
        pattern = re.compile(
            r'\b' + re.escape(source_term) + r'(a|e|i|o|u|\'s|s\b)?\b',
            re.IGNORECASE
        )

        def _replace_variant(match: re.Match) -> str:
            full_match = match.group(0)
            suffix = match.group(1) or ""
            # If the suffix indicates possessive or plural, keep it
            if suffix in ("'s", "s"):
                return rendering + suffix
            # Drift variant detected — normalize to canonical form
            if full_match.rstrip("aeiou") != rendering.rstrip("aeiou") or full_match != rendering:
                return rendering
            return full_match

        new_text, count = pattern.subn(_replace_variant, normalized)

        if count > 0 and new_text != normalized:
            warnings.append(
                f"Name normalization: '{source_term}' variant corrected to '{rendering}' "
                f"({count} occurrence(s))."
            )
            normalized = new_text

    return normalized, warnings
