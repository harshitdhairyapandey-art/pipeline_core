def check_consistency(clean_source: str, translated_text: str, critical_terms: list) -> list:
    """
    Detects repeated inconsistencies or naming drift by comparing source terms 
    to output lengths and missing contextual phrases natively.
    """
    warnings = []
    
    # Heuristic 1: Critical source noun left totally untranslated
    for term in critical_terms:
        if term in clean_source and term in translated_text:
            warnings.append(f"Possible un-localized critical term detected natively in output: '{term}'")
            
    # Heuristic 2: Extreme length discrepancy indicating truncation or hallucination
    source_len = len(clean_source)
    trans_len = len(translated_text)
    
    if source_len > 10:
        if trans_len < source_len * 0.2:
            warnings.append("Translation length suspiciously short (possible truncation or missing sentences).")
        elif trans_len > source_len * 3.5:
            warnings.append("Translation length suspiciously long (possible hallucination or duplicate loops).")
        
    return warnings
