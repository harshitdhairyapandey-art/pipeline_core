"""
pipeline_core/postprocessing/ai_critics.py
============================================
Migrated from AyzerLexiFlow LexiFlow_v2/postprocessing.py (run_all_passes).
Full 6-pass Actor-Critic system with:
  - Pass1: Lexical Editor
  - Pass2: Prose Architect
  - Pass3: Literary Voice Editor
  - Pass4: Sensory Editor (action/horror only)
  - Pass5: Terminology & Tier Enforcer
  - Pass6: Grammar & Case Editor
  - Synthesis: Master Editor applying all critiques
  - CPU Fixes: nuqta corrections, grammar fixes, glossary enforcement
"""

import re
import json
from typing import List, Dict, Any, Optional, Tuple
from ..providers.scitely_provider import ScitelyProvider
from ..runtime.concurrent_executor import execute_concurrently

# =============================================================================
# CRITIQUE PROMPTS (migrated verbatim from LexiFlow postprocessing.py)
# =============================================================================

PASS1_SYSTEM = """You are a Hindi Lexical Editor working on a literary fantasy translation.
Read the English original and the Hindi draft.
Identify weak verbs, flat vocabulary, or missed literary opportunities.
Enforce the 70/30 Density Rule: if a sentence stacks too many heavy words/metaphors, critique it to be simplified into transparent, readable Hindi.
Return a JSON array of specific critiques.

Example:
[
  {"quote": "उसका माना कम हो गया", "issue": "unnecessary English transliteration", "suggestion": "change to 'उसकी जादुई शक्ति कम हो गई'"},
  {"quote": "ठंडी विदेशी बुद्धिमत्ता", "issue": "awkward literal translation of 'alien'", "suggestion": "use 'अजनबी' or 'पराई'"},
  {"quote": "हड्डियों में धड़क रहा", "issue": "Literal translation of English body idiom", "suggestion": "Use 'नसों में' or 'भीतर कहीं'"}
]
Rules: Max 5 critiques per chapter. Return raw JSON only."""

PASS2_SYSTEM = """You are a Hindi Prose Architect.
Critique sentence length, pacing, and rhythm based on the English source.
- Action scenes: sentences should be short and active.
- Emotional scenes: give sentences breathing room.
- Check for English syntax bleeding (S-V-O word order). Enforce native Hindi rhythm (S-O-V).
- Make technical exposition flow naturally, avoiding robotic system-like readouts.
Example:
[
  {"quote": "माना रेटिंग कम से कम 0.4", "issue": "reads like raw system output", "suggestion": "smooth into 'जादुई तीव्रता कम से कम 0.4 स्तर की होनी चाहिए'"}
]
Rules: Max 5 critiques per chapter. Return raw JSON only."""

PASS3_SYSTEM = """You are a Hindi Literary Voice Editor.
Find narrative voice markers from the English original that got flattened in the Hindi draft (e.g., em-dashes, sardonic intensifiers, hedging qualifiers).
Example:
[
  {"quote": "यह अक्षमता है", "issue": "lost sardonic tone of 'very diplomatic'", "suggestion": "make it sound colder and more sarcastic"}
]
Rules: Max 4 critiques. Return raw JSON only."""

PASS4_SYSTEM = """You are a Hindi Sensory Editor.
This applies mainly to action/horror scenes. Ensure sensory rotation (visual, auditory, tactile).
Example:
[
  {"quote": "छाया लंबी हो गई", "issue": "consecutive visual descriptions", "suggestion": "add an auditory detail"}
]
Rules: Max 3 critiques. Return raw JSON only."""

PASS5_SYSTEM = """You are a strict Terminology & Tier System Enforcer.
Your PRIMARY job is to ensure the draft uses the EXACT Devanagari terms from the Locked Glossary.
For generic terms NOT in the glossary, follow the 3-Tier rule:
1. Core Lore: Keep English transliteration.
2. General/Technical Concepts: MUST translate to pure Hindi.

If an English term is present in the source, its exact Devanagari MUST be in the draft.
If the draft used a synonym, left it in English, used a WRONG Hindi transliteration, or failed to translate a generic tier word, flag it.

Example:
[
  {"quote": "एक शूरवीर के रूप में", "issue": "Used 'शूरवीर' for 'Knight'", "suggestion": "Change 'शूरवीर' to locked term 'नाईट'"},
  {"quote": "आर्थुर ने कहा", "issue": "Wrong transliteration", "suggestion": "Change 'आर्थुर' to 'आर्थर'"}
]
Rules: Max 10 critiques per chapter. Return raw JSON only."""

PASS6_SYSTEM = """You are a strict Hindi Grammar, Case, and Pronoun Editor.
Check the draft for case agreement errors (missing or incorrect use of ने, को, से, का/के/की that distorts the subject/object relationship).
Check for tense inconsistencies (randomly shifting between past and present).
Check pronoun consistency (तू, तुम, आप) based on character relationships.
Check for UNTRANSLATED English phrases (like incantations or system commands) written in Devanagari script, and order their translation.
Hunt for ANY UTF-8 encoding glitches or replacement characters and explicitly reconstruct the broken word based on context.

Example:
[
  {"quote": "महल का रक्षक नहीं देखा", "issue": "missing 'ने' postposition for past tense transitive", "suggestion": "change to 'महल के रक्षक ने नहीं देखा'"},
  {"quote": "वह जाता है और उसने कहा", "issue": "tense inconsistency", "suggestion": "make both past tense"},
  {"quote": "तुम कैसे हो... आप क्या कर रहे हैं", "issue": "pronoun register shift", "suggestion": "unify to 'तुम' or 'आप' consistently"}
]
Rules: Max 5 critiques per chapter. Return raw JSON only."""

SYNTHESIS_SYSTEM = """You are a precise Master Synthesis Editor.
You are given an English original, a high-quality Hindi draft, and a JSON list of editorial critiques.
Your job is to SURGICALLY apply the specific critiques to the draft.

CRITICAL RULES:
1. DO NOT rewrite the entire text. You must preserve 95% of the draft EXACTLY as it is.
2. ONLY modify the specific sentences targeted by the JSON critiques to fix their issues.
3. ENCODING REPAIR: If you see broken Devanagari characters or floating matras, seamlessly repair the word based on surrounding context.
4. TERMINOLOGY LOCK: You MUST use the exact Devanagari spelling for all terms in the glossary.
5. WEAVING: Ensure that locked English transliterated terms feel naturally woven into the surrounding Hindi prose, not abruptly dropped in.
6. Maintain the original paragraph breaks perfectly. Do not merge or split paragraphs.

Return the final Hindi text ONLY. No commentary."""

SYNTHESIS_USER = """GLOSSARY (Strict Devanagari Enforcement):
{glossary_block}

VOLUME TONE & ARC:
{volume_context}

CHAPTER EMOTIONAL TIMELINE:
{emotion_timeline}

EDITORIAL CRITIQUES TO APPLY:
{critiques_json}

ENGLISH ORIGINAL:
{english_text}

HINDI DRAFT:
{hindi_draft}

Surgically update the draft by applying the critiques. Preserve the rest of the text exactly as written."""

# =============================================================================
# CPU FIXES (migrated from LexiFlow postprocessing.py)
# =============================================================================

PASS5_NUQTA = {
    "कदम":    "क़दम",
    "खामोशी": "ख़ामोशी",
    "गलत":    "ग़लत",
    "जमीन":   "ज़मीन",
    "फर्क":   "फ़र्क़",
    "कैद":    "क़ैद",
    "खयाल":   "ख़याल",
    "जिंदगी": "ज़िंदगी",
    "खून":    "ख़ून",
    "खतरा":   "ख़तरा",
    "खबर":    "ख़बर",
    "फैसला":  "फ़ैसला",
    "काफी":   "काफ़ी",
    "साफ":    "साफ़",
}

CPU_GRAMMAR_FIXES = {
    "नीचे का शहर ने": "नीचे शहर ने",
    "नीचे के शहर ने": "नीचे शहर ने",
    "क्रिया अनुक्रम": "संघर्ष",
    "दार्शनिक आंतरिक एकाकी विचार": "आंतरिक चिंतन",
}


def apply_cpu_nuqta_fix(text: str) -> str:
    for wrong, correct in PASS5_NUQTA.items():
        text = text.replace(wrong, correct)
    return text


def apply_cpu_grammar_fix(text: str) -> str:
    for wrong, correct in CPU_GRAMMAR_FIXES.items():
        text = text.replace(wrong, correct)
    return text


def apply_cpu_glossary_fix(text: str, glossary: list) -> str:
    """Force replace any stray English words that match the glossary."""
    if not glossary:
        return text
    sorted_glossary = sorted(glossary, key=lambda x: len(x.get("term", "").strip()), reverse=True)
    for entry in sorted_glossary:
        eng = entry.get("term", "").strip()
        deva = entry.get("devanagari", "").strip()
        if eng and deva:
            text = re.sub(r'\b' + re.escape(eng) + r'\b', deva, text, flags=re.IGNORECASE)
    return text


def _format_glossary(glossary_map: dict) -> str:
    if not glossary_map:
        return ""
    lines = ["LOCKED TERMS (use exact Devanagari, no variation):"]
    for term, instruction in glossary_map.items():
        if isinstance(instruction, dict):
            deva = instruction.get("devanagari") or instruction.get("suggested_rendering", "")
        else:
            deva = instruction
        if term and deva and not deva.startswith("["):
            lines.append(f"  {term} → {deva}")
    return "\n".join(lines)


# =============================================================================
# ACTOR-CRITIC ENGINE
# =============================================================================

class ActorCriticEngine:
    def __init__(self, provider: ScitelyProvider):
        self.provider = provider

    def run_critics(
        self,
        english_text: str,
        hindi_text: str,
        context_block: str,
        scene_type: str = "narration",
        emotion_timeline: str = "",
        glossary_block: str = ""
    ) -> Dict[str, Any]:
        """
        Runs parallel AI critics — migrated from LexiFlow run_all_passes().
        Uses all 6 passes (Pass4 only for action/horror scenes).
        """
        user_prompt = (
            f"SCENE TYPE: {scene_type}\n"
            f"EMOTIONAL TIMELINE: {emotion_timeline}\n\n"
            f"ENGLISH ORIGINAL:\n{english_text[:8000]}\n\n"
            f"HINDI DRAFT:\n{hindi_text[:12000]}"
        )

        tasks = [
            ("lexical",      PASS1_SYSTEM),
            ("architecture", PASS2_SYSTEM),
            ("voice",        PASS3_SYSTEM),
            ("terminology",  PASS5_SYSTEM + f"\n\nLOCKED GLOSSARY:\n{glossary_block}"),
            ("grammar",      PASS6_SYSTEM),
        ]
        if scene_type in ("action", "horror", "investigation", "climax"):
            tasks.append(("sensory", PASS4_SYSTEM))

        def _run_critic(item: Tuple[str, str]) -> Tuple[bool, Any]:
            name, system_prompt = item
            try:
                res = self.provider.call_json(system_prompt, user_prompt, temperature=0.2)
                # call_json returns dict or list; wrap list in dict
                if isinstance(res, list):
                    return True, {"name": name, "critiques": res}
                return True, {"name": name, "critiques": res if isinstance(res, list) else []}
            except Exception:
                return True, {"name": name, "critiques": []}

        success, results = execute_concurrently(tasks, _run_critic, max_workers=6)

        master_critique = {}
        if success:
            for r in results:
                master_critique[r["name"]] = r["critiques"]
        return master_critique

    def synthesize(
        self,
        english_text: str,
        hindi_text: str,
        critiques: Dict[str, Any],
        glossary_block: str = "",
        volume_context: str = "",
        emotion_timeline: str = ""
    ) -> str:
        """
        Surgically applies critiques to the Hindi draft.
        Falls back to original hindi_text if synthesis truncates output.
        """
        user_input = SYNTHESIS_USER.format(
            glossary_block=glossary_block,
            volume_context=volume_context,
            emotion_timeline=emotion_timeline,
            critiques_json=json.dumps(critiques, ensure_ascii=False, indent=2),
            english_text=english_text[:8000],
            hindi_draft=hindi_text[:12000],
        )

        result = self.provider.call_ai(SYNTHESIS_SYSTEM, user_input, temperature=0.4)

        if result and result.strip():
            # Guard against synthesis truncation (< 80% of input length)
            if len(result) < len(hindi_text) * 0.8:
                return hindi_text  # fall back to polished draft
            return result
        return hindi_text

    def run_full_actor_critic(
        self,
        english_text: str,
        hindi_text: str,
        global_context: Dict[str, Any],
        preprocessed_unit: Dict[str, Any],
    ) -> str:
        """
        Full pipeline: critics → synthesis → CPU fixes.
        Migrated from LexiFlow run_all_passes().
        """
        # Build context strings
        scene_type = preprocessed_unit.get("analysis", {}).get("scene_type", "narration")
        emotion_list = preprocessed_unit.get("critical_context", {}).get("tone_hint", "")
        glossary_block = _format_glossary(global_context.get("glossary_map", {}))
        volume_context = (
            f"Tone: {global_context.get('global_tone', 'N/A')} | "
            f"Arc: {global_context.get('volume_flow', {}).get('dominant_arc', 'N/A')}"
        )

        # Stage A: parallel critics
        critiques = self.run_critics(
            english_text=english_text,
            hindi_text=hindi_text,
            context_block=volume_context,
            scene_type=scene_type,
            emotion_timeline=str(emotion_list),
            glossary_block=glossary_block,
        )

        # Stage B: synthesis
        if critiques:
            final_text = self.synthesize(
                english_text=english_text,
                hindi_text=hindi_text,
                critiques=critiques,
                glossary_block=glossary_block,
                volume_context=volume_context,
                emotion_timeline=str(emotion_list),
            )
        else:
            final_text = hindi_text

        # Stage C: CPU fixes
        final_text = apply_cpu_nuqta_fix(final_text)
        final_text = apply_cpu_grammar_fix(final_text)

        # Build glossary list for cpu_glossary_fix
        glossary_list = []
        for term, instruction in global_context.get("glossary_map", {}).items():
            if isinstance(instruction, dict):
                deva = instruction.get("devanagari") or instruction.get("suggested_rendering", "")
            else:
                deva = instruction
            if deva and not deva.startswith("["):
                glossary_list.append({"term": term, "devanagari": deva})

        final_text = apply_cpu_glossary_fix(final_text, glossary_list)

        return final_text
