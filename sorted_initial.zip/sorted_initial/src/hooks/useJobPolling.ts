import { useState, useEffect } from 'react';
import { ProjectAPI } from '@/lib/api/projects';
import type { JobProgressResponse } from '@/lib/types';

export function useJobPolling(projectId: string, isPollingEnabled: boolean) {
  const [jobState, setJobState] = useState<JobProgressResponse | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [consecutiveFailures, setConsecutiveFailures] = useState(0);

  useEffect(() => {
    if (!projectId || !isPollingEnabled) return;
    const poll = async () => {
      try {
        const data = await ProjectAPI.getJobStatus(projectId);
        setJobState(data);
        setConsecutiveFailures(0);
        if (data.status === 'failed') setError(data.error || 'The translation was interrupted by the backend.');
      } catch (err: any) {
        setConsecutiveFailures(prev => prev + 1);
        if (consecutiveFailures >= 2) setError('Network instability detected. Attempting to recover connection...');
      }
    };
    poll();
    const interval = setInterval(() => { if (jobState?.status !== 'completed' && jobState?.status !== 'failed') poll(); }, 3000);
    return () => clearInterval(interval);
  }, [projectId, isPollingEnabled, jobState?.status, consecutiveFailures]);

  return { jobState, error, isRecovering: consecutiveFailures > 0 && consecutiveFailures < 3 };
}
