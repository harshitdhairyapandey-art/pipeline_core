export type JobStatus = 'idle' | 'processing' | 'completed' | 'failed';

export interface Project {
  id: string;
  fileName: string;
  sourceLang: string;
  targetLang: string;
  format: string;
  mode: string;
  status: JobStatus;
  progress: number;
  currentStage: string;
  createdAt: number;
  updatedAt: number;
}

export interface JobProgressResponse {
  status: JobStatus;
  progress: number;
  currentStage: string;
  currentChapter: number;
  totalChapters: number;
  error?: string;
}

export interface ResultContent {
  chapters: { id: number; title: string; content: string }[];
  metadata: { wordCount: number; completedAt: number; };
}
