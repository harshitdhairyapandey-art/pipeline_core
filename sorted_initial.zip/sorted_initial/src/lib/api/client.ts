export class ApiError extends Error {
  constructor(public status: number, message: string) { super(message); this.name = 'ApiError'; }
}
export async function apiClient<T>(endpoint: string, options: RequestInit = {}): Promise<T> {
  const apiKey = typeof window !== 'undefined' ? localStorage.getItem('katha_api_key') : null;
  const headers: HeadersInit = { 'Content-Type': 'application/json', ...(apiKey && { Authorization: `Bearer ${apiKey}` }), ...options.headers };
  const controller = new AbortController();
  const timeoutId = setTimeout(() => controller.abort(), 10000);
  try {
    const response = await fetch(`${process.env.NEXT_PUBLIC_API_URL || 'http://localhost:8000/api'}${endpoint}`, { ...options, headers, signal: controller.signal });
    clearTimeout(timeoutId);
    if (!response.ok) {
      if (response.status === 401) throw new ApiError(401, 'Invalid or missing API Key. Please check your Settings.');
      const errorData = await response.json().catch(() => ({}));
      throw new ApiError(response.status, errorData.message || 'The server encountered an unexpected error.');
    }
    return await response.json();
  } catch (error: any) {
    clearTimeout(timeoutId);
    if (error.name === 'AbortError') throw new ApiError(408, 'The request timed out. Please check your connection.');
    throw error;
  }
}
