import { apiClient } from './client';
import type { Project, JobProgressResponse, ResultContent } from '../types';

export const ProjectAPI = {
  uploadFile: async (file: File): Promise<{ projectId: string }> => {
    const formData = new FormData();
    formData.append('file', file);
    const apiKey = localStorage.getItem('katha_api_key');
    const response = await fetch(`${process.env.NEXT_PUBLIC_API_URL || 'http://localhost:8000/api'}/projects/upload`, {
      method: 'POST',
      headers: { ...(apiKey && { Authorization: `Bearer ${apiKey}` }) },
      body: formData,
    });
    if (!response.ok) throw new Error('File upload failed.');
    return response.json();
  },
  startTranslation: async (projectId: string, config: Partial<Project>): Promise<Project> => {
    return apiClient<Project>(`/projects/${projectId}/start`, { method: 'POST', body: JSON.stringify(config) });
  },
  getJobStatus: async (projectId: string): Promise<JobProgressResponse> => {
    return apiClient<JobProgressResponse>(`/projects/${projectId}/status`);
  },
  getResult: async (projectId: string): Promise<ResultContent> => {
    return apiClient<ResultContent>(`/projects/${projectId}/result`);
  },
  getAllProjects: async (): Promise<Project[]> => {
    return apiClient<Project[]>('/projects');
  }
};
