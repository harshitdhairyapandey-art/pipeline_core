/**
 * Lightweight Event Tracker (Phase 7)
 * Safe stub for beta launch. Replace console.log with PostHog, Vercel Analytics, or Plausible later.
 */
export const trackEvent = (eventName: string, metadata: Record<string, any> = {}) => {
  if (process.env.NODE_ENV !== 'production') {
    console.log(`[Analytics Stub] ${eventName}`, metadata);
  }
  // TODO: Inject real analytics provider here
};
