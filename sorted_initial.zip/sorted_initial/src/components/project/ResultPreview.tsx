'use client';

import { useState, useEffect } from 'react';
import { Button } from '@/components/ui/Button';
import { Download, CheckCircle2, Loader2, GitCompare, AlignLeft } from 'lucide-react';
import { trackEvent } from '@/lib/analytics';
import { ProjectAPI } from '@/lib/api/projects';
import type { ResultContent } from '@/lib/types';
import { Skeleton } from '@/components/ui/Skeleton';

type ExportState = 'idle' | 'exporting' | 'success' | 'error';

export function ResultPreview({ projectId }: { projectId: string }) {
  const [result, setResult] = useState<ResultContent | null>(null);
  const [exportState, setExportState] = useState<ExportState>('idle');

  useEffect(() => {
    trackEvent('Preview Opened', { projectId });
    ProjectAPI.getResult(projectId).then(setResult).catch(console.error);
  }, [projectId]);

  const handleExport = async () => {
    setExportState('exporting');
    trackEvent('Export Started', { projectId });
    
    // Simulate export generation delay for psychological confidence
    setTimeout(() => {
      setExportState('success');
      trackEvent('Export Completed', { projectId });
      
      // Revert button state gracefully after a few seconds
      setTimeout(() => setExportState('idle'), 4000);
    }, 1500);
  };

  if (!result) return <Skeleton type="full-page" />;

  return (
    <div className="animate-in fade-in duration-700 h-[calc(100vh-5rem)] flex flex-col">
      {/* Topbar */}
      <div className="flex items-center justify-between pb-4 border-b border-[#27272a]/50 mb-6 shrink-0">
        <div>
          <h2 className="text-xl font-semibold text-[#ededed] tracking-tight">Translated Manuscript</h2>
          <p className="text-sm text-[#71717a]">Status: Finalized • {result.metadata.wordCount.toLocaleString()} words</p>
        </div>
        <div className="flex gap-3">
          <Button variant="outline"><GitCompare size={16} /> Compare</Button>
          
          <Button 
            onClick={handleExport}
            disabled={exportState === 'exporting'}
            className={`min-w-[140px] transition-all duration-300 ${
              exportState === 'success' ? 'bg-emerald-500/10 text-emerald-500 border-emerald-500/20' : ''
            }`}
          >
            {exportState === 'idle' && <><Download size={16} /> Export Output</>}
            {exportState === 'exporting' && <><Loader2 size={16} className="animate-spin" /> Preparing...</>}
            {exportState === 'success' && <><CheckCircle2 size={16} /> Downloaded</>}
          </Button>
        </div>
      </div>

      {/* Workspace */}
      <div className="flex-1 flex gap-8 min-h-0">
        <div className="w-64 border-r border-[#27272a]/50 pr-4 hidden md:block">
           <h3 className="text-xs font-semibold uppercase tracking-wider text-[#71717a] mb-4 flex items-center gap-2"><AlignLeft size={14} /> Chapters</h3>
           <div className="p-2.5 bg-[#1a1a1c] text-[#ededed] text-sm rounded-lg border border-[#27272a] cursor-default">
             {result.chapters[0]?.title || 'Chapter 1'}
           </div>
        </div>
        <div className="flex-1 overflow-y-auto pb-20 pr-4 custom-scrollbar">
          <div className="max-w-2xl mx-auto pt-4">
            <h1 className="text-3xl font-serif font-medium text-[#ededed] mb-12 tracking-wide">
              {result.chapters[0]?.title || 'Chapter 1'}
            </h1>
            <div className="prose prose-invert max-w-none text-lg leading-relaxed text-[#d4d4d8] font-serif tracking-wide whitespace-pre-wrap">
              {result.chapters[0]?.content}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
