import { AlertCircle } from 'lucide-react';
export function AlertPanel({ message, actionText, onAction }: { message: string, actionText?: string, onAction?: () => void }) {
  return (
    <div className="p-6 border border-red-900/50 bg-red-950/10 rounded-xl flex flex-col items-center text-center max-w-md mx-auto mt-10">
      <AlertCircle className="text-red-500 mb-4" size={32} />
      <p className="text-[#ededed] text-sm mb-6">{message}</p>
      {actionText && onAction && (
        <button onClick={onAction} className="px-4 py-2 bg-[#27272a] hover:bg-[#3f3f46] text-[#ededed] rounded-lg text-sm transition-colors">
          {actionText}
        </button>
      )}
    </div>
  );
}
