import React from 'react';
import { LucideIcon } from 'lucide-react';
import { Button } from './Button';

interface EmptyStateProps {
  icon: LucideIcon;
  title: string;
  description: string;
  actionText?: string;
  onAction?: () => void;
}

export function EmptyState({ icon: Icon, title, description, actionText, onAction }: EmptyStateProps) {
  return (
    <div className="flex flex-col items-center justify-center text-center max-w-md mx-auto mt-20 p-8 rounded-2xl border border-[#27272a]/50 bg-[#121214]/30">
      <div className="h-16 w-16 rounded-2xl bg-[#1a1a1c] border border-[#27272a] flex items-center justify-center mb-6 shadow-sm">
        <Icon className="text-[#71717a]" size={28} strokeWidth={1.5} />
      </div>
      <h3 className="text-lg font-medium text-[#ededed] mb-2 tracking-tight">{title}</h3>
      <p className="text-[#a1a1aa] text-sm mb-8 leading-relaxed">{description}</p>
      {actionText && onAction && (
        <Button onClick={onAction} className="shadow-md">{actionText}</Button>
      )}
    </div>
  );
}
