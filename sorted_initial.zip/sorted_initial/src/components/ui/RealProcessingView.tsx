'use client';

import { useEffect, useState } from 'react';
import { ProjectAPI } from '@/lib/api/projects';
import type { JobProgressResponse } from '@/lib/types';
import { Card } from '@/components/ui/Card';
import { AlertCircle, Loader2 } from 'lucide-react';
import { useRouter } from 'next/navigation';

export function RealProcessingView({ projectId }: { projectId: string }) {
  const router = useRouter();
  const [jobState, setJobState] = useState<JobProgressResponse | null>(null);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    if (!projectId) return;
    const pollBackend = async () => {
      try {
        const data = await ProjectAPI.getJobStatus(projectId);
        setJobState(data);
        if (data.status === 'completed') router.push(`/project/${projectId}/preview`);
        else if (data.status === 'failed') setError(data.error || 'The translation was interrupted.');
      } catch (err: any) {
        console.warn('Polling skipped this cycle due to network error.');
      }
    };
    pollBackend();
    const interval = setInterval(() => {
      if (jobState?.status !== 'completed' && jobState?.status !== 'failed') pollBackend();
    }, 3000);
    return () => clearInterval(interval);
  }, [projectId, router, jobState?.status]);

  if (error) {
    return (
      <Card className="p-8 border-red-900/50 bg-red-950/10 flex flex-col items-center text-center">
        <AlertCircle className="text-red-500 mb-4" size={32} />
        <h3 className="text-[#ededed] font-medium mb-2">Translation Interrupted</h3>
        <p className="text-[#a1a1aa] text-sm mb-6">{error}</p>
        <button onClick={() => setError(null)} className="px-4 py-2 bg-[#27272a] hover:bg-[#3f3f46] rounded-lg text-sm transition-colors">
          Attempt Resume
        </button>
      </Card>
    );
  }

  return (
    <Card className="p-10 flex flex-col items-center">
      <h3 className="text-3xl font-light mb-2">{jobState?.progress || 0}%</h3>
      <div className="flex items-center gap-2 text-[#c2734a] text-sm mb-8">
        <Loader2 className="animate-spin" size={14} />
        {jobState?.currentStage || 'Initializing pipeline'}...
      </div>
      <div className="w-full max-w-md h-2 bg-[#1a1a1c] rounded-full overflow-hidden">
         <div className="h-full bg-[#c2734a] transition-all duration-500 ease-out" style={{ width: `${jobState?.progress || 0}%` }} />
      </div>
    </Card>
  );
}
