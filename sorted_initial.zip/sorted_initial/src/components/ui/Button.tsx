import React from 'react';

interface ButtonProps extends React.ButtonHTMLAttributes<HTMLButtonElement> {
  variant?: 'primary' | 'secondary' | 'outline';
}

export function Button({ children, variant = 'primary', className = '', ...props }: ButtonProps) {
  const baseStyle = "px-4 py-2 rounded-lg text-sm font-medium transition-all duration-200 focus:outline-none disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center gap-2";
  
  const variants = {
    // Updated to the new warm gold hex codes
    primary: "bg-[#D4A373] text-[#181614] hover:bg-[#B88655] shadow-sm",
    secondary: "bg-[#221F1D] text-[#F5EBE0] border border-[#36312D] hover:bg-[#2C2825]",
    outline: "border border-[#36312D] text-[#F5EBE0] hover:bg-[#221F1D]"
  };

  return (
    <button className={`${baseStyle} ${variants[variant]} ${className}`} {...props}>
      {children}
    </button>
  );
}
