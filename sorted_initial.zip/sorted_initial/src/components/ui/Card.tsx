import React from 'react';

interface CardProps extends React.HTMLAttributes<HTMLDivElement> {
  children: React.ReactNode;
  className?: string;
}

export function Card({ children, className = '', ...props }: CardProps) {
  return (
    <div className={`bg-[#121214] border border-[#27272a] rounded-xl p-6 shadow-lg ${className}`} {...props}>
      {children}
    </div>
  );
}
