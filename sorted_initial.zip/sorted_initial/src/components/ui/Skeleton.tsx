export function Skeleton({ type = 'card' }: { type?: 'card' | 'text' | 'full-page' }) {
  if (type === 'full-page') return (
    <div className="animate-pulse flex flex-col items-center justify-center h-[50vh] space-y-4">
      <div className="w-12 h-12 bg-[#27272a] rounded-full"></div>
      <div className="w-48 h-4 bg-[#27272a] rounded"></div>
    </div>
  );
  return <div className={`animate-pulse bg-[#27272a] rounded ${type === 'card' ? 'h-32 w-full' : 'h-4 w-3/4'}`}></div>;
}
