'use client';

import { useState, useEffect } from 'react';
import { PageHeader } from '@/components/layout/PageHeader';
import { Card } from '@/components/ui/Card';
import { Button } from '@/components/ui/Button';
import { Key, Save, Eye, EyeOff, CheckCircle2 } from 'lucide-react';
import { trackEvent } from '@/lib/analytics';

export default function SettingsPage() {
  const [apiKey, setApiKey] = useState('');
  const [showKey, setShowKey] = useState(false);
  const [isSaved, setIsSaved] = useState(false);
  const [isMounted, setIsMounted] = useState(false);

  useEffect(() => {
    const saved = localStorage.getItem('katha_api_key');
    if (saved) {
      setApiKey(saved);
      setIsSaved(true);
    }
    setIsMounted(true);
  }, []);

  const handleSave = () => {
    if (!apiKey.trim()) return;
    localStorage.setItem('katha_api_key', apiKey.trim());
    setIsSaved(true);
    trackEvent('Settings Saved', { hasApiKey: true });
    
    // Reset success state after 3 seconds for UX polish
    setTimeout(() => setIsSaved(false), 3000);
  };

  if (!isMounted) return null;

  return (
    <div className="animate-in fade-in duration-500 max-w-2xl">
      <PageHeader 
        title="Configuration" 
        description="Connect your translation pipeline and manage local preferences."
      />

      <div className="space-y-8">
        <section>
          <div className="mb-4">
            <h3 className="text-sm font-medium flex items-center gap-2 text-[#ededed]">
              <Key size={16} className="text-[#c2734a]" /> 
              Pipeline Access
            </h3>
            <p className="text-xs text-[#71717a] mt-1">
              Required to authenticate jobs with the Sangam backend.
            </p>
          </div>
          
          <Card className="border-[#27272a]/80">
            <div className="flex gap-3">
              <div className="relative flex-1">
                <input 
                  type={showKey ? "text" : "password"} 
                  value={apiKey} 
                  onChange={(e) => {
                    setApiKey(e.target.value);
                    if (isSaved) setIsSaved(false);
                  }}
                  placeholder="Enter your API key (sk-...)" 
                  className="w-full bg-[#0a0a0b] border border-[#27272a] rounded-lg px-4 py-2.5 text-sm text-[#ededed] focus:border-[#c2734a] focus:outline-none pr-10 transition-colors"
                />
                <button 
                  onClick={() => setShowKey(!showKey)} 
                  className="absolute right-3 top-2.5 text-[#71717a] hover:text-[#ededed] transition-colors"
                >
                  {showKey ? <EyeOff size={16} /> : <Eye size={16} />}
                </button>
              </div>
              <Button 
                onClick={handleSave}
                disabled={!apiKey.trim() || isSaved}
                className={`min-w-[100px] transition-all ${isSaved ? 'bg-emerald-500/10 text-emerald-500 hover:bg-emerald-500/20' : ''}`}
              >
                {isSaved ? <><CheckCircle2 size={16} /> Saved</> : <><Save size={16} /> Save</>}
              </Button>
            </div>
            <p className="text-[11px] text-[#71717a] mt-4 flex items-center gap-1.5">
              <span className="w-1.5 h-1.5 rounded-full bg-emerald-500/50"></span>
              Keys are stored securely in your browser's local storage and never sent to third-party analytics.
            </p>
          </Card>
        </section>
      </div>
    </div>
  );
}
