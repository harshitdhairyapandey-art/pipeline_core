'use client';

import Link from 'next/link';
import { Button } from '@/components/ui/Button';
import { BookOpen, Sparkles, Feather, ArrowRight } from 'lucide-react';

export default function LandingPage() {
  return (
    <div className="min-h-screen flex flex-col animate-in fade-in duration-1000">
      
      {/* Public Topbar */}
      <header className="flex items-center justify-between px-8 py-6 border-b border-[#36312D]/50 z-10 relative">
        <div className="tracking-tight">
          <h1 className="text-xl font-semibold text-[#F5EBE0]">Katha</h1>
          <p className="text-[10px] text-[#A89F95] mt-0.5 uppercase tracking-widest">Powered by Sangam</p>
        </div>
        <div className="flex items-center gap-4">
          <Link href="/library" className="text-sm font-medium text-[#A89F95] hover:text-[#F5EBE0] transition-colors">
            Log In
          </Link>
          <Link href="/new-project">
            <Button className="h-9 px-5 shadow-lg shadow-[#D4A373]/10">Go to Workspace</Button>
          </Link>
        </div>
      </header>

      {/* Hero Section */}
      <main className="flex-1 flex flex-col items-center justify-center text-center px-4 py-24 z-10 relative">
        {/* Subtle background glow */}
        <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[600px] h-[600px] bg-[#D4A373] opacity-[0.03] blur-[120px] rounded-full pointer-events-none" />

        <div className="inline-flex items-center gap-2 px-3 py-1.5 rounded-full border border-[#D4A373]/30 bg-[#D4A373]/5 text-[#D4A373] text-xs font-medium mb-8">
          <Sparkles size={14} />
          <span>Sangam Tri-Core V2 Pipeline Now Active</span>
        </div>

        <h2 className="text-5xl md:text-7xl font-serif font-medium text-[#F5EBE0] tracking-tight max-w-4xl mb-6 leading-[1.1]">
          Translate literature without losing the soul.
        </h2>
        
        <p className="text-lg md:text-xl text-[#A89F95] max-w-2xl mb-12 font-light leading-relaxed">
          A premium, long-form translation engine built for novelists, translators, and avid readers. Upload your manuscript and receive a polished, book-quality output.
        </p>

        <div className="flex items-center gap-4">
          <Link href="/new-project">
            <Button className="h-12 px-8 text-base shadow-xl shadow-[#D4A373]/20 flex items-center gap-2">
              Start Translating <ArrowRight size={18} />
            </Button>
          </Link>
        </div>
      </main>

      {/* Features/Modes Section */}
      <section className="py-24 border-t border-[#36312D]/50 bg-[#221F1D]/30 z-10 relative">
        <div className="max-w-6xl mx-auto px-8">
          <div className="text-center mb-16">
            <h3 className="text-2xl font-serif text-[#F5EBE0]">Engineered for narrative fidelity.</h3>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <div className="p-8 rounded-2xl border border-[#36312D] bg-[#181614] hover:border-[#D4A373]/50 transition-colors">
              <BookOpen className="text-[#D4A373] mb-4" size={28} strokeWidth={1.5} />
              <h4 className="text-lg font-medium text-[#F5EBE0] mb-2">Faithful</h4>
              <p className="text-sm text-[#A89F95] leading-relaxed">Strict adherence to source syntax and phrasing. Perfect for preserving the exact literal meaning of the original author.</p>
            </div>
            <div className="p-8 rounded-2xl border border-[#36312D] bg-[#181614] hover:border-[#D4A373]/50 transition-colors">
              <Feather className="text-[#D4A373] mb-4" size={28} strokeWidth={1.5} />
              <h4 className="text-lg font-medium text-[#F5EBE0] mb-2">Reader-Native</h4>
              <p className="text-sm text-[#A89F95] leading-relaxed">Flows naturally in the target language. Adapts idioms and sentence structures while preserving the story's core facts.</p>
            </div>
            <div className="p-8 rounded-2xl border border-[#D4A373]/30 bg-[#221F1D] shadow-[0_0_30px_rgba(212,163,115,0.05)] relative overflow-hidden">
              <div className="absolute top-0 left-0 w-full h-1 bg-gradient-to-r from-transparent via-[#D4A373] to-transparent opacity-50" />
              <Sparkles className="text-[#D4A373] mb-4" size={28} strokeWidth={1.5} />
              <h4 className="text-lg font-medium text-[#F5EBE0] mb-2">Premium Literary</h4>
              <p className="text-sm text-[#A89F95] leading-relaxed">Elevated prose tailored for published fiction. Refines tone, mood, and descriptive depth for a truly immersive reading experience.</p>
            </div>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="py-8 text-center text-xs text-[#857D75] border-t border-[#36312D]/50 z-10 relative">
        <p>Katha © 2026. Powered by the Sangam Pipeline.</p>
      </footer>
    </div>
  );
}
