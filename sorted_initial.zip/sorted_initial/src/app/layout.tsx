import './globals.css';

export const metadata = {
  title: 'Katha | Premium Literary Translation',
  description: 'Powered by Sangam',
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en" className="dark">
      <body className="antialiased min-h-screen relative noise-bg">
        {children}
      </body>
    </html>
  );
}
