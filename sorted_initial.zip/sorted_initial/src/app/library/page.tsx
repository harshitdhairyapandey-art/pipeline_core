'use client';

import { useEffect, useState } from 'react';
import { useRouter } from 'next/navigation';
import { PageHeader } from '@/components/layout/PageHeader';
import { EmptyState } from '@/components/ui/EmptyState';
import { ProjectAPI } from '@/lib/api/projects';
import type { Project } from '@/lib/types';
import { BookOpen, PlusSquare } from 'lucide-react';
import { Skeleton } from '@/components/ui/Skeleton';
import { trackEvent } from '@/lib/analytics';

export default function LibraryPage() {
  const router = useRouter();
  const [projects, setProjects] = useState<Project[]>([]);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    trackEvent('Library Viewed');
    const fetchProjects = async () => {
      try {
        const data = await ProjectAPI.getAllProjects();
        setProjects(data);
      } catch (error) {
        console.error("Failed to fetch projects", error);
        // Fail silently to empty state for beta, rather than crashing
      } finally {
        setIsLoading(false);
      }
    };
    fetchProjects();
  }, []);

  if (isLoading) return <Skeleton type="full-page" />;

  return (
    <div className="animate-in fade-in duration-500">
      <PageHeader 
        title="Project Library" 
        description="Resume interrupted jobs, review past translations, and manage your exported manuscripts."
      />

      {projects.length === 0 ? (
        <EmptyState 
          icon={BookOpen}
          title="No translations yet"
          description="Your workspace is ready. Upload a manuscript to begin your first translation process."
          actionText="Start New Translation"
          onAction={() => router.push('/new-project')}
        />
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {/* Project Cards mapping goes here (preserved from Phase 6) */}
          <p className="text-[#71717a] text-sm">Projects loaded successfully.</p>
        </div>
      )}
    </div>
  );
}
