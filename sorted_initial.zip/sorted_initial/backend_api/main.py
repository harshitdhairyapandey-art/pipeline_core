import os
import sys
import uuid
import shutil
import json
import asyncio
from typing import Dict
from fastapi import FastAPI, UploadFile, File, HTTPException, BackgroundTasks
from fastapi.responses import StreamingResponse, PlainTextResponse
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel
from dotenv import load_dotenv

# Load environment variables (API keys, etc.)
load_dotenv()

# Ensure pipeline_core is in the path if run directly
current_dir = os.path.dirname(os.path.abspath(__file__))
project_root = os.path.abspath(os.path.join(current_dir, "..", "pipeline core"))
if project_root not in sys.path:
    sys.path.append(project_root)

from pipeline_core.core.models import PipelineJob, JobStatus
from pipeline_core.core.orchestrator import Orchestrator
from pipeline_core.runtime.job_runner import JobRunner
from pipeline_core.runtime.checkpoint_store import load_checkpoint
from pipeline_core.streaming.event_bus import bus
from pipeline_core.stages import (
    IngestionStage,
    PreprocessingStage,
    BatchPlanningStage,
    TranslationStage,
    PolishingStage,
    PostprocessingStage,
    PublishingStage,
    ExportStage
)

app = FastAPI(title="Katha Pipeline Core API")

# 1. Add CORS Middleware for Next.js frontend
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],  # In production, restrict to frontend domain
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# In-memory job tracking
jobs: Dict[str, PipelineJob] = {}

def build_orchestrator() -> Orchestrator:
    """Instantiates the modular pipeline stages in sequence."""
    return Orchestrator([
        IngestionStage(),
        PreprocessingStage(),
        BatchPlanningStage(),
        TranslationStage(),
        PolishingStage(),
        PostprocessingStage(),
        PublishingStage(),
        ExportStage()
    ])

def run_pipeline_background(job: PipelineJob):
    """Execution wrapper to run in a background thread/task."""
    try:
        orchestrator = build_orchestrator()
        runner = JobRunner(orchestrator)
        runner.run(job)
    except Exception as e:
        job.status = JobStatus.FAILED
        job.error_message = str(e)
        bus.error(job.job_id, "SYSTEM", f"Fatal pipeline crash: {str(e)}")

@app.post("/jobs")
async def create_job(background_tasks: BackgroundTasks, file: UploadFile = File(...)):
    """Creates a new job and kicks off background execution."""
    if not file.filename.lower().endswith(('.txt', '.pdf', '.docx')):
        raise HTTPException(status_code=400, detail="Unsupported file format")
        
    job_id = f"job_{uuid.uuid4().hex[:8]}"
    
    # Setup working directory
    working_dir = os.path.abspath(os.path.join("runs", job_id))
    os.makedirs(working_dir, exist_ok=True)
    
    source_path = os.path.join(working_dir, file.filename)
    with open(source_path, "wb") as buffer:
        shutil.copyfileobj(file.file, buffer)
        
    job = PipelineJob(
        job_id=job_id,
        status=JobStatus.PENDING,
        source_path=source_path,
        working_dir=working_dir
    )
    
    jobs[job_id] = job
    
    # Start the pipeline in the background so API returns immediately
    background_tasks.add_task(run_pipeline_background, job)
    
    return {
        "job_id": job.job_id,
        "status": job.status.name,
        "message": "Job initialized and queued for background execution."
    }

@app.get("/jobs/{job_id}/events")
async def stream_job_events(job_id: str):
    """SSE endpoint to stream live events for a specific job."""
    if job_id not in jobs:
        # We allow streaming even if not in memory (maybe it's a cold resume), 
        # but for first launch we expect it to be active.
        pass

    event_queue = bus.subscribe()
    
    async def event_generator():
        try:
            while True:
                # Poll the thread-safe queue
                if not event_queue.empty():
                    event = event_queue.get_nowait()
                    # Filter for this job's events
                    # Note: event kind/data structure from event_bus.py
                    event_data = {
                        "kind": event.kind,
                        "data": event.data,
                        "ts": event.timestamp
                    }
                    if event.data.get("job_id") == job_id or event.kind == "system":
                        yield f"data: {json.dumps(event_data)}\n\n"
                
                await asyncio.sleep(0.5) # Heartbeat/Polling interval
        except asyncio.CancelledError:
            bus.unsubscribe(event_queue)
        finally:
            bus.unsubscribe(event_queue)

    return StreamingResponse(event_generator(), media_type="text/event-stream")

@app.get("/jobs/{job_id}")
def get_job_status(job_id: str):
    if job_id not in jobs:
        raise HTTPException(status_code=404, detail="Job not found")
        
    job = jobs[job_id]
    return {
        "job_id": job.job_id,
        "status": job.status.name,
        "current_stage": job.current_stage.name if job.current_stage else "INITIALIZING",
        "progress": job.progress if hasattr(job, 'progress') else 0,
        "error_message": job.error_message,
        "output": job.final_output_path if job.status == JobStatus.COMPLETED else None
    }

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8000)

